//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-B_NXKIbV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/home/ubuntu/iantechpred/src/routes/__root.tsx",
		children: [
			"/",
			"/api/health",
			"/api/predictions",
			"/api/admin/providers",
			"/api/ai/review",
			"/api/ops/status"
		],
		preloads: ["/assets/index-DjGnktw_.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DjGnktw_.js"
		} }]
	},
	"/": {
		filePath: "/home/ubuntu/iantechpred/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BEv89MLa.js"]
	}
} });
//#endregion
export { tsrStartManifest };
