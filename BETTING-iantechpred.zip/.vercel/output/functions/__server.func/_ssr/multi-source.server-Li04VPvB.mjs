import { a as fatigueFactor, c as multiSeasonElo, d as tableMotivation, f as venuePpg, l as oddsMovement, m as weatherDiagnostics, o as fitTimeDecayedDixonColes, p as venueSplitFactor, r as assessFreshness, s as fittedDcProbabilities } from "./analysis-Cbzgc3mb.mjs";
import { a as eloTriple } from "./backtest-DeRv33Nh.mjs";
import { a as getSql, r as ensureDbReady } from "./db-DcaGEQZG.mjs";
import { t as env } from "./env.server-B4a86VpI.mjs";
import { n as normalizeTeamName } from "./jackpot-utils-2-SdMduq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/multi-source.server-Li04VPvB.js
var cache = /* @__PURE__ */ new Map();
var TTL = 12e5;
var HISTORY_TTL = 864e5;
var normalize = (value) => normalizeTeamName(value).replace(/\b(fc|afc|cf|sc|club)\b/g, "").replace(/\s+/g, " ").trim();
var exactTeam = (a, b) => normalize(a) === normalize(b);
var validDate = (value) => !!value && Number.isFinite(Date.parse(value));
var clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
async function memo(key, ttl, load) {
	const hit = cache.get(key);
	if (hit && hit.expiresAt > Date.now()) return hit.promise;
	const entry = {
		expiresAt: Date.now() + ttl,
		createdAt: Date.now(),
		promise: load()
	};
	cache.set(key, entry);
	try {
		const value = await entry.promise;
		entry.createdAt = Date.now();
		return value;
	} catch (error) {
		cache.delete(key);
		throw error;
	}
}
async function json(url, headers = {}) {
	const response = await fetch(url, {
		headers,
		signal: AbortSignal.timeout(1e4)
	});
	if (!response.ok) throw new Error(`Provider responded ${response.status}`);
	return response.json();
}
async function apiFootball(path, params, ttl = TTL) {
	const key = env("API_FOOTBALL_KEY");
	if (!key) return null;
	const query = new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)])).toString();
	return memo(`af:${path}:${query}`, ttl, () => json(`https://v3.football.api-sports.io/${path}?${query}`, { "x-apisports-key": key }));
}
function getLeagueOverrides() {
	try {
		const parsed = JSON.parse(env("API_FOOTBALL_LEAGUE_MAP") ?? "{}");
		if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) return {};
		return Object.fromEntries(Object.entries(parsed).filter(([, v]) => Number.isInteger(v) && Number(v) > 0).map(([k, v]) => [k, Number(v)]));
	} catch {
		return {};
	}
}
async function resolveLeagueId(league) {
	const override = getLeagueOverrides()[league];
	if (override) return override;
	const matches = ((await apiFootball("leagues", { search: league }))?.response ?? []).filter((row) => exactTeam(String(row.league?.name ?? ""), league));
	const ids = [...new Set(matches.map((row) => Number(row.league?.id)).filter((n) => Number.isInteger(n) && n > 0))];
	return ids.length === 1 ? ids[0] : null;
}
function seasonFor(kickoffAt) {
	const d = kickoffAt && validDate(kickoffAt) ? new Date(kickoffAt) : /* @__PURE__ */ new Date();
	return d.getUTCMonth() >= 6 ? d.getUTCFullYear() : d.getUTCFullYear() - 1;
}
function mapFinished(row, league, season) {
	const f = row.fixture, teams = row.teams, goals = row.goals;
	if (f?.status?.short !== "FT" || !f.date || !teams?.home?.id || !teams.away?.id || teams.home.id === teams.away.id) return null;
	const homeGoals = goals?.home, awayGoals = goals?.away;
	if (!Number.isInteger(homeGoals) || !Number.isInteger(awayGoals) || Number(homeGoals) < 0 || Number(awayGoals) < 0) return null;
	return {
		homeId: String(teams.home.id),
		awayId: String(teams.away.id),
		homeGoals: Number(homeGoals),
		awayGoals: Number(awayGoals),
		kickoffAt: f.date,
		season,
		league
	};
}
async function loadLeagueFixtures(league, kickoffAt) {
	const leagueId = await resolveLeagueId(league).catch(() => null);
	if (!leagueId) return {
		leagueId: null,
		all: [],
		history: [],
		observedAt: null
	};
	const current = seasonFor(kickoffAt);
	const all = (await Promise.all([
		current,
		current - 1,
		current - 2
	].map((season) => apiFootball("fixtures", {
		league: leagueId,
		season
	}, HISTORY_TTL).catch(() => null)))).flatMap((payload) => payload?.response ?? []);
	const history = all.map((row) => mapFinished(row, league, seasonFor(row.fixture?.date ?? null))).filter((m) => !!m);
	const currentKey = `af:fixtures:${new URLSearchParams({
		league: String(leagueId),
		season: String(current)
	}).toString()}`;
	const observedAt = cache.get(currentKey)?.createdAt;
	return {
		leagueId,
		all,
		history,
		observedAt: all.length && observedAt ? new Date(observedAt).toISOString() : null
	};
}
function matchTeamId(fixtures, name) {
	const ids = /* @__PURE__ */ new Set();
	for (const row of fixtures) for (const team of [row.teams?.home, row.teams?.away]) if (team?.id && team.name && exactTeam(team.name, name)) ids.add(team.id);
	return ids.size === 1 ? [...ids][0] : null;
}
function teamRecent(fixtures, teamId, before) {
	return fixtures.map((row) => mapFinished(row, "", seasonFor(row.fixture?.date ?? null))).filter((m) => !!m && (m.homeId === String(teamId) || m.awayId === String(teamId)) && Date.parse(m.kickoffAt) < before).sort((a, b) => Date.parse(b.kickoffAt) - Date.parse(a.kickoffAt)).slice(0, 20);
}
function ppg(matches, teamId) {
	if (!matches.length) return null;
	return matches.reduce((sum, m) => {
		const isHome = m.homeId === teamId;
		const gf = isHome ? m.homeGoals : m.awayGoals;
		const ga = isHome ? m.awayGoals : m.homeGoals;
		return sum + (gf > ga ? 3 : gf === ga ? 1 : 0);
	}, 0) / matches.length;
}
function restSummary(matches, teamId, kickoffAt) {
	if (!kickoffAt || !validDate(kickoffAt)) return {
		days: null,
		games14d: 0
	};
	const cutoff = Date.parse(kickoffAt);
	const teamMatches = matches.filter((m) => (m.homeId === teamId || m.awayId === teamId) && Date.parse(m.kickoffAt) < cutoff).sort((a, b) => Date.parse(b.kickoffAt) - Date.parse(a.kickoffAt));
	return {
		days: teamMatches[0] ? (cutoff - Date.parse(teamMatches[0].kickoffAt)) / 864e5 : null,
		games14d: teamMatches.filter((m) => cutoff - Date.parse(m.kickoffAt) <= 12096e5).length
	};
}
async function persistHistory(history, fixtures, league, leagueId) {
	if (!history.length || !leagueId) return;
	try {
		await ensureDbReady();
		const sql = await getSql();
		const latest = history.sort((a, b) => Date.parse(b.kickoffAt) - Date.parse(a.kickoffAt)).slice(0, 500);
		const values = [];
		const placeholders = latest.map((m, i) => {
			const row = fixtures.find((f) => String(f.teams?.home?.id) === m.homeId && String(f.teams?.away?.id) === m.awayId && f.fixture?.date === m.kickoffAt);
			const fixtureId = String(row?.fixture?.id ?? `${m.homeId}-${m.awayId}-${m.kickoffAt}`);
			const names = row?.teams;
			const offset = i * 13;
			values.push("api-football", fixtureId, league, league, m.season ?? null, m.kickoffAt, m.homeId, names?.home?.name ?? m.homeId, m.awayId, names?.away?.name ?? m.awayId, m.homeGoals, m.awayGoals, true);
			return `($${offset + 1},$${offset + 2},$${offset + 3},$${offset + 4},$${offset + 5},$${offset + 6},$${offset + 7},$${offset + 8},$${offset + 9},$${offset + 10},$${offset + 11},$${offset + 12},$${offset + 13})`;
		});
		if (placeholders.length) await sql.query(`insert into historical_match_results (provider,fixture_id,league_code,league_name,season,kickoff_at,home_id,home_name,away_id,away_name,home_goals,away_goals,regulation_time) values ${placeholders.join(",")} on conflict (provider,fixture_id) do nothing`, values);
	} catch {}
}
async function saveLineup(matchId, providerMatchId, status, kickoffAt, payload, observedAt) {
	try {
		await ensureDbReady();
		await (await getSql())`insert into lineup_observations (match_id, provider, provider_match_id, status, kickoff_at, observed_at, payload)
      values (${matchId}, 'api-football', ${providerMatchId === null ? null : String(providerMatchId)}, ${status}, ${kickoffAt}, ${observedAt}, ${JSON.stringify(payload)})
      on conflict (match_id, provider, observed_at) do nothing`;
	} catch {}
}
async function lateLineup(context, fixtures, homeId, awayId) {
	if (!context.kickoffAt || !validDate(context.kickoffAt)) return void 0;
	const kickoff = Date.parse(context.kickoffAt), now = Date.now();
	if (now < kickoff - 54e5 || now > kickoff + 9e5) return void 0;
	const date = new Date(kickoff).toISOString().slice(0, 10);
	let providerFixture = fixtures.find((f) => f.fixture?.date?.slice(0, 10) === date && f.teams?.home?.id === homeId && f.teams?.away?.id === awayId);
	if (!providerFixture) {
		const candidates = ((await apiFootball("fixtures", {
			team: homeId,
			date
		}, 12e4).catch(() => null))?.response ?? []).filter((f) => f.teams?.home?.id === homeId && f.teams?.away?.id === awayId && f.fixture?.date && Math.abs(Date.parse(f.fixture.date) - kickoff) < 432e5);
		if (candidates.length === 1) providerFixture = candidates[0];
	}
	const observedAt = (/* @__PURE__ */ new Date(Math.floor(now / 6e4) * 6e4)).toISOString();
	if (!providerFixture?.fixture?.id) {
		const status = "identity-unverified";
		await saveLineup(context.id, null, status, context.kickoffAt, {}, observedAt);
		return {
			status,
			observedAt,
			homeStarters: 0,
			awayStarters: 0
		};
	}
	const rows = (await apiFootball("fixtures/lineups", { fixture: providerFixture.fixture.id }, 12e4).catch(() => null))?.response ?? [];
	const h = rows.find((r) => r.team?.id === homeId);
	const a = rows.find((r) => r.team?.id === awayId);
	const homeStarters = Array.isArray(h?.startXI) ? h.startXI.length : 0;
	const awayStarters = Array.isArray(a?.startXI) ? a.startXI.length : 0;
	const status = homeStarters >= 11 && awayStarters >= 11 ? "confirmed" : rows.length ? "not-announced" : "coverage-unavailable";
	const payload = {
		home: h?.startXI ?? [],
		away: a?.startXI ?? [],
		substitutes: {
			home: h?.substitutes ?? [],
			away: a?.substitutes ?? []
		}
	};
	await saveLineup(context.id, providerFixture.fixture.id, status, context.kickoffAt, payload, observedAt);
	return {
		status,
		observedAt,
		homeStarters,
		awayStarters
	};
}
function venueCoordinates(context) {
	try {
		const raw = JSON.parse(env("VENUE_COORDINATES_JSON") ?? "{}");
		const value = raw?.[context.id] ?? (context.venue ? raw?.[context.venue] : null);
		const latitude = Number(value?.latitude ?? value?.lat), longitude = Number(value?.longitude ?? value?.lon);
		if (Number.isFinite(latitude) && Number.isFinite(longitude) && latitude >= -90 && latitude <= 90 && longitude >= -180 && longitude <= 180) return {
			latitude,
			longitude
		};
	} catch {}
	return null;
}
async function weatherFor(context) {
	if (!context.kickoffAt || !validDate(context.kickoffAt)) return void 0;
	const coords = venueCoordinates(context);
	if (!coords) return void 0;
	const base = (env("OPEN_METEO_BASE_URL") ?? "https://api.open-meteo.com/v1/forecast").replace(/\/$/, "");
	const params = new URLSearchParams({
		latitude: String(coords.latitude),
		longitude: String(coords.longitude),
		hourly: "temperature_2m,precipitation,wind_speed_10m",
		timezone: "UTC",
		forecast_days: "16"
	});
	const data = await memo(`weather:${context.id}:${context.kickoffAt}`, 18e5, () => json(`${base}?${params}`)).catch(() => null);
	const times = data?.hourly?.time ?? [];
	const target = Date.parse(context.kickoffAt);
	let index = -1, delta = Infinity;
	for (let i = 0; i < times.length; i++) {
		const diff = Math.abs(Date.parse(times[i]) - target);
		if (diff < delta) {
			delta = diff;
			index = i;
		}
	}
	if (index < 0 || delta > 72e5) return void 0;
	const temperatureC = Number(data.hourly.temperature_2m?.[index]);
	const precipitationMm = Number(data.hourly.precipitation?.[index]);
	const windKmh = Number(data.hourly.wind_speed_10m?.[index]);
	const observedAt = (/* @__PURE__ */ new Date()).toISOString();
	const variables = {
		temperatureC: Number.isFinite(temperatureC) ? temperatureC : null,
		precipitationMm: Number.isFinite(precipitationMm) ? precipitationMm : null,
		windKmh: Number.isFinite(windKmh) ? windKmh : null
	};
	try {
		await ensureDbReady();
		await (await getSql())`insert into weather_observations (match_id, provider, latitude, longitude, observed_at, valid_at, variables)
      values (${context.id}, 'open-meteo', ${coords.latitude}, ${coords.longitude}, ${observedAt}, ${times[index]}, ${JSON.stringify(variables)}) on conflict do nothing`;
	} catch {}
	return {
		validAt: times[index],
		...Number.isFinite(temperatureC) ? { temperatureC } : {},
		...Number.isFinite(precipitationMm) ? { precipitationMm } : {},
		...Number.isFinite(windKmh) ? { windKmh } : {},
		diagnostics: weatherDiagnostics({
			...Number.isFinite(temperatureC) ? { temperatureC } : {},
			...Number.isFinite(precipitationMm) ? { precipitationMm } : {},
			...Number.isFinite(windKmh) ? { windKmh } : {}
		})
	};
}
var SPORT_BY_LEAGUE = {
	"Premier League": "soccer_epl",
	"Championship": "soccer_efl_champ",
	"Bundesliga": "soccer_germany_bundesliga",
	"La Liga": "soccer_spain_la_liga",
	"Serie A": "soccer_italy_serie_a",
	"Ligue 1": "soccer_france_ligue_one",
	"Eredivisie": "soccer_netherlands_eredivisie",
	"Primeira Liga": "soccer_portugal_primeira_liga"
};
async function captureOdds(context) {
	const key = env("ODDS_API_KEY"), sport = SPORT_BY_LEAGUE[context.league];
	if (!key || !sport || !context.kickoffAt) return {
		market: null,
		movement: null,
		dispersion: void 0
	};
	const events = (await memo(`odds:${sport}`, TTL, () => json(`https://api.the-odds-api.com/v4/sports/${sport}/odds/?apiKey=${encodeURIComponent(key)}&regions=eu,uk&markets=h2h&oddsFormat=decimal`)).catch(() => null) ?? []).filter((event) => exactTeam(String(event.home_team ?? ""), context.home) && exactTeam(String(event.away_team ?? ""), context.away));
	if (events.length !== 1) return {
		market: null,
		movement: null,
		dispersion: void 0
	};
	const event = events[0];
	if (event.commence_time && Math.abs(Date.parse(event.commence_time) - Date.parse(context.kickoffAt)) > 1296e5) return {
		market: null,
		movement: null,
		dispersion: void 0
	};
	const capturedAt = (/* @__PURE__ */ new Date(Math.floor(Date.now() / 6e4) * 6e4)).toISOString();
	const captured = [];
	for (const book of event.bookmakers ?? []) {
		const market = book.markets?.find((m) => m.key === "h2h");
		const find = (name) => market?.outcomes?.find((o) => exactTeam(String(o.name ?? ""), name))?.price;
		const h = find(context.home), a = find(context.away), d = find("Draw");
		const updatedAt = book.last_update ?? null;
		const updatedMs = updatedAt ? Date.parse(updatedAt) : NaN;
		const updateAge = Date.now() - updatedMs;
		if (Number.isFinite(h) && Number.isFinite(a) && Number.isFinite(d) && h > 1 && a > 1 && d > 1 && book.key && Number.isFinite(updatedMs) && updateAge >= -3e5 && updateAge <= 72e5) captured.push({
			key: book.key,
			title: book.title ?? book.key,
			updatedAt,
			odds: {
				home: h,
				draw: d,
				away: a
			}
		});
	}
	if (!captured.length) return {
		market: null,
		movement: null,
		dispersion: void 0
	};
	try {
		await ensureDbReady();
		const sql = await getSql();
		const prior = await sql`select distinct on (bookmaker_key) bookmaker_key, provider_updated_at from odds_observations where match_id = ${context.id} and provider = 'the-odds-api' order by bookmaker_key, captured_at desc`;
		const lastUpdate = new Map(prior.map((row) => [String(row.bookmaker_key), row.provider_updated_at ? new Date(row.provider_updated_at).getTime() : NaN]));
		for (const book of captured) {
			if (lastUpdate.get(book.key) === Date.parse(book.updatedAt)) continue;
			await sql`insert into odds_observations (match_id, provider, event_id, bookmaker_key, bookmaker_name, market, kickoff_at, captured_at, provider_updated_at, home_odds, draw_odds, away_odds)
        values (${context.id}, 'the-odds-api', ${String(event.id ?? context.id)}, ${book.key}, ${book.title}, 'h2h', ${context.kickoffAt}, ${capturedAt}, ${book.updatedAt}, ${book.odds.home}, ${book.odds.draw}, ${book.odds.away}) on conflict do nothing`;
		}
	} catch {}
	const { multiBookConsensus } = await import("./backtest-DeRv33Nh.mjs").then((n) => n.t).then((n) => n.f);
	const marketConsensus = multiBookConsensus(captured.map((b) => b.odds));
	let movement = null;
	try {
		await ensureDbReady();
		const history = await (await getSql())`select bookmaker_key, captured_at, kickoff_at, home_odds, draw_odds, away_odds from odds_observations where match_id = ${context.id} and provider = 'the-odds-api' order by captured_at asc`;
		const groups = /* @__PURE__ */ new Map();
		for (const row of history) groups.set(String(row.bookmaker_key), [...groups.get(String(row.bookmaker_key)) ?? [], row]);
		const shifts = [];
		let openingAt = null, currentAt = null;
		for (const rows of groups.values()) {
			if (rows.length < 2) continue;
			const first = rows[0], last = rows[rows.length - 1];
			const quote = (r) => ({
				home: Number(r.home_odds),
				draw: Number(r.draw_odds),
				away: Number(r.away_odds)
			});
			const firstUpdate = String(first.provider_updated_at ?? ""), lastUpdate = String(last.provider_updated_at ?? "");
			const shift = firstUpdate && lastUpdate && firstUpdate !== lastUpdate ? oddsMovement(quote(first), quote(last)) : null;
			if (shift) shifts.push(shift);
			openingAt ??= new Date(first.captured_at).toISOString();
			currentAt = new Date(last.captured_at).toISOString();
		}
		if (shifts.length && openingAt && currentAt) {
			const med = (key) => {
				const xs = shifts.map((s) => s[key]).sort((a, b) => a - b);
				return xs[Math.floor(xs.length / 2)];
			};
			movement = {
				openingObservedAt: openingAt,
				currentObservedAt: currentAt,
				movement: {
					home: med("home"),
					draw: med("draw"),
					away: med("away")
				}
			};
		}
	} catch {}
	return {
		market: marketConsensus?.p ?? null,
		movement,
		dispersion: marketConsensus?.dispersion
	};
}
async function saveStandings(matchId, leagueId, season, teamId, observedAt, row, gamesLeft) {
	try {
		await ensureDbReady();
		await (await getSql())`insert into standings_observations (match_id, provider, league_id, team_id, season, observed_at, position, points, played, games_left)
      values (${matchId}, 'api-football', ${String(leagueId)}, ${String(teamId)}, ${season}, ${observedAt}, ${row.rank ?? null}, ${row.points ?? null}, ${row.all?.played ?? null}, ${gamesLeft}) on conflict do nothing`;
	} catch {}
}
async function loadMultiSourceSignals(context) {
	const used = [];
	const s = {
		used,
		notes: [],
		featureStatus: []
	};
	const status = (id, state, detail) => s.featureStatus.push({
		id,
		status: state,
		detail
	});
	const key = env("API_FOOTBALL_KEY");
	const weatherAvailable = !!venueCoordinates(context);
	const nowIso = (/* @__PURE__ */ new Date()).toISOString();
	if (!key) {
		s.freshness = assessFreshness([{
			name: "API-Football core team history",
			observedAt: null,
			required: true,
			maxAgeHours: 24
		}]);
		for (const id of [
			"fatigue",
			"venue-split",
			"standings-motivation",
			"late-lineups",
			"elo-multiseason",
			"dixon-coles",
			"league-draw-rate"
		]) status(id, "missing", "API_FOOTBALL_KEY is not configured; no data is inferred.");
	}
	const leagueData = key ? await loadLeagueFixtures(context.league, context.kickoffAt).catch(() => ({
		leagueId: null,
		all: [],
		history: [],
		observedAt: null
	})) : {
		leagueId: null,
		all: [],
		history: [],
		observedAt: null
	};
	const homeId = leagueData.leagueId ? matchTeamId(leagueData.all, context.home) : null;
	const awayId = leagueData.leagueId ? matchTeamId(leagueData.all, context.away) : null;
	const completeLeagueHistory = leagueData.history;
	const cutoff = context.kickoffAt && validDate(context.kickoffAt) ? Date.parse(context.kickoffAt) : Date.now();
	const history = completeLeagueHistory.filter((m) => Date.parse(m.kickoffAt) < cutoff);
	const coreReady = validDate(context.kickoffAt) && !!leagueData.observedAt && !!homeId && !!awayId && history.filter((m) => m.homeId === String(homeId) || m.awayId === String(homeId)).length >= 4 && history.filter((m) => m.homeId === String(awayId) || m.awayId === String(awayId)).length >= 4;
	s.freshness = assessFreshness([{
		name: "API-Football league history / home team",
		observedAt: coreReady ? leagueData.observedAt : null,
		required: true,
		maxAgeHours: 24
	}, {
		name: "API-Football league history / away team",
		observedAt: coreReady ? leagueData.observedAt : null,
		required: true,
		maxAgeHours: 24
	}]);
	let contextSwing = 0;
	if (coreReady && homeId && awayId) {
		const hid = String(homeId), aid = String(awayId);
		const [homeRecentPayload, awayRecentPayload] = await Promise.all([apiFootball("fixtures", {
			team: homeId,
			last: 20
		}, HISTORY_TTL).catch(() => null), apiFootball("fixtures", {
			team: awayId,
			last: 20
		}, HISTORY_TTL).catch(() => null)]);
		const hRecent = teamRecent(homeRecentPayload?.response ?? [], homeId, cutoff);
		const aRecent = teamRecent(awayRecentPayload?.response ?? [], awayId, cutoff);
		const hr = restSummary(hRecent, hid, context.kickoffAt), ar = restSummary(aRecent, aid, context.kickoffAt);
		s.rest = {
			homeDays: hr.days,
			awayDays: ar.days,
			homeGames14d: hr.games14d,
			awayGames14d: ar.games14d
		};
		const homeOverall = ppg(history.filter((m) => m.homeId === hid || m.awayId === hid), hid);
		const awayOverall = ppg(history.filter((m) => m.homeId === aid || m.awayId === aid), aid);
		const homeVenue = venuePpg(history, hid, "home"), awayVenue = venuePpg(history, aid, "away");
		const homeFactor = venueSplitFactor(homeOverall, homeVenue.ppg, homeVenue.games);
		const awayFactor = venueSplitFactor(awayOverall, awayVenue.ppg, awayVenue.games);
		s.venueSplit = {
			homePpg: homeVenue.ppg,
			awayPpg: awayVenue.ppg,
			homeFactor,
			awayFactor,
			homeGames: homeVenue.games,
			awayGames: awayVenue.games
		};
		if (hr.days !== null && ar.days !== null) {
			contextSwing += clamp((fatigueFactor(hr.days, hr.games14d) - fatigueFactor(ar.days, ar.games14d)) * .12, -.025, .025);
			status("fatigue", "ready", `Rest: ${hr.days.toFixed(1)} d vs ${ar.days.toFixed(1)} d; based on completed fixtures.`);
			used.push("Rest and fatigue from completed fixtures");
		} else status("fatigue", "missing", "No verified previous fixture timestamp for both teams.");
		if (homeVenue.games >= 4 && awayVenue.games >= 4) {
			contextSwing += clamp((homeFactor - awayFactor) * .08, -.02, .02);
			status("venue-split", "ready", `${homeVenue.games} home and ${awayVenue.games} away results with shrinkage.`);
			used.push("Home/away venue-split form");
		} else status("venue-split", "missing", "Fewer than four venue-specific results for one side.");
		const season = seasonFor(context.kickoffAt);
		if (leagueData.leagueId) {
			const table = ((await apiFootball("standings", {
				league: leagueData.leagueId,
				season
			}).catch(() => null))?.response?.[0]?.league?.standings ?? []).flat();
			const hTable = table.find((r) => r.team?.id === homeId), aTable = table.find((r) => r.team?.id === awayId);
			const future = leagueData.all.filter((f) => f.fixture?.date && Date.parse(f.fixture.date) >= cutoff - 18e5 && ["NS", "TBD"].includes(String(f.fixture.status?.short)));
			const gamesLeft = (id) => future.filter((f) => f.teams?.home?.id === id || f.teams?.away?.id === id).length;
			const hm = tableMotivation(hTable?.rank ?? null, table.length || null, hTable ? gamesLeft(homeId) : null);
			const am = tableMotivation(aTable?.rank ?? null, table.length || null, aTable ? gamesLeft(awayId) : null);
			const observedAt = (/* @__PURE__ */ new Date()).toISOString();
			if (hTable) await saveStandings(context.id, leagueData.leagueId, season, homeId, observedAt, hTable, hm.stakes === "unknown" ? null : gamesLeft(homeId));
			if (aTable) await saveStandings(context.id, leagueData.leagueId, season, awayId, observedAt, aTable, am.stakes === "unknown" ? null : gamesLeft(awayId));
			if (hTable && aTable) {
				s.motivation = {
					home: hm.stakes,
					away: am.stakes,
					homeFactor: hm.factor,
					awayFactor: am.factor
				};
				contextSwing += clamp(((hm.factor ?? 1) - (am.factor ?? 1)) * .08, -.015, .015);
				status("standings-motivation", "ready", `Standings ${hTable.rank} and ${aTable.rank}; remaining fixtures counted from provider schedule.`);
				used.push("Table position and remaining-fixture motivation");
			} else status("standings-motivation", "missing", "Provider standings did not identify both teams; no motivation adjustment.");
		} else status("standings-motivation", "missing", "League mapping is ambiguous; configure API_FOOTBALL_LEAGUE_MAP to use standings.");
		const elo = multiSeasonElo(history);
		const ratingHome = elo.ratings.get(hid), ratingAway = elo.ratings.get(aid);
		if (ratingHome !== void 0 && ratingAway !== void 0 && elo.matches >= 100) {
			s.elo = eloTriple(ratingHome, ratingAway);
			used.push(`Multi-season Elo (${elo.seasons.length} seasons, ${elo.matches} results)`);
			status("elo-multiseason", "ready", `${elo.matches} completed results across ${elo.seasons.length} seasons.`);
		} else status("elo-multiseason", "missing", "At least 100 validated results are required for Elo history.");
		const fitted = fitTimeDecayedDixonColes(history);
		if (fitted) {
			s.dixonColes = fittedDcProbabilities(fitted, hid, aid);
			used.push(`Time-decayed Dixon–Coles (${fitted.samples} results)`);
			status("dixon-coles", "ready", `Fitted on ${fitted.samples} dated results; half-life ${fitted.halfLifeDays} days.`);
		} else status("dixon-coles", "missing", "Fewer than 100 suitable dated results or insufficient team coverage.");
		const draws = history.filter((m) => m.homeGoals === m.awayGoals).length;
		if (history.length >= 20) {
			s.drawPrior = {
				draws,
				sample: history.length,
				observedAt: leagueData.observedAt ?? nowIso
			};
			status("league-draw-rate", "ready", `${draws}/${history.length} draw results, shrunk toward the global prior.`);
			used.push("League-specific draw-rate prior");
		} else status("league-draw-rate", "missing", "At least 20 completed league results are required.");
		persistHistory(history, leagueData.all, context.league, leagueData.leagueId);
		const lineup = await lateLineup(context, leagueData.all, homeId, awayId).catch(() => void 0);
		if (lineup) {
			s.lineups = lineup;
			status("late-lineups", lineup.status === "confirmed" ? "ready" : "missing", lineup.status === "confirmed" ? `${lineup.homeStarters} and ${lineup.awayStarters} starters confirmed; saved separately.` : `Lineup state: ${lineup.status}; forecast remains frozen.`);
			if (lineup.status === "confirmed") used.push("Late lineup check (separate observation)");
		} else status("late-lineups", "diagnostic", "Lineup query activates on-demand within 90 minutes of a verified kickoff.");
	} else if (key) {
		for (const id of [
			"fatigue",
			"venue-split",
			"standings-motivation",
			"elo-multiseason",
			"dixon-coles",
			"league-draw-rate",
			"late-lineups"
		]) status(id, "missing", "Exact competition/team identity or a sufficient real-results history was unavailable.");
		s.notes?.push("API-Football data did not uniquely verify both teams and competition; no live team-context adjustment was applied.");
	}
	const weather = await weatherFor(context).catch(() => void 0);
	if (weather) {
		s.weather = weather;
		status("weather", weather.diagnostics.length ? "diagnostic" : "ready", weather.diagnostics.length ? weather.diagnostics.join(" ") : `Open-Meteo forecast for ${weather.validAt}; diagnostic only.`);
		used.push("Open-Meteo matchday weather diagnostic");
	} else status("weather", weatherAvailable ? "missing" : "missing", "Verified venue coordinates and a forecast within range are required.");
	const odds = await captureOdds(context).catch(() => ({
		market: null,
		movement: null,
		dispersion: void 0
	}));
	if (odds.market) {
		s.market = odds.market;
		s.dispersion = odds.dispersion;
		used.push("The Odds API multi-book consensus");
		status("market-prices", "ready", "Current 1X2 quote matched by exact teams and fixture date.");
	} else status("market-prices", "missing", "No fresh exact The Odds API event and bookmaker quotes are available.");
	if (odds.movement?.movement) {
		s.movement = odds.movement.movement;
		s.oddsMovement = odds.movement;
		status("odds-movement", "ready", `Opening/current are first and latest app-observed quotes (${odds.movement.openingObservedAt} → ${odds.movement.currentObservedAt}).`);
		used.push("Timestamped odds movement");
	} else status("odds-movement", env("ODDS_API_KEY") ? "missing" : "missing", "Two timestamped, same-event quotes are required; no opening price is inferred.");
	if (contextSwing) s.nudge = {
		home: contextSwing,
		draw: 0,
		away: -contextSwing
	};
	if (!key) s.notes?.push("No API-Football key: stale bundled figures are not treated as verified live inputs; pass until required current team data is available.");
	return s;
}
//#endregion
export { loadMultiSourceSignals };
