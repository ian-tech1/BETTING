import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tracker-fn-BC5-nSrh.js
var getTracker_createServerFn_handler = createServerRpc({
	id: "9dfca6027de17322ea5a342cf6f5ff6950aac8b0867ec5b57fcf962ca352f321",
	name: "getTracker",
	filename: "src/lib/tracker-fn.ts"
}, (opts) => getTracker.__executeServer(opts));
var getTracker = createServerFn({ method: "GET" }).handler(getTracker_createServerFn_handler, async () => {
	const [{ loadPredictions, loadMarketBenchmarks }, { checkDatabaseHealth }] = await Promise.all([import("./tracker.server-D2Xu2JlA.mjs"), import("./db-DcaGEQZG.mjs").then((n) => n.n)]);
	const database = await checkDatabaseHealth();
	if (!database.connected) return {
		rows: [],
		marketBenchmarks: [],
		database,
		serverTime: (/* @__PURE__ */ new Date()).toISOString()
	};
	const rows = await loadPredictions();
	return {
		rows,
		marketBenchmarks: await loadMarketBenchmarks(rows),
		database,
		serverTime: (/* @__PURE__ */ new Date()).toISOString()
	};
});
/**
* Records forecasts for fixtures that have not kicked off, settles finished ones, and returns the log.
* Takes no input: every probability and timestamp is produced on the server.
*/
var lastSyncAt = 0;
var syncTracker_createServerFn_handler = createServerRpc({
	id: "f8d435955c0f59958b672882c4cf0a2c57d4d17c41efeef29851b396bf0f6aa2",
	name: "syncTracker",
	filename: "src/lib/tracker-fn.ts"
}, (opts) => syncTracker.__executeServer(opts));
var syncTracker = createServerFn({ method: "POST" }).handler(syncTracker_createServerFn_handler, async () => {
	const [{ recordUpcoming, settlePending, loadPredictions, loadMarketBenchmarks }, { checkDatabaseHealth }] = await Promise.all([import("./tracker.server-D2Xu2JlA.mjs"), import("./db-DcaGEQZG.mjs").then((n) => n.n)]);
	const { env } = await import("./env.server-B4a86VpI.mjs").then((n) => n.n);
	const database = await checkDatabaseHealth();
	const serverTime = (/* @__PURE__ */ new Date()).toISOString();
	if (!database.connected) return {
		rows: [],
		marketBenchmarks: [],
		recording: {
			recorded: 0,
			alreadyLogged: 0,
			skipped: {
				noKickoff: 0,
				passed: 0
			}
		},
		settling: {
			settled: 0,
			waiting: 0,
			note: database.note
		},
		serverTime,
		dataKeys: { footballData: !!env("FOOTBALL_DATA_KEY") },
		database
	};
	const now = Date.now();
	const throttled = now - lastSyncAt < 6e4;
	if (!throttled) lastSyncAt = now;
	const recording = throttled ? {
		recorded: 0,
		alreadyLogged: 0,
		skipped: {
			noKickoff: 0,
			passed: 0
		}
	} : await recordUpcoming();
	const settling = throttled ? {
		settled: 0,
		waiting: 0,
		note: "A sync ran recently; try again in a minute."
	} : await settlePending();
	const rows = await loadPredictions();
	return {
		rows,
		marketBenchmarks: await loadMarketBenchmarks(rows),
		recording,
		settling,
		serverTime: (/* @__PURE__ */ new Date()).toISOString(),
		dataKeys: { footballData: !!env("FOOTBALL_DATA_KEY") },
		database
	};
});
//#endregion
export { getTracker_createServerFn_handler, syncTracker_createServerFn_handler };
