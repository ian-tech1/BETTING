import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/db-DcaGEQZG.js
var _0002_desk_default = "create table if not exists desk_state (\n  user_id text primary key,\n  payload text not null,\n  updated_at timestamptz not null default now()\n);\n";
var _0003_results_default = "create table if not exists settled_results (\n  match_id text primary key,\n  engine_home double precision not null,\n  engine_draw double precision not null,\n  engine_away double precision not null,\n  ai_home double precision not null,\n  ai_draw double precision not null,\n  ai_away double precision not null,\n  result text not null check (result in ('home','draw','away')),\n  settled_at timestamptz not null default now()\n);\n";
var _0004_prediction_log_default = "-- Pre-match prediction log. A row is written once, before kickoff, and its forecast columns are never updated.\n-- Only the result columns are filled in later, and only while result is still null.\ncreate table if not exists prediction_log (\n  match_id text primary key,\n  home text not null,\n  away text not null,\n  league text not null,\n  kickoff_at timestamptz not null,\n  recorded_at timestamptz not null default now(),\n  model_version text not null,\n  input_hash text not null,\n  engine_home double precision not null,\n  engine_draw double precision not null,\n  engine_away double precision not null,\n  ai_home double precision not null,\n  ai_draw double precision not null,\n  ai_away double precision not null,\n  final_home double precision not null,\n  final_draw double precision not null,\n  final_away double precision not null,\n  pick text not null check (pick in ('home','draw','away')),\n  code text not null,\n  tier text not null check (tier in ('A','B','C','PASS')),\n  result text check (result in ('home','draw','away')),\n  home_goals integer,\n  away_goals integer,\n  settled_at timestamptz,\n  result_source text,\n  -- The database itself refuses a forecast recorded at or after kickoff.\n  constraint recorded_before_kickoff check (recorded_at < kickoff_at),\n  constraint result_and_settled_together check ((result is null) = (settled_at is null))\n);\n\ncreate index if not exists prediction_log_pending_idx on prediction_log (kickoff_at) where result is null;\n";
var _0005_multi_source_analysis_default = "-- Supplemental observations are separate from the immutable pre-match forecast ledger.\n-- These rows contain provider data only; no account or personal fields are stored.\ncreate table if not exists historical_match_results (\n  provider text not null,\n  fixture_id text not null,\n  league_code text,\n  league_name text not null,\n  season integer,\n  kickoff_at timestamptz not null,\n  home_id text not null,\n  home_name text not null,\n  away_id text not null,\n  away_name text not null,\n  home_goals integer not null check (home_goals >= 0),\n  away_goals integer not null check (away_goals >= 0),\n  regulation_time boolean not null default true,\n  provider_updated_at timestamptz,\n  ingested_at timestamptz not null default now(),\n  primary key (provider, fixture_id),\n  check (home_id <> away_id)\n);\ncreate index if not exists historical_match_results_league_time_idx\n  on historical_match_results (league_code, kickoff_at desc);\ncreate index if not exists historical_match_results_team_time_idx\n  on historical_match_results (home_id, away_id, kickoff_at desc);\n\ncreate table if not exists lineup_observations (\n  id bigserial primary key,\n  match_id text not null,\n  provider text not null,\n  provider_match_id text,\n  status text not null check (status in ('confirmed', 'not-announced', 'coverage-unavailable', 'identity-unverified', 'provider-error')),\n  kickoff_at timestamptz not null,\n  observed_at timestamptz not null default now(),\n  payload jsonb not null default '{}'::jsonb,\n  unique (match_id, provider, observed_at)\n);\ncreate index if not exists lineup_observations_latest_idx\n  on lineup_observations (match_id, observed_at desc);\n\ncreate table if not exists odds_observations (\n  id bigserial primary key,\n  match_id text not null,\n  provider text not null,\n  event_id text not null,\n  bookmaker_key text not null,\n  bookmaker_name text not null,\n  market text not null check (market = 'h2h'),\n  kickoff_at timestamptz not null,\n  captured_at timestamptz not null default now(),\n  provider_updated_at timestamptz,\n  home_odds double precision not null check (home_odds > 1),\n  draw_odds double precision not null check (draw_odds > 1),\n  away_odds double precision not null check (away_odds > 1),\n  unique (match_id, provider, event_id, bookmaker_key, market, captured_at)\n);\ncreate index if not exists odds_observations_match_time_idx\n  on odds_observations (match_id, captured_at desc);\n\ncreate table if not exists weather_observations (\n  id bigserial primary key,\n  match_id text not null,\n  provider text not null default 'open-meteo',\n  latitude double precision not null check (latitude between -90 and 90),\n  longitude double precision not null check (longitude between -180 and 180),\n  observed_at timestamptz not null default now(),\n  valid_at timestamptz not null,\n  variables jsonb not null,\n  unique (match_id, provider, valid_at, observed_at)\n);\ncreate index if not exists weather_observations_match_time_idx\n  on weather_observations (match_id, valid_at desc);\n\ncreate table if not exists standings_observations (\n  id bigserial primary key,\n  match_id text not null,\n  provider text not null,\n  league_id text not null,\n  team_id text not null,\n  season integer not null,\n  observed_at timestamptz not null default now(),\n  position integer,\n  points integer,\n  played integer,\n  games_left integer,\n  unique (match_id, provider, team_id, observed_at)\n);\ncreate index if not exists standings_observations_latest_idx\n  on standings_observations (match_id, observed_at desc);\n\nalter table prediction_log\n  add column if not exists source_snapshot jsonb not null default '{}'::jsonb;\n\n-- A forecast's model inputs and probabilities are immutable after insertion.\n-- The result section can be filled once, only while the row is unsettled.\ncreate or replace function protect_prediction_log_update() returns trigger as $$\nbegin\n  if row(\n    new.match_id, new.home, new.away, new.league, new.kickoff_at, new.recorded_at,\n    new.model_version, new.input_hash, new.engine_home, new.engine_draw, new.engine_away,\n    new.ai_home, new.ai_draw, new.ai_away, new.final_home, new.final_draw, new.final_away,\n    new.pick, new.code, new.tier, new.source_snapshot\n  ) is distinct from row(\n    old.match_id, old.home, old.away, old.league, old.kickoff_at, old.recorded_at,\n    old.model_version, old.input_hash, old.engine_home, old.engine_draw, old.engine_away,\n    old.ai_home, old.ai_draw, old.ai_away, old.final_home, old.final_draw, old.final_away,\n    old.pick, old.code, old.tier, old.source_snapshot\n  ) then\n    raise exception 'prediction forecast columns are immutable';\n  end if;\n  if old.result is not null and row(new.result, new.home_goals, new.away_goals, new.settled_at, new.result_source)\n       is distinct from row(old.result, old.home_goals, old.away_goals, old.settled_at, old.result_source) then\n    raise exception 'settled prediction result is immutable';\n  end if;\n  if old.result is null and new.result is null and row(new.home_goals, new.away_goals, new.settled_at, new.result_source)\n       is distinct from row(old.home_goals, old.away_goals, old.settled_at, old.result_source) then\n    raise exception 'result fields may only be written when settling';\n  end if;\n  return new;\nend;\n$$ language plpgsql;\n\ndrop trigger if exists prediction_log_immutable_update on prediction_log;\ncreate trigger prediction_log_immutable_update\nbefore update on prediction_log\nfor each row execute function protect_prediction_log_update();\n";
var _0006_operations_default = "create table if not exists provider_configs (\n  provider text primary key,\n  enabled boolean not null default false,\n  display_name text not null,\n  league_map jsonb not null default '{}'::jsonb,\n  refresh_seconds integer not null default 300 check (refresh_seconds between 30 and 86400),\n  settings jsonb not null default '{}'::jsonb,\n  updated_by text,\n  updated_at timestamptz not null default now()\n);\n\ncreate table if not exists job_runs (\n  id bigserial primary key,\n  job_type text not null check (job_type in ('fixture-sync','odds-snapshot','prediction-refresh','result-settlement','ai-analysis')),\n  status text not null check (status in ('queued','running','succeeded','failed')),\n  provider text,\n  started_at timestamptz,\n  finished_at timestamptz,\n  rows_affected integer not null default 0,\n  error_code text,\n  created_at timestamptz not null default now()\n);\ncreate index if not exists job_runs_type_time_idx on job_runs (job_type, created_at desc);\n\ncreate table if not exists admin_audit_events (\n  id bigserial primary key,\n  actor_id text not null,\n  action text not null,\n  target text not null,\n  metadata jsonb not null default '{}'::jsonb,\n  created_at timestamptz not null default now()\n);\ncreate index if not exists admin_audit_events_time_idx on admin_audit_events (created_at desc);\n\ninsert into provider_configs (provider, enabled, display_name)\nvalues\n  ('manus-ai', true, 'Manus AI'),\n  ('odds-api', false, 'The Odds API'),\n  ('api-football', false, 'API-Football'),\n  ('football-data', false, 'Football-Data.org'),\n  ('betika-authorized', false, 'Betika authorized feed'),\n  ('sportpesa-authorized', false, 'SportPesa authorized feed'),\n  ('1xbet-authorized', false, '1xBet authorized feed')\non conflict (provider) do nothing;\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var db_exports = /* @__PURE__ */ __exportAll({
	checkDatabaseHealth: () => checkDatabaseHealth,
	dbSource: () => dbSource,
	ensureDbReady: () => ensureDbReady,
	getPglite: () => getPglite,
	getSql: () => getSql
});
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.SUPABASE_DATABASE_URL || process.env.POSTGRES_URL || process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: Supabase when its URL is supplied, otherwise configured Postgres
* (for example the Vercel/Neon integration). PGLite is development-only; a
* production deployment without a hosted URL remains usable but has no durable log.
*/
var dbSource = !databaseUrl ? typeof process !== "undefined" && true ? "unconfigured" : "pglite" : typeof process !== "undefined" && !!process.env.SUPABASE_DATABASE_URL?.trim() ? "supabase" : databaseUrl.includes("supabase") ? "supabase" : "postgres";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.n);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({
			connectionString: databaseUrl,
			max: 1,
			connectionTimeoutMillis: 1e4
		});
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({
			"/migrations/0002_desk.sql": _0002_desk_default,
			"/migrations/0003_results.sql": _0003_results_default,
			"/migrations/0004_prediction_log.sql": _0004_prediction_log_default,
			"/migrations/0005_multi_source_analysis.sql": _0005_multi_source_analysis_default,
			"/migrations/0006_operations.sql": _0006_operations_default
		});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	if (dbSource === "unconfigured") throw new Error("Set SUPABASE_DATABASE_URL or DATABASE_URL to enable durable server-side storage.");
	return dbSource === "pglite" ? createPgliteSql() : createNeonSql();
}
/**
* Get the shared, **server-only** SQL client. Hosted Postgres when configured;
* PGLite is used only during local development. Memoized — safe per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/** Public-safe health metadata; never returns the URL or a driver error message. */
async function checkDatabaseHealth() {
	const checkedAt = (/* @__PURE__ */ new Date()).toISOString();
	const started = Date.now();
	if (dbSource === "unconfigured") return {
		provider: dbSource,
		configured: false,
		durable: false,
		connected: false,
		checkedAt,
		latencyMs: null,
		note: "No hosted database URL is set. Configure SUPABASE_DATABASE_URL in Vercel to enable durable forecast logs."
	};
	try {
		const rows = await (await getSql()).query("select 1 as ok");
		return {
			provider: dbSource,
			configured: dbSource !== "pglite",
			durable: dbSource !== "pglite",
			connected: rows[0]?.ok === 1,
			checkedAt,
			latencyMs: Date.now() - started,
			note: dbSource === "pglite" ? "Preview-only in-memory database; data is not durable." : "Server-side Postgres connection is responding."
		};
	} catch {
		return {
			provider: dbSource,
			configured: dbSource !== "pglite",
			durable: dbSource !== "pglite",
			connected: false,
			checkedAt,
			latencyMs: null,
			note: dbSource === "pglite" ? "Local preview database did not respond." : "Postgres connection failed; verify the server-side URL and network settings."
		};
	}
}
/**
* The shared local-development PGLite instance, with `migrations/*.sql` applied.
* Throws when a hosted database is selected.
*/
async function getPglite() {
	if (dbSource !== "pglite") throw new Error("getPglite() is only available when no Postgres URL is configured");
	await getSql();
	const pg = await globalRef.__pgliteInstance__;
	if (!pg) throw new Error("PGLite instance failed to initialize");
	return pg;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (local development only): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
//#endregion
export { getSql as a, getPglite as i, db_exports as n, ensureDbReady as r, checkDatabaseHealth as t };
