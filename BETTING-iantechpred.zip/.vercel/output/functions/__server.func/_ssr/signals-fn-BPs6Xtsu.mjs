import { S as findAny, l as RECENT, n as KICKOFF_ISO, u as actualSide } from "./price-D3Ht-t88.mjs";
import { d as runBacktest, i as buildConsensus } from "./backtest-DeRv33Nh.mjs";
import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signals-fn-BPs6Xtsu.js
var getMatchSignals_createServerFn_handler = createServerRpc({
	id: "0af0fc41459e674fabd285222dfb4c3a692db7590fd2dc0efc8cec9c3a416062",
	name: "getMatchSignals",
	filename: "src/lib/signals-fn.ts"
}, (opts) => getMatchSignals.__executeServer(opts));
var getMatchSignals = createServerFn({ method: "GET" }).validator((id) => {
	if (typeof id !== "string" || id.length > 80 || !/^[a-z0-9-]+$/i.test(id)) throw new Error("Invalid fixture ID");
	return id;
}).handler(getMatchSignals_createServerFn_handler, async ({ data: id }) => {
	const match = findAny(id);
	if (!match) return { used: [] };
	const { buildSignals } = await import("./signals.server-BL3m_YjG.mjs");
	const base = buildConsensus(match.home, match.away).probabilities;
	return buildSignals(match.home.name, match.away.name, base, {
		id: match.id,
		home: match.home.name,
		away: match.away.name,
		league: match.league,
		venue: match.venue,
		kickoffAt: KICKOFF_ISO[match.id] ?? null
	});
});
var getProviderStatus_createServerFn_handler = createServerRpc({
	id: "8f90fff7fcbefdb2522c142f480e92366b88036b2f4dc494b49068559f1b830c",
	name: "getProviderStatus",
	filename: "src/lib/signals-fn.ts"
}, (opts) => getProviderStatus.__executeServer(opts));
var getProviderStatus = createServerFn({ method: "GET" }).handler(getProviderStatus_createServerFn_handler, async () => {
	const { env } = await import("./env.server-B4a86VpI.mjs").then((n) => n.n);
	return {
		odds: !!env("ODDS_API_KEY"),
		apiFootball: !!env("API_FOOTBALL_KEY"),
		footballData: !!env("FOOTBALL_DATA_KEY"),
		ai: !!env("GEMINI_API_KEY")
	};
});
var getPredictionLearningHistory_createServerFn_handler = createServerRpc({
	id: "b5b14acc5da9f5326c04d72a67a8be0b061cbc72fafc8bd73bbd3ea577c5bb83",
	name: "getPredictionLearningHistory",
	filename: "src/lib/signals-fn.ts"
}, (opts) => getPredictionLearningHistory.__executeServer(opts));
var getPredictionLearningHistory = createServerFn({ method: "GET" }).handler(getPredictionLearningHistory_createServerFn_handler, async () => {
	try {
		const { getSql, ensureDbReady } = await import("./db-DcaGEQZG.mjs").then((n) => n.n);
		const { MODEL_VERSION } = await import("./tracker-B_iIlhXn.mjs").then((n) => n.c);
		await ensureDbReady();
		const rows = await (await getSql())`
      select engine_home, engine_draw, engine_away, ai_home, ai_draw, ai_away,
             final_home, final_draw, final_away, league, result, recorded_at, kickoff_at
      from prediction_log
      where result is not null and recorded_at < kickoff_at and model_version = ${MODEL_VERSION}
      order by kickoff_at desc limit 100
    `;
		const asTriple = (r, prefix) => ({
			home: Number(r[`${prefix}_home`]),
			draw: Number(r[`${prefix}_draw`]),
			away: Number(r[`${prefix}_away`])
		});
		const asIso = (value) => new Date(value).toISOString();
		return rows.reverse().map((r) => ({
			engine: asTriple(r, "engine"),
			ai: asTriple(r, "ai"),
			final: asTriple(r, "final"),
			result: r.result,
			league: String(r.league),
			recordedAt: asIso(r.recorded_at),
			kickoffAt: asIso(r.kickoff_at)
		}));
	} catch {
		return [];
	}
});
var settleKnownResults_createServerFn_handler = createServerRpc({
	id: "c70ece561479a999463b28b8cf398882c90b0e011efa77dc05ad8e73d779e73d",
	name: "settleKnownResults",
	filename: "src/lib/signals-fn.ts"
}, (opts) => settleKnownResults.__executeServer(opts));
var settleKnownResults = createServerFn({ method: "POST" }).handler(settleKnownResults_createServerFn_handler, async () => {
	const { getSql, ensureDbReady, checkDatabaseHealth } = await import("./db-DcaGEQZG.mjs").then((n) => n.n);
	if (!(await checkDatabaseHealth()).connected) return [];
	await ensureDbReady();
	const sql = await getSql();
	for (const m of RECENT) {
		const c = buildConsensus(m.home, m.away);
		await sql`insert into settled_results (match_id, engine_home, engine_draw, engine_away, ai_home, ai_draw, ai_away, result)
      values (${m.id}, ${c.engineProbs.home}, ${c.engineProbs.draw}, ${c.engineProbs.away}, ${c.aiProbs.home}, ${c.aiProbs.draw}, ${c.aiProbs.away}, ${actualSide(m)})
      on conflict (match_id) do nothing`;
	}
	return (await sql`select * from settled_results order by settled_at desc limit 100`).reverse().map((r) => ({
		engine: {
			home: Number(r.engine_home),
			draw: Number(r.engine_draw),
			away: Number(r.engine_away)
		},
		ai: {
			home: Number(r.ai_home),
			draw: Number(r.ai_draw),
			away: Number(r.ai_away)
		},
		result: r.result
	}));
});
var getBacktest_createServerFn_handler = createServerRpc({
	id: "5cf53b12df380c39c243a2a658e745198ff738c87727b2219dc2a13bd44e135f",
	name: "getBacktest",
	filename: "src/lib/signals-fn.ts"
}, (opts) => getBacktest.__executeServer(opts));
var getBacktest = createServerFn({ method: "GET" }).handler(getBacktest_createServerFn_handler, async () => {
	const { getSql, ensureDbReady, checkDatabaseHealth } = await import("./db-DcaGEQZG.mjs").then((n) => n.n);
	if (!(await checkDatabaseHealth()).connected) return runBacktest([]);
	await ensureDbReady();
	const sql = await getSql();
	for (const m of RECENT) {
		const c = buildConsensus(m.home, m.away);
		await sql`insert into settled_results (match_id, engine_home, engine_draw, engine_away, ai_home, ai_draw, ai_away, result)
      values (${m.id}, ${c.engineProbs.home}, ${c.engineProbs.draw}, ${c.engineProbs.away}, ${c.aiProbs.home}, ${c.aiProbs.draw}, ${c.aiProbs.away}, ${actualSide(m)})
      on conflict (match_id) do nothing`;
	}
	const rows = await sql`select * from settled_results order by settled_at asc`;
	return runBacktest(rows.map((r) => ({
		id: String(r.match_id),
		engine: {
			home: Number(r.engine_home),
			draw: Number(r.engine_draw),
			away: Number(r.engine_away)
		},
		ai: {
			home: Number(r.ai_home),
			draw: Number(r.ai_draw),
			away: Number(r.ai_away)
		},
		result: r.result
	})));
});
//#endregion
export { getBacktest_createServerFn_handler, getMatchSignals_createServerFn_handler, getPredictionLearningHistory_createServerFn_handler, getProviderStatus_createServerFn_handler, settleKnownResults_createServerFn_handler };
