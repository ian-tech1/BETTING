import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
import { a as stableFixtureId, i as sameTeam, r as parseBetikaKickoff } from "./jackpot-utils-2-SdMduq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/jackpot-live-DwHGRFkZ.js
var BETIKA = [
	{
		home: "Paderborn",
		away: "Eintracht"
	},
	{
		home: "Fulham",
		away: "Newcastle"
	},
	{
		home: "Espanyol",
		away: "Deportivo"
	},
	{
		home: "Auxerre",
		away: "Paris FC"
	},
	{
		home: "Osasuna",
		away: "Athletic Club"
	},
	{
		home: "Napoli",
		away: "Lazio"
	},
	{
		home: "Elche",
		away: "Betis"
	},
	{
		home: "Sunderland",
		away: "Chelsea"
	},
	{
		home: "Rennes",
		away: "Lille"
	},
	{
		home: "Monza",
		away: "Atalanta"
	},
	{
		home: "Le Havre",
		away: "Lorient"
	},
	{
		home: "Angers",
		away: "Nice"
	},
	{
		home: "Brest",
		away: "Lyon"
	},
	{
		home: "Man Utd",
		away: "Aston Villa"
	},
	{
		home: "Lens",
		away: "Marseille"
	}
];
var SPORTPESA_JACKPOT_URL = "https://jackpot-offer-api.sportpesa.com/api/jackpots/active";
var BETIKA_MATCH_URL = "https://api.betika.com/v1/uo/matches";
var XBET_PUBLIC_PAGE = "https://1xbet.com/en/line/football";
var MAX_BETIKA_FIXTURE_AGE_MS = 2592e6;
async function searchBetika(home = "") {
	try {
		const url = new URL(BETIKA_MATCH_URL);
		url.search = new URLSearchParams({
			page: "1",
			limit: "50",
			sport_id: "14",
			keyword: home
		}).toString();
		const response = await fetch(url, {
			headers: { Accept: "application/json" },
			signal: AbortSignal.timeout(8e3)
		});
		if (!response.ok) return [];
		const body = await response.json();
		return Array.isArray(body.data) ? body.data : [];
	} catch {
		return [];
	}
}
function eligibleBetikaRow(row, want, now) {
	const home = row.home_team?.trim() ?? "";
	const away = row.away_team?.trim() ?? "";
	if (!home || !away || row.is_esport || row.is_srl || /women|wfc|esport|srl/i.test(`${home} ${away}`) || !sameTeam(home, want.home) || !sameTeam(away, want.away)) return null;
	const kickoff = row.start_time ? parseBetikaKickoff(row.start_time) : null;
	if (kickoff === null || kickoff < now || kickoff - now > MAX_BETIKA_FIXTURE_AGE_MS) return null;
	const odds = {
		home: Number(row.home_odd),
		draw: Number(row.neutral_odd),
		away: Number(row.away_odd)
	};
	if (!Object.values(odds).every((odd) => Number.isFinite(odd) && odd > 1.01 && odd <= 100)) return null;
	return {
		home,
		away,
		kickoff,
		odds
	};
}
function eligibleAnyBetikaRow(row, now) {
	const home = row.home_team?.trim() ?? "";
	const away = row.away_team?.trim() ?? "";
	const kickoff = row.start_time ? parseBetikaKickoff(row.start_time) : null;
	if (!home || !away || row.is_esport || row.is_srl || /women|wfc|esport|srl/i.test(`${home} ${away}`)) return null;
	if (kickoff === null || kickoff < now || kickoff - now > MAX_BETIKA_FIXTURE_AGE_MS) return null;
	const odds = {
		home: Number(row.home_odd),
		draw: Number(row.neutral_odd),
		away: Number(row.away_odd)
	};
	if (!Object.values(odds).every((odd) => Number.isFinite(odd) && odd > 1.01 && odd <= 100)) return null;
	return {
		home,
		away,
		kickoff,
		odds
	};
}
async function loadBetika() {
	let cursor = 0;
	const accepted = /* @__PURE__ */ new Map();
	const now = Date.now();
	const allRows = await searchBetika("");
	for (const row of allRows) {
		const match = eligibleAnyBetikaRow(row, now);
		if (!match) continue;
		const kickoff = new Date(match.kickoff).toISOString();
		const id = stableFixtureId("betika", match.home, match.away, kickoff);
		accepted.set(id, {
			id,
			league: row.competition_name ?? "Competition unavailable",
			when: formatKickoff(match.kickoff),
			kickoff,
			home: match.home,
			away: match.away,
			odds: match.odds,
			found: true
		});
	}
	const worker = async () => {
		while (cursor < BETIKA.length) {
			const want = BETIKA[cursor++];
			const selected = (await searchBetika(want.home)).map((row) => ({
				row,
				match: eligibleBetikaRow(row, want, now)
			})).filter((item) => item.match !== null).sort((left, right) => left.match.kickoff - right.match.kickoff)[0];
			if (!selected) continue;
			const { row, match } = selected;
			const kickoff = new Date(match.kickoff).toISOString();
			const id = stableFixtureId("betika", match.home, match.away, kickoff);
			accepted.set(id, {
				id,
				league: row.competition_name ?? "Competition unavailable",
				when: formatKickoff(match.kickoff),
				kickoff,
				home: match.home,
				away: match.away,
				odds: match.odds,
				found: true
			});
		}
	};
	await Promise.all(Array.from({ length: 4 }, worker));
	const games = [...accepted.values()].sort((left, right) => Date.parse(left.kickoff ?? "") - Date.parse(right.kickoff ?? ""));
	return {
		games,
		status: games.length ? `Betika public feed returned ${games.length} real upcoming football games with valid 1X2 odds. Past, women’s, esports, and ambiguous rows are hidden.` : "Betika returned no exact upcoming team-and-kickoff quotes for this tracked card; no saved or simulated prices are substituted."
	};
}
async function loadSportpesa() {
	try {
		const response = await fetch(SPORTPESA_JACKPOT_URL, {
			headers: { Accept: "application/json" },
			signal: AbortSignal.timeout(8e3)
		});
		if (!response.ok) return {
			games: [],
			status: `SportPesa's official public jackpot feed is unavailable from this server (HTTP ${response.status}); no quote is shown. Use a manually transcribed price from the SportPesa app if needed.`
		};
		const body = await response.json();
		const accepted = /* @__PURE__ */ new Map();
		for (const event of body.events ?? []) {
			const competitors = event.competitors ?? [];
			const homeSides = competitors.filter((side) => side.isHome === true && side.competitorName?.trim());
			const awaySides = competitors.filter((side) => side.isHome === false && side.competitorName?.trim());
			if (homeSides.length !== 1 || awaySides.length !== 1) continue;
			const home = homeSides[0].competitorName.trim();
			const away = awaySides[0].competitorName.trim();
			const kickoffMs = event.utcKickOffTime ? Date.parse(event.utcKickOffTime) : NaN;
			const odds = {
				home: Number(event.home),
				draw: Number(event.draw),
				away: Number(event.away)
			};
			if (!Number.isFinite(kickoffMs) || kickoffMs <= Date.now() || !Object.values(odds).every((odd) => Number.isFinite(odd) && odd > 1.01 && odd <= 100)) continue;
			const kickoff = new Date(kickoffMs).toISOString();
			const id = stableFixtureId("sportpesa", home, away, kickoff);
			accepted.set(id, {
				id,
				league: event.tournamentName ?? "Competition unavailable",
				when: formatKickoff(kickoffMs),
				kickoff,
				home,
				away,
				odds,
				found: true
			});
		}
		const games = [...accepted.values()].sort((left, right) => Date.parse(left.kickoff ?? "") - Date.parse(right.kickoff ?? ""));
		return {
			games,
			status: games.length ? `SportPesa official feed returned ${games.length} upcoming 1X2 quotes. Team order is taken only from explicit home/away flags.` : "SportPesa returned no valid upcoming 1X2 quotes with explicit home/away labels. No comparison or demo price is presented as its official price."
		};
	} catch {
		return {
			games: [],
			status: "SportPesa's official public jackpot feed request failed; no cached odds are shown. You can enter the prices shown in its app manually."
		};
	}
}
/** Read the public page only; do not fetch hidden app endpoints or bypass a gate. */
async function checkXbetPublicPage() {
	try {
		const response = await fetch(XBET_PUBLIC_PAGE, {
			headers: { Accept: "text/html" },
			redirect: "follow",
			signal: AbortSignal.timeout(8e3)
		});
		if (!response.ok) return {
			games: [],
			status: `1xBet public page returned HTTP ${response.status}; no quotes are shown.`
		};
		const html = await response.text();
		const title = html.match(/<title[^>]*>(.*?)<\/title>/is)?.[1]?.replace(/\s+/g, " ").trim() ?? "";
		if (/captcha|access denied|country.{0,30}(?:blocked|restricted)|vpn/i.test(html)) return {
			games: [],
			status: "1xBet public page is gated in this runtime; no odds are shown."
		};
		if (!/\b1x2\b/i.test(html) || !/\b(?:home|draw|away)\b/i.test(html)) return {
			games: [],
			status: title ? "1xBet page loaded, but the public HTML contains no readable 1X2 prices." : "1xBet public page did not expose readable event odds."
		};
		return {
			games: [],
			status: "1xBet page text is present, but its public markup does not provide a safely matchable 1X2 feed."
		};
	} catch {
		return {
			games: [],
			status: "1xBet public page could not be reached; no quotes are shown."
		};
	}
}
var refreshJackpot_createServerFn_handler = createServerRpc({
	id: "a3d9059c842e62f8323454b137a7bcc53e3132d66db2cc8efa5a8631699a19e4",
	name: "refreshJackpot",
	filename: "src/lib/jackpot-live.ts"
}, (opts) => refreshJackpot.__executeServer(opts));
var refreshJackpot = createServerFn({ method: "GET" }).handler(refreshJackpot_createServerFn_handler, async () => {
	const [betika, sportpesa, xbet, eventResponse] = await Promise.all([
		loadBetika(),
		loadSportpesa(),
		checkXbetPublicPage(),
		fetch("https://api.betika.com/v1/jackpot/events", {
			headers: { Accept: "application/json" },
			signal: AbortSignal.timeout(8e3)
		}).catch(() => null)
	]);
	let prize = "";
	let expiry = "";
	if (eventResponse?.ok) {
		const events = await eventResponse.json();
		const active = events.find((event) => event.status === "ACTIVE") ?? events[0];
		prize = active?.prize ? `KES ${Number(active.prize).toLocaleString("en-KE")}` : "";
		expiry = active?.event_expiry ?? "";
	}
	return {
		checked: (/* @__PURE__ */ new Date()).toISOString(),
		prize,
		expiry,
		betika: betika.games,
		betikaStatus: betika.status,
		sportpesa: sportpesa.games,
		sportpesaStatus: sportpesa.status,
		xbet: xbet.games,
		xbetStatus: xbet.status
	};
});
function formatKickoff(timestamp) {
	return new Intl.DateTimeFormat("en-KE", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23",
		timeZone: "Africa/Nairobi"
	}).format(new Date(timestamp));
}
//#endregion
export { refreshJackpot_createServerFn_handler };
