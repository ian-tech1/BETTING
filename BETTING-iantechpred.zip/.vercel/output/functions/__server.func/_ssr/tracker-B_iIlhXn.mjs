import { t as __exportAll } from "./rolldown-runtime-D7D4PA-g.mjs";
import { u as perLeagueAccuracy } from "./analysis-Cbzgc3mb.mjs";
import { d as runBacktest, f as score } from "./backtest-DeRv33Nh.mjs";
import { i as sameTeam } from "./jackpot-utils-2-SdMduq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tracker-B_iIlhXn.js
var tracker_exports = /* @__PURE__ */ __exportAll({
	MODEL_VERSION: () => MODEL_VERSION,
	SIDES: () => SIDES,
	bucket: () => bucket,
	buildDashboard: () => buildDashboard,
	canRecord: () => canRecord,
	csvCell: () => csvCell,
	isPreMatch: () => isPreMatch,
	outcomeReport: () => outcomeReport,
	pairResult: () => pairResult,
	rollingBrier: () => rollingBrier,
	tipCovered: () => tipCovered,
	toCsv: () => toCsv,
	topCorrect: () => topCorrect,
	trend: () => trend
});
var SIDES = [
	"home",
	"draw",
	"away"
];
/** Bump when the forecasting logic changes so old and new versions can be scored separately. */
var MODEL_VERSION = "2026-11-b-multisource";
var ms = (iso) => Date.parse(iso);
/** A forecast may only be recorded while the kickoff is known and still in the future (server clock). */
function canRecord(nowMs, kickoffMs) {
	if (kickoffMs === null || !Number.isFinite(kickoffMs)) return {
		ok: false,
		reason: "no verified kickoff time"
	};
	if (nowMs >= kickoffMs) return {
		ok: false,
		reason: "kickoff already passed"
	};
	return {
		ok: true,
		reason: ""
	};
}
/** Counted only if it was recorded strictly before kickoff. */
var isPreMatch = (r) => ms(r.recordedAt) < ms(r.kickoffAt);
/** Matches a finished fixture from a results feed to a logged forecast: same teams in the same order, within 36 hours of kickoff. */
function pairResult(row, feed) {
	if (!sameTeam(row.home, feed.home) || !sameTeam(row.away, feed.away)) return null;
	const gap = Math.abs(ms(feed.utcDate) - ms(row.kickoffAt));
	if (!Number.isFinite(gap) || gap > 1296e5) return null;
	if (!Number.isInteger(feed.homeGoals) || !Number.isInteger(feed.awayGoals) || feed.homeGoals < 0 || feed.awayGoals < 0) return null;
	return feed.homeGoals > feed.awayGoals ? "home" : feed.homeGoals < feed.awayGoals ? "away" : "draw";
}
function bucket(rows) {
	const out = {
		pending: [],
		settled: [],
		excluded: []
	};
	for (const r of rows) if (!isPreMatch(r)) out.excluded.push(r);
	else if (r.result) out.settled.push(r);
	else out.pending.push(r);
	out.settled.sort((a, b) => ms(a.kickoffAt) - ms(b.kickoffAt));
	out.pending.sort((a, b) => ms(a.kickoffAt) - ms(b.kickoffAt));
	return out;
}
var SYMBOL = {
	home: "1",
	draw: "X",
	away: "2"
};
/** Did the published tip (single or double chance) cover the real result? null when the tip was PASS. */
var tipCovered = (r) => r.code === "PASS" || !r.result ? null : r.code.includes(SYMBOL[r.result]);
/** Was the single most likely outcome right? */
var topCorrect = (r) => r.result ? r.pick === r.result : null;
function outcomeReport(settled) {
	const correct = settled.filter((r) => topCorrect(r) === true);
	const incorrect = settled.filter((r) => topCorrect(r) === false);
	const tips = settled.map(tipCovered).filter((x) => x !== null);
	return {
		correct,
		incorrect,
		confidentMisses: incorrect.filter((r) => r.final[r.pick] >= .6),
		tipHits: tips.filter(Boolean).length,
		tipsMade: tips.length,
		passes: settled.length - tips.length
	};
}
var brierOf = (r) => SIDES.reduce((s, k) => s + (r.final[k] - (r.result === k ? 1 : 0)) ** 2, 0);
function rollingBrier(settled, window = 20) {
	const out = [];
	for (let i = window; i <= settled.length; i++) {
		const slice = settled.slice(i - window, i);
		out.push({
			upTo: i,
			brier: slice.reduce((s, r) => s + brierOf(r), 0) / window
		});
	}
	return out;
}
/** Compares the earlier half with the later half. Needs enough matches, and a real gap, before it says anything. */
function trend(settled) {
	if (settled.length < 50) return {
		verdict: "too-early",
		early: NaN,
		late: NaN,
		text: `Needs at least 50 settled matches before a trend means anything (have ${settled.length}).`
	};
	const mid = Math.floor(settled.length / 2);
	const avg = (xs) => xs.reduce((s, r) => s + brierOf(r), 0) / xs.length;
	const early = avg(settled.slice(0, mid));
	const late = avg(settled.slice(mid));
	const delta = early - late;
	const verdict = delta > .015 ? "improving" : delta < -.015 ? "worsening" : "flat";
	return {
		verdict,
		early,
		late,
		text: verdict === "improving" ? `Brier fell from ${early.toFixed(3)} to ${late.toFixed(3)} between the earlier and later half. Small samples can still be luck.` : verdict === "worsening" ? `Brier rose from ${early.toFixed(3)} to ${late.toFixed(3)} between the earlier and later half.` : `No meaningful change between the earlier half (${early.toFixed(3)}) and later half (${late.toFixed(3)}).`
	};
}
function buildDashboard(rows) {
	const b = bucket(rows);
	const report = runBacktest(b.settled.map((r) => ({
		id: r.matchId,
		engine: r.engine,
		ai: r.ai,
		final: r.final,
		tier: r.tier,
		result: r.result
	})));
	const versions = [...new Set(b.settled.map((r) => r.modelVersion))];
	const lead = rows.length ? rows.reduce((s, r) => s + (ms(r.kickoffAt) - ms(r.recordedAt)), 0) / rows.length / 36e5 : NaN;
	return {
		counts: {
			recorded: rows.length,
			pending: b.pending.length,
			settled: b.settled.length,
			excluded: b.excluded.length
		},
		report,
		outcomes: outcomeReport(b.settled),
		trend: trend(b.settled),
		rolling: rollingBrier(b.settled),
		byVersion: versions.map((v) => ({
			version: v,
			card: score(b.settled.filter((r) => r.modelVersion === v).map((r) => ({
				p: r.final,
				result: r.result
			})))
		})),
		byLeague: perLeagueAccuracy(b.settled.map((r) => ({
			league: r.league,
			final: r.final,
			result: r.result,
			recordedAt: r.recordedAt,
			kickoffAt: r.kickoffAt
		}))),
		buckets: b,
		avgLeadHours: lead
	};
}
var HEADER = [
	"match_id",
	"league",
	"home",
	"away",
	"kickoff_utc",
	"recorded_utc",
	"hours_before_kickoff",
	"status",
	"model_version",
	"input_hash",
	"engine_home",
	"engine_draw",
	"engine_away",
	"ai_home",
	"ai_draw",
	"ai_away",
	"final_home",
	"final_draw",
	"final_away",
	"pick",
	"tip_code",
	"tier",
	"result",
	"home_goals",
	"away_goals",
	"top_pick_correct",
	"tip_covered",
	"brier",
	"log_loss",
	"settled_utc",
	"result_source"
];
/** Spreadsheet-safe cell: quotes escaped, and a leading = + - @ is neutralised so a team name cannot run as a formula. */
function csvCell(v) {
	if (v === null || v === void 0) return "";
	let t = String(v);
	if (typeof v === "string" && /^[=+\-@\t\r]/.test(t)) t = `'${t}`;
	return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, "\"\"")}"` : t;
}
function toCsv(rows) {
	const f = (x) => Number(x.toFixed(4));
	const lines = [HEADER.join(",")];
	for (const r of rows) {
		const status = !isPreMatch(r) ? "excluded_recorded_after_kickoff" : r.result ? "settled" : "pending";
		const settled = !!r.result;
		lines.push([
			r.matchId,
			r.league,
			r.home,
			r.away,
			r.kickoffAt,
			r.recordedAt,
			Number(((ms(r.kickoffAt) - ms(r.recordedAt)) / 36e5).toFixed(2)),
			status,
			r.modelVersion,
			r.inputHash,
			f(r.engine.home),
			f(r.engine.draw),
			f(r.engine.away),
			f(r.ai.home),
			f(r.ai.draw),
			f(r.ai.away),
			f(r.final.home),
			f(r.final.draw),
			f(r.final.away),
			r.pick,
			r.code,
			r.tier,
			r.result,
			r.homeGoals,
			r.awayGoals,
			settled ? topCorrect(r) : null,
			settled ? tipCovered(r) : null,
			settled ? f(brierOf(r)) : null,
			settled ? f(-Math.log(Math.max(r.final[r.result], 1e-9))) : null,
			r.settledAt,
			r.resultSource
		].map(csvCell).join(","));
	}
	return lines.join("\r\n") + "\r\n";
}
//#endregion
export { tipCovered as a, tracker_exports as c, pairResult as i, buildDashboard as n, toCsv as o, canRecord as r, topCorrect as s, MODEL_VERSION as t };
