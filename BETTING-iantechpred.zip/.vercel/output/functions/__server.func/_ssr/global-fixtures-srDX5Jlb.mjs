import { c as MATCHES, n as KICKOFF_ISO } from "./price-D3Ht-t88.mjs";
import { n as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CN-evIEF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/global-fixtures-srDX5Jlb.js
var COMPETITIONS = [
	{
		file: "en.1",
		code: "EPL",
		label: "English Premier League"
	},
	{
		file: "en.2",
		code: "CHP",
		label: "English Championship"
	},
	{
		file: "de.1",
		code: "BUN",
		label: "German Bundesliga"
	},
	{
		file: "es.1",
		code: "LAL",
		label: "Spanish La Liga"
	},
	{
		file: "fr.1",
		code: "FRA",
		label: "French Ligue 1"
	},
	{
		file: "it.1",
		code: "SEA",
		label: "Italian Serie A"
	},
	{
		file: "nl.1",
		code: "ERE",
		label: "Dutch Eredivisie"
	},
	{
		file: "pt.1",
		code: "POR",
		label: "Portuguese Primeira Liga"
	}
];
var ROOT = "https://raw.githubusercontent.com/openfootball/football.json/master";
var CACHE_MS = 108e5;
var cache;
function norm(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/\b(nott'?m forest|nottingham forest)\b/g, "nottinghamforest").replace(/\b(man city|manchester city)\b/g, "manchestercity").replace(/\b(bayern|bayern munich)\b/g, "bayernmunich").replace(/\b(tottenham hotspur|tottenham)\b/g, "tottenham").replace(/\b(fc|afc|cf|sc|the)\b/g, "").replace(/[^a-z0-9]/g, "");
}
function dayAfter(isoDate, days) {
	const date = /* @__PURE__ */ new Date(`${isoDate}T12:00:00Z`);
	date.setUTCDate(date.getUTCDate() + days);
	return date.toISOString().slice(0, 10);
}
function seasonFor(date) {
	const year = date.getUTCFullYear();
	const start = date.getUTCMonth() >= 6 ? year : year - 1;
	return `${start}-${String(start + 1).slice(-2)}`;
}
function existingKeys(year) {
	const entries = /* @__PURE__ */ new Map();
	for (const match of MATCHES) {
		const start = KICKOFF_ISO[match.id];
		const labelDate = match.dateLabel.match(/^(?:Mon|Tue|Wed|Thu|Fri|Sat|Sun)\s+(\d{1,2})\s+([A-Za-z]{3})$/i);
		const month = labelDate ? [
			"Jan",
			"Feb",
			"Mar",
			"Apr",
			"May",
			"Jun",
			"Jul",
			"Aug",
			"Sep",
			"Oct",
			"Nov",
			"Dec"
		].findIndex((name) => name.toLowerCase() === labelDate[2].toLowerCase()) : -1;
		const date = start?.slice(0, 10) ?? (labelDate && month >= 0 ? `${year}-${String(month + 1).padStart(2, "0")}-${labelDate[1].padStart(2, "0")}` : null);
		if (!date) continue;
		const key = `${match.code}:${date}`;
		const matches = entries.get(key) ?? [];
		matches.push({
			home: norm(match.home.name),
			away: norm(match.away.name)
		});
		entries.set(key, matches);
	}
	return entries;
}
function sameTeam(left, right) {
	return left === right || Math.min(left.length, right.length) >= 5 && (left.includes(right) || right.includes(left));
}
async function loadFeed() {
	const now = /* @__PURE__ */ new Date();
	const season = seasonFor(now);
	const from = now.toISOString().slice(0, 10);
	const through = dayAfter(from, 30);
	const existing = existingKeys(now.getUTCFullYear());
	const sourceByFile = /* @__PURE__ */ new Map();
	const unavailable = [];
	let nextIndex = 0;
	const worker = async () => {
		while (nextIndex < COMPETITIONS.length) {
			const competition = COMPETITIONS[nextIndex++];
			const sourceUrl = `${ROOT}/${season}/${competition.file}.json`;
			try {
				const response = await fetch(sourceUrl, {
					headers: { Accept: "application/json" },
					signal: AbortSignal.timeout(9e3)
				});
				if (!response.ok) {
					unavailable.push(`${competition.code}: source returned HTTP ${response.status}`);
					continue;
				}
				const data = await response.json();
				const rows = Array.isArray(data.matches) ? data.matches : [];
				const fixtures = [];
				for (const row of rows) {
					if (!row.date || row.date < from || row.date > through || row.score?.ft || !row.team1?.trim() || !row.team2?.trim()) continue;
					if ((existing.get(`${competition.code}:${row.date}`) ?? []).some((match) => sameTeam(match.home, norm(row.team1)) && sameTeam(match.away, norm(row.team2)))) continue;
					fixtures.push({
						id: `of-${competition.file}-${row.date}-${norm(row.team1)}-${norm(row.team2)}`,
						code: competition.code,
						competition: competition.label,
						date: row.date,
						home: row.team1.trim(),
						away: row.team2.trim(),
						round: row.round?.trim() || null,
						sourceUrl
					});
				}
				sourceByFile.set(competition.file, fixtures);
			} catch {
				unavailable.push(`${competition.code}: source could not be reached`);
			}
		}
	};
	await Promise.all(Array.from({ length: 4 }, () => worker()));
	const fixtures = [...sourceByFile.values()].flat().sort((a, b) => {
		return a.date.localeCompare(b.date) || a.competition.localeCompare(b.competition) || a.home.localeCompare(b.home);
	});
	const counts = /* @__PURE__ */ new Map();
	for (const fixture of fixtures) counts.set(fixture.code, (counts.get(fixture.code) ?? 0) + 1);
	return {
		season,
		from,
		through,
		checkedAt: (/* @__PURE__ */ new Date()).toISOString(),
		source: "https://github.com/openfootball/football.json",
		competitions: COMPETITIONS.map((competition) => ({
			code: competition.code,
			label: competition.label,
			count: counts.get(competition.code) ?? 0
		})),
		fixtures,
		unavailable
	};
}
var getExpandedFixtures_createServerFn_handler = createServerRpc({
	id: "56e124ef1242433c6b034641a2a420b6f8f976c8dfbf08293010f317e38ce3c6",
	name: "getExpandedFixtures",
	filename: "src/lib/global-fixtures.ts"
}, (opts) => getExpandedFixtures.__executeServer(opts));
var getExpandedFixtures = createServerFn({ method: "GET" }).handler(getExpandedFixtures_createServerFn_handler, async () => {
	if (cache && Date.now() - cache.at < CACHE_MS) return cache.feed;
	const feed = await loadFeed();
	if (feed.fixtures.length) cache = {
		at: Date.now(),
		feed
	};
	return feed;
});
//#endregion
export { getExpandedFixtures_createServerFn_handler };
