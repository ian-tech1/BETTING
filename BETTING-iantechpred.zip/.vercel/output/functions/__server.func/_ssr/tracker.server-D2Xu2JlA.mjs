import { i as closingLineComparison, l as oddsMovement } from "./analysis-Cbzgc3mb.mjs";
import { T as kickoffMs, c as MATCHES, n as KICKOFF_ISO } from "./price-D3Ht-t88.mjs";
import { i as buildConsensus } from "./backtest-DeRv33Nh.mjs";
import { a as getSql, r as ensureDbReady } from "./db-DcaGEQZG.mjs";
import { t as env } from "./env.server-B4a86VpI.mjs";
import { i as pairResult, r as canRecord, t as MODEL_VERSION } from "./tracker-B_iIlhXn.mjs";
import { buildSignals } from "./signals.server-BL3m_YjG.mjs";
import { createHash } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/tracker.server-D2Xu2JlA.js
/** Server-only. Records forecasts before kickoff, then fills in results from a real results feed. */
var num = (v) => Number(v);
var iso = (v) => v === null || v === void 0 ? null : new Date(v).toISOString();
function toRow(r) {
	return {
		matchId: String(r.match_id),
		home: String(r.home),
		away: String(r.away),
		league: String(r.league),
		kickoffAt: iso(r.kickoff_at),
		recordedAt: iso(r.recorded_at),
		modelVersion: String(r.model_version),
		inputHash: String(r.input_hash),
		engine: {
			home: num(r.engine_home),
			draw: num(r.engine_draw),
			away: num(r.engine_away)
		},
		ai: {
			home: num(r.ai_home),
			draw: num(r.ai_draw),
			away: num(r.ai_away)
		},
		final: {
			home: num(r.final_home),
			draw: num(r.final_draw),
			away: num(r.final_away)
		},
		pick: r.pick,
		code: String(r.code),
		tier: r.tier,
		result: r.result ?? null,
		homeGoals: r.home_goals === null || r.home_goals === void 0 ? null : num(r.home_goals),
		awayGoals: r.away_goals === null || r.away_goals === void 0 ? null : num(r.away_goals),
		settledAt: iso(r.settled_at),
		resultSource: r.result_source ?? null,
		sourceSnapshot: r.source_snapshot && typeof r.source_snapshot === "object" ? r.source_snapshot : {}
	};
}
async function loadPredictions() {
	await ensureDbReady();
	return (await (await getSql())`select * from prediction_log order by kickoff_at asc`).map(toRow);
}
/**
* The database holds timestamped, app-observed odds only. A close proxy is emitted
* only when a source quote was updated within three hours of kickoff; it is not
* an official bookmaker close or the user's taken-price CLV.
*/
async function loadMarketBenchmarks(predictions) {
	if (!predictions.length) return [];
	const ids = [...new Set(predictions.map((row) => row.matchId))];
	const slots = ids.map((_, i) => `$${i + 1}`).join(",");
	const observations = await (await getSql()).query(`select match_id, bookmaker_key, captured_at, provider_updated_at, kickoff_at, home_odds, draw_odds, away_odds
     from odds_observations where provider = 'the-odds-api' and match_id in (${slots}) order by match_id, bookmaker_key, captured_at asc`, ids);
	const byMatch = /* @__PURE__ */ new Map();
	for (const row of observations) byMatch.set(String(row.match_id), [...byMatch.get(String(row.match_id)) ?? [], row]);
	const asDate = (value) => value ? new Date(value).toISOString() : null;
	const quote = (row) => ({
		home: Number(row.home_odds),
		draw: Number(row.draw_odds),
		away: Number(row.away_odds)
	});
	const median = (values) => {
		if (!values.length) return null;
		const sorted = [...values].sort((a, b) => a - b);
		const middle = Math.floor(sorted.length / 2);
		return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
	};
	return predictions.map((prediction) => {
		const rows = byMatch.get(prediction.matchId) ?? [];
		const books = /* @__PURE__ */ new Map();
		for (const row of rows) books.set(String(row.bookmaker_key), [...books.get(String(row.bookmaker_key)) ?? [], row]);
		const movements = [];
		const closeComparisons = [];
		let openingObservedAt = null;
		let latestObservedAt = null;
		for (const bookRows of books.values()) {
			if (!bookRows.length) continue;
			openingObservedAt ??= asDate(bookRows[0].captured_at);
			latestObservedAt = asDate(bookRows[bookRows.length - 1].captured_at);
			if (bookRows.length > 1) {
				const first = bookRows[0], last = bookRows[bookRows.length - 1];
				const firstUpdate = String(first.provider_updated_at ?? ""), lastUpdate = String(last.provider_updated_at ?? "");
				if (firstUpdate && lastUpdate && firstUpdate !== lastUpdate) {
					const shift = oddsMovement(quote(first), quote(last));
					if (shift) movements.push(shift);
				}
			}
			const kickoff = Date.parse(prediction.kickoffAt);
			const candidate = bookRows.filter((row) => {
				const captured = Date.parse(String(row.captured_at));
				const updated = Date.parse(String(row.provider_updated_at ?? ""));
				return Number.isFinite(kickoff) && Number.isFinite(captured) && Number.isFinite(updated) && captured < kickoff && updated < kickoff && kickoff - updated <= 108e5;
			}).at(-1);
			if (candidate) {
				const comparison = closingLineComparison(prediction.final, quote(candidate));
				if (comparison) closeComparisons.push({
					gap: comparison.probabilityGap,
					oddsGap: comparison.fairOddsGapPct,
					at: asDate(candidate.provider_updated_at) ?? asDate(candidate.captured_at)
				});
			}
		}
		const movement = movements.length ? {
			home: median(movements.map((m) => m.home)),
			draw: median(movements.map((m) => m.draw)),
			away: median(movements.map((m) => m.away))
		} : null;
		const closeProbabilityGap = median(closeComparisons.map((x) => x.gap));
		const closeFairOddsGapPct = median(closeComparisons.map((x) => x.oddsGap));
		const closeObservedAt = closeComparisons.map((x) => x.at).sort().at(-1) ?? null;
		return {
			matchId: prediction.matchId,
			snapshots: rows.length,
			bookmakers: books.size,
			openingObservedAt,
			latestObservedAt,
			movement,
			closeObservedAt,
			closeBooks: closeComparisons.length,
			closeProbabilityGap,
			closeFairOddsGapPct
		};
	});
}
/**
* Freezes a server-computed forecast with its safe feature/freshness snapshot. A client cannot supply probabilities or
* a timestamp; `on conflict do nothing` means neither the forecast nor its source snapshot is ever rewritten.
*/
async function recordUpcoming(nowMs = Date.now()) {
	await ensureDbReady();
	const sql = await getSql();
	const out = {
		recorded: 0,
		alreadyLogged: 0,
		skipped: {
			noKickoff: 0,
			passed: 0
		}
	};
	const previous = await loadPredictions();
	const existing = new Set(previous.map((row) => row.matchId));
	const history = previous.filter((r) => !!r.result && Date.parse(r.recordedAt) < Date.parse(r.kickoffAt)).map((r) => ({
		engine: r.engine,
		ai: r.ai,
		final: r.final,
		result: r.result,
		league: r.league,
		recordedAt: r.recordedAt,
		kickoffAt: r.kickoffAt
	}));
	for (const m of MATCHES) {
		const k = kickoffMs(m.id);
		if (!canRecord(nowMs, k).ok) {
			if (k === null) out.skipped.noKickoff++;
			else out.skipped.passed++;
			continue;
		}
		if (existing.has(m.id)) {
			out.alreadyLogged++;
			continue;
		}
		const kickoffAt = new Date(k).toISOString();
		const initial = buildConsensus(m.home, m.away, {
			history,
			league: m.league
		});
		let signals = {
			used: [],
			notes: ["Live signal request failed; freshness gate applies."],
			freshness: {
				status: "missing",
				action: "pass",
				ageHours: null,
				reasons: ["No timestamped required team-data source is available."]
			}
		};
		try {
			signals = await buildSignals(m.home.name, m.away.name, initial.probabilities, {
				id: m.id,
				home: m.home.name,
				away: m.away.name,
				league: m.league,
				venue: m.venue,
				kickoffAt: KICKOFF_ISO[m.id] ?? kickoffAt
			});
		} catch {}
		const c = buildConsensus(m.home, m.away, {
			history,
			league: m.league,
			signals
		});
		const sourceSnapshot = {
			observedAt: new Date(nowMs).toISOString(),
			used: signals.used,
			freshness: signals.freshness ?? null,
			featureStatus: signals.featureStatus ?? [],
			rest: signals.rest ?? null,
			venueSplit: signals.venueSplit ?? null,
			motivation: signals.motivation ?? null,
			lineups: signals.lineups ?? null,
			weather: signals.weather ?? null,
			oddsMovement: signals.oddsMovement ?? null,
			market: signals.market ?? null
		};
		const hash = createHash("sha256").update(JSON.stringify({
			v: MODEL_VERSION,
			home: m.home,
			away: m.away,
			sourceSnapshot
		})).digest("hex").slice(0, 16);
		if ((await sql`insert into prediction_log
      (match_id, home, away, league, kickoff_at, model_version, input_hash, source_snapshot,
       engine_home, engine_draw, engine_away, ai_home, ai_draw, ai_away, final_home, final_draw, final_away, pick, code, tier)
      values (${m.id}, ${m.home.name}, ${m.away.name}, ${m.league}, ${kickoffAt}, ${"2026-11-b-multisource"}, ${hash}, ${JSON.stringify(sourceSnapshot)},
       ${c.engineProbs.home}, ${c.engineProbs.draw}, ${c.engineProbs.away}, ${c.aiProbs.home}, ${c.aiProbs.draw}, ${c.aiProbs.away},
       ${c.probabilities.home}, ${c.probabilities.draw}, ${c.probabilities.away}, ${c.pick}, ${c.code}, ${c.tier})
      on conflict (match_id) do nothing returning match_id`).length) out.recorded++;
		else out.alreadyLogged++;
	}
	return out;
}
var COMPETITIONS = [
	"PL",
	"ELC",
	"BL1",
	"PD",
	"FL1",
	"SA",
	"DED",
	"PPL"
];
var WINDOW_MS = 7776e5;
var MIN_GAP_MS = 3e5;
var lastSettleAt = 0;
async function finishedBetween(key, comp, from, to) {
	const q = new URLSearchParams({
		status: "FINISHED",
		dateFrom: new Date(from).toISOString().slice(0, 10),
		dateTo: new Date(to).toISOString().slice(0, 10)
	});
	const res = await fetch(`https://api.football-data.org/v4/competitions/${comp}/matches?${q}`, {
		headers: { "X-Auth-Token": key },
		signal: AbortSignal.timeout(8e3)
	});
	if (!res.ok) throw new Error(`football-data ${comp} ${res.status}`);
	const j = await res.json();
	const out = [];
	for (const m of j.matches ?? []) {
		const s = m.score ?? {};
		const t = s.duration && s.duration !== "REGULAR" ? s.regularTime : s.fullTime;
		if (typeof t?.home === "number" && typeof t?.away === "number") out.push({
			home: m.homeTeam?.name ?? "",
			away: m.awayTeam?.name ?? "",
			utcDate: m.utcDate,
			homeGoals: t.home,
			awayGoals: t.away
		});
	}
	return out;
}
/** Fills in results for logged forecasts whose match should be over. Only touches rows that still have no result. */
async function settlePending(nowMs = Date.now()) {
	await ensureDbReady();
	const sql = await getSql();
	const due = (await loadPredictions()).filter((r) => !r.result && Date.parse(r.kickoffAt) + 72e5 < nowMs);
	if (!due.length) return {
		settled: 0,
		waiting: 0,
		note: "No logged match is waiting for a result."
	};
	const key = env("FOOTBALL_DATA_KEY");
	if (!key) return {
		settled: 0,
		waiting: due.length,
		note: "Set FOOTBALL_DATA_KEY so finished results can be fetched and these matches settled."
	};
	if (nowMs - lastSettleAt < MIN_GAP_MS) return {
		settled: 0,
		waiting: due.length,
		note: "Results were checked a moment ago; checking again shortly."
	};
	lastSettleAt = nowMs;
	const from = Math.min(...due.map((r) => Date.parse(r.kickoffAt))) - 864e5;
	const to = Math.min(nowMs, Math.max(...due.map((r) => Date.parse(r.kickoffAt))) + 1728e5);
	const feed = [];
	let calls = 0;
	for (const comp of COMPETITIONS) for (let a = from; a < to && calls < 24; a += WINDOW_MS) {
		calls++;
		try {
			feed.push(...await finishedBetween(key, comp, a, Math.min(a + WINDOW_MS - 864e5, to)));
		} catch {}
	}
	let settled = 0;
	for (const row of due) for (const f of feed) {
		const side = pairResult(row, f);
		if (!side) continue;
		if ((await sql`update prediction_log
        set result = ${side}, home_goals = ${f.homeGoals}, away_goals = ${f.awayGoals}, settled_at = now(), result_source = 'football-data.org'
        where match_id = ${row.matchId} and result is null returning match_id`).length) settled++;
		break;
	}
	return {
		settled,
		waiting: due.length - settled,
		note: settled ? `${settled} match${settled === 1 ? "" : "es"} settled from football-data.org.` : "No matching finished results found yet."
	};
}
//#endregion
export { loadMarketBenchmarks, loadPredictions, recordUpcoming, settlePending };
