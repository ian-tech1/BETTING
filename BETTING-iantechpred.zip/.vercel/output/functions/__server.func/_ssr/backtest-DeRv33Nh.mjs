import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
import { n as applyLeagueDrawPrior } from "./analysis-Cbzgc3mb.mjs";
import { A as predictionFeeds, N as removeVig, P as scoreTriple, _ as decide, d as adjustedLambdas, f as argmax, g as calibrate, h as brier, m as blendWithMarket, p as baseLambdas, w as fitTemperature, y as eloExpected } from "./price-D3Ht-t88.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/backtest-DeRv33Nh.js
var backtest_DeRv33Nh_exports = /* @__PURE__ */ __exportAll({
	a: () => buildAdvancedReport,
	c: () => boundedNudge,
	d: () => injuryImpact,
	f: () => signals_exports,
	i: () => liveConsensus,
	l: () => eloTriple,
	n: () => score,
	o: () => predictorPickLabel,
	r: () => buildConsensus,
	s: () => predictorShortLabel,
	t: () => runBacktest,
	u: () => headToHead
});
var signals_exports = /* @__PURE__ */ __exportAll$1({
	applySignals: () => applySignals,
	boundedNudge: () => boundedNudge,
	confidenceBand: () => confidenceBand,
	dixonColes: () => dixonColes,
	eloTriple: () => eloTriple,
	headToHead: () => headToHead,
	injuryImpact: () => injuryImpact,
	multiBookConsensus: () => multiBookConsensus,
	reliabilityAdjust: () => reliabilityAdjust
});
var KEYS$1 = [
	"home",
	"draw",
	"away"
];
var clamp$1 = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
var norm = (t) => {
	const s = t.home + t.draw + t.away || 1;
	return {
		home: t.home / s,
		draw: t.draw / s,
		away: t.away / s
	};
};
var factorial = (n) => n <= 1 ? 1 : n * factorial(n - 1);
var poisson = (k, l) => Math.exp(-l) * l ** k / factorial(k);
/** 1. Dixon-Coles: corrects the independent-Poisson habit of under-rating 0-0, 1-1, 1-0 and 0-1. */
function dixonColes(lh, la, rho = -.08, max = 8) {
	const tau = (x, y) => x === 0 && y === 0 ? 1 - lh * la * rho : x === 0 && y === 1 ? 1 + lh * rho : x === 1 && y === 0 ? 1 + la * rho : x === 1 && y === 1 ? 1 - rho : 1;
	let home = 0, draw = 0, away = 0;
	for (let x = 0; x <= max; x++) for (let y = 0; y <= max; y++) {
		const p = poisson(x, lh) * poisson(y, la) * tau(x, y);
		if (x > y) home += p;
		else if (x === y) draw += p;
		else away += p;
	}
	return norm({
		home,
		draw,
		away
	});
}
/** 2. Elo to 1X2: expected score split into win/draw/loss with a draw share that peaks when teams are level. */
function eloTriple(rHome, rAway, homeEdge = 60) {
	const e = eloExpected(rHome, rAway, homeEdge);
	const draw = clamp$1(.29 - Math.abs(e - .5) * .45, .12, .3);
	return norm({
		home: Math.max(.01, e - draw / 2),
		draw,
		away: Math.max(.01, 1 - e - draw / 2)
	});
}
/** 3. Multi-bookmaker consensus: de-vig each book, then take the median so one stale price cannot move it. */
function multiBookConsensus(books) {
	const fair = books.map(removeVig).filter((t) => !!t);
	if (!fair.length) return null;
	const med = (k) => {
		const xs = fair.map((t) => t[k]).sort((a, b) => a - b);
		const m = Math.floor(xs.length / 2);
		return xs.length % 2 ? xs[m] : (xs[m - 1] + xs[m]) / 2;
	};
	const p = norm({
		home: med("home"),
		draw: med("draw"),
		away: med("away")
	});
	const dispersion = Math.max(...KEYS$1.map((k) => Math.max(...fair.map((t) => t[k])) - Math.min(...fair.map((t) => t[k]))));
	return {
		p,
		books: fair.length,
		dispersion
	};
}
function injuryImpact(absences) {
	let attack = 1, defence = 1;
	for (const a of absences) {
		const w = a.starter ? 1 : .35;
		if (a.role === "FWD") attack -= .07 * w;
		else if (a.role === "MID") {
			attack -= .035 * w;
			defence += .02 * w;
		} else if (a.role === "DEF") defence += .05 * w;
		else if (a.role === "GK") defence += .09 * w;
		else {
			attack -= .02 * w;
			defence += .02 * w;
		}
	}
	return {
		attack: clamp$1(attack, .78, 1),
		defence: clamp$1(defence, 1, 1.28)
	};
}
/** 8. Head to head, shrunk hard: fixtures repeat but squads change, so it is only a light prior. */
function headToHead(results) {
	if (results.length < 3) return null;
	const n = results.length;
	const c = (k) => results.filter((r) => r === k).length;
	const prior = 4;
	return norm({
		home: (c("home") + prior / 3) / (n + prior),
		draw: (c("draw") + prior / 3) / (n + prior),
		away: (c("away") + prior / 3) / (n + prior)
	});
}
/** 10. Uncertainty band: perturbs both goal rates and reports the spread of the top outcome's probability. */
function confidenceBand(lh, la, runs = 200) {
	let state = Math.round((lh * 1e3 + la * 100) % 2147483647) || 1;
	const rnd = () => (state = state * 48271 % 2147483647) / 2147483647;
	const picks = {
		home: 0,
		draw: 0,
		away: 0
	};
	const tops = [];
	for (let i = 0; i < runs; i++) {
		const p = dixonColes(lh * (.85 + rnd() * .3), la * (.85 + rnd() * .3), -.08, 6);
		const k = KEYS$1.reduce((a, b) => p[b] > p[a] ? b : a);
		picks[k] += 1;
		tops.push(p[k]);
	}
	tops.sort((a, b) => a - b);
	const top = KEYS$1.reduce((a, b) => picks[b] > picks[a] ? b : a);
	return {
		low: tops[Math.floor(runs * .1)],
		high: tops[Math.floor(runs * .9)],
		stability: picks[top] / runs,
		top
	};
}
function reliabilityAdjust(p, history, min = 40) {
	if (history.length < min) return p;
	const out = { ...p };
	for (const k of KEYS$1) {
		const predicted = history.reduce((s, h) => s + h.p[k], 0) / history.length;
		const actual = history.filter((h) => h.result === k).length / history.length;
		out[k] = clamp$1(p[k] + clamp$1((actual - predicted) * .33, -.04, .04), .01, .97);
	}
	return norm(out);
}
function boundedNudge(n, cap = .04) {
	if (!n) return null;
	const f = (x) => Number.isFinite(x) ? clamp$1(x, -cap, cap) : 0;
	return {
		home: f(n.home),
		draw: f(n.draw),
		away: f(n.away)
	};
}
/** Fold the signals into a base probability. Each acts as a small, capped log-odds nudge. */
function applySignals(base, s, maxShift = .1) {
	if (!s) return {
		p: base,
		notes: []
	};
	const notes = [...s.notes ?? []];
	const out = { ...base };
	const pull = (target, weight, label) => {
		if (!target) return;
		for (const k of KEYS$1) out[k] += (target[k] - base[k]) * weight;
		notes.push(label);
	};
	pull(s.elo, .12, "Elo rating");
	pull(s.dixonColes, .35, "Time-decayed Dixon–Coles fit");
	pull(s.h2h, .04, "Head to head");
	if (s.market) pull(s.market, s.dispersion !== void 0 && s.dispersion > .08 ? .15 : .3, "Multi-bookmaker median");
	if (s.movement) for (const k of KEYS$1) out[k] += clamp$1(s.movement[k] * .5, -.02, .02);
	if (s.nudge) for (const k of KEYS$1) out[k] += s.nudge[k];
	for (const k of KEYS$1) out[k] = clamp$1(out[k], base[k] - maxShift, base[k] + maxShift);
	return {
		p: norm({
			home: Math.max(.005, out.home),
			draw: Math.max(.005, out.draw),
			away: Math.max(.005, out.away)
		}),
		notes
	};
}
var clamp = (value, minimum, maximum) => Math.min(maximum, Math.max(minimum, value));
var markValue = {
	W: 1,
	D: .35,
	L: 0
};
var formatPercent = (probability) => `${(probability * 100).toFixed(1)}%`;
function recentForm(form) {
	if (form.length === 0) return .4;
	let weighted = 0;
	let total = 0;
	form.forEach((mark, index) => {
		const age = form.length - index - 1;
		const weight = Math.pow(.72, age);
		weighted += markValue[mark] * weight;
		total += weight;
	});
	return total > 0 ? weighted / total : .4;
}
function shrinkRate(rate, played, prior = 1.35) {
	const games = Math.max(0, played);
	const priorGames = 8;
	return (rate * games + prior * priorGames) / (games + priorGames);
}
function namedAbsences(side) {
	return side.out.filter((name) => !/no new|no senior|no confirmed/i.test(name)).length;
}
function weightedEnsemble(models) {
	const scenarioIds = /* @__PURE__ */ new Set([
		"xg-only-neutral",
		"form-only",
		"goal-trend",
		"draw-conservative",
		"table-form-blend",
		"low-tempo-stress"
	]);
	const weightTotal = models.reduce((sum, model) => sum + (scenarioIds.has(model.id) ? .35 : 1), 0);
	const average = (key) => models.reduce((sum, model) => sum + model.probabilities[key] * (scenarioIds.has(model.id) ? .35 : 1), 0) / Math.max(1, weightTotal);
	return {
		home: average("home"),
		draw: average("draw"),
		away: average("away")
	};
}
function hashedSeed(input) {
	let value = 2166136261;
	for (let index = 0; index < input.length; index++) {
		value ^= input.charCodeAt(index);
		value = Math.imul(value, 16777619);
	}
	return value >>> 0 || 1;
}
function seededRandom(seed) {
	let state = seed;
	return () => {
		state = Math.imul(1664525, state) + 1013904223 >>> 0;
		return state / 4294967296;
	};
}
function samplePoisson(lambda, random) {
	const threshold = Math.exp(-lambda);
	let product = 1;
	let goals = 0;
	do {
		goals += 1;
		product *= random();
	} while (product > threshold && goals < 20);
	return goals - 1;
}
function monteCarlo(homeLambda, awayLambda, seed) {
	const simulations = 2400;
	const random = seededRandom(seed);
	let home = 0;
	let draw = 0;
	let away = 0;
	for (let index = 0; index < simulations; index++) {
		const homeGoals = samplePoisson(homeLambda, random);
		const awayGoals = samplePoisson(awayLambda, random);
		if (homeGoals > awayGoals) home += 1;
		else if (homeGoals === awayGoals) draw += 1;
		else away += 1;
	}
	const denominator = 2401.5;
	return {
		home: (home + .5) / denominator,
		draw: (draw + .5) / denominator,
		away: (away + .5) / denominator
	};
}
function poissonDistribution(lambda, maxGoals = 9) {
	const values = Array.from({ length: maxGoals + 1 }, (_, goals) => {
		let probability = Math.exp(-lambda);
		for (let index = 1; index <= goals; index++) probability *= lambda / index;
		return probability;
	});
	const mass = values.reduce((sum, value) => sum + value, 0);
	return values.map((value) => value / mass);
}
function negativeBinomialDistribution(mean, dispersion = 6, maxGoals = 9) {
	const p = dispersion / (dispersion + mean);
	const q = 1 - p;
	const values = [];
	let coefficient = 1;
	let power = Math.pow(p, dispersion);
	for (let goals = 0; goals <= maxGoals; goals++) {
		values.push(coefficient * power);
		coefficient *= (dispersion + goals) / (goals + 1);
		power *= q;
	}
	const mass = values.reduce((sum, value) => sum + value, 0);
	return values.map((value) => value / mass);
}
function tripleFromDistributions(home, away) {
	let homeWin = 0;
	let draw = 0;
	let awayWin = 0;
	for (let h = 0; h < home.length; h++) for (let a = 0; a < away.length; a++) {
		const probability = home[h] * away[a];
		if (h > a) homeWin += probability;
		else if (h === a) draw += probability;
		else awayWin += probability;
	}
	const total = homeWin + draw + awayWin || 1;
	return {
		home: homeWin / total,
		draw: draw / total,
		away: awayWin / total
	};
}
function zeroInflate(distribution, extraZeroMass) {
	return distribution.map((probability, index) => index === 0 ? extraZeroMass + (1 - extraZeroMass) * probability : (1 - extraZeroMass) * probability);
}
function bivariatePoisson(homeLambda, awayLambda) {
	const shared = Math.min(.12, homeLambda * .12, awayLambda * .12);
	const common = poissonDistribution(shared);
	const homeSolo = poissonDistribution(Math.max(.01, homeLambda - shared));
	const awaySolo = poissonDistribution(Math.max(.01, awayLambda - shared));
	const grid = Array.from({ length: homeSolo.length + common.length - 1 }, () => Array.from({ length: awaySolo.length + common.length - 1 }, () => 0));
	for (let commonGoals = 0; commonGoals < common.length; commonGoals++) for (let homeGoals = 0; homeGoals < homeSolo.length; homeGoals++) for (let awayGoals = 0; awayGoals < awaySolo.length; awayGoals++) grid[homeGoals + commonGoals][awayGoals + commonGoals] += common[commonGoals] * homeSolo[homeGoals] * awaySolo[awayGoals];
	let home = 0;
	let draw = 0;
	let away = 0;
	for (let h = 0; h < grid.length; h++) for (let a = 0; a < grid[h].length; a++) if (h > a) home += grid[h][a];
	else if (h === a) draw += grid[h][a];
	else away += grid[h][a];
	const total = home + draw + away || 1;
	return {
		home: home / total,
		draw: draw / total,
		away: away / total
	};
}
function strengthProxy(home, away) {
	const formHome = recentForm(home.form);
	const formAway = recentForm(away.form);
	const homeGoalDiff = home.played > 0 ? (home.gf - home.ga) / home.played : 0;
	const awayGoalDiff = away.played > 0 ? (away.gf - away.ga) / away.played : 0;
	const ratingGap = clamp((18 - home.pos) * 14 + (formHome - .5) * 70 + homeGoalDiff * 28 - ((18 - away.pos) * 14 + (formAway - .5) * 70 + awayGoalDiff * 28) + 48, -320, 320);
	const homeWinGivenNoDraw = 1 / (1 + Math.pow(10, -ratingGap / 400));
	const draw = clamp(.28 * Math.exp(-Math.abs(ratingGap) / 360), .07, .29);
	return {
		home: homeWinGivenNoDraw * (1 - draw),
		draw,
		away: (1 - homeWinGivenNoDraw) * (1 - draw)
	};
}
function logisticFeatures(home, away) {
	const xgGap = clamp(home.xgFor - away.xgFor + away.xgAgainst - home.xgAgainst, -3.5, 3.5);
	const tableGap = clamp(away.pos - home.pos, -20, 20);
	const formGap = recentForm(home.form) - recentForm(away.form);
	const absenceGap = clamp(namedAbsences(away) - namedAbsences(home), -3, 3);
	const score = clamp(.48 * xgGap + .025 * tableGap + .9 * formGap + .08 * absenceGap + .24, -2.4, 2.4);
	const exp = [
		score,
		.5 + Math.abs(score) * .12,
		-score
	].map((value) => Math.exp(value));
	const total = exp.reduce((sum, value) => sum + value, 0);
	return {
		home: exp[0] / total,
		draw: exp[1] / total,
		away: exp[2] / total
	};
}
function formCounts(form) {
	return {
		win: form.filter((mark) => mark === "W").length,
		draw: form.filter((mark) => mark === "D").length,
		loss: form.filter((mark) => mark === "L").length,
		games: form.length
	};
}
function formPointsVolatility(form) {
	if (form.length < 2) return null;
	const points = form.map((mark) => mark === "W" ? 3 : mark === "D" ? 1 : 0);
	const mean = points.reduce((sum, value) => sum + value, 0) / points.length;
	const variance = points.reduce((sum, value) => sum + (value - mean) ** 2, 0) / points.length;
	return Math.sqrt(variance);
}
function dirichletForm(home, away) {
	const h = formCounts(home.form);
	const a = formCounts(away.form);
	const hWin = (h.win + 1) / (h.games + 3);
	const hDraw = (h.draw + 1) / (h.games + 3);
	const hLoss = (h.loss + 1) / (h.games + 3);
	const aWin = (a.win + 1) / (a.games + 3);
	const aDraw = (a.draw + 1) / (a.games + 3);
	const raw = {
		home: (hWin + (a.loss + 1) / (a.games + 3)) / 2,
		draw: (hDraw + aDraw) / 2,
		away: (aWin + hLoss) / 2
	};
	const total = raw.home + raw.draw + raw.away || 1;
	return {
		home: raw.home / total,
		draw: raw.draw / total,
		away: raw.away / total
	};
}
function buildTools(home, away, homeLambda, awayLambda) {
	const hDist = poissonDistribution(homeLambda);
	const aDist = poissonDistribution(awayLambda);
	let btts = 0;
	let over15 = 0;
	let over25 = 0;
	let over35 = 0;
	let nilNil = 0;
	let homeNil = 0;
	let awayNil = 0;
	let homeClean = 0;
	let awayClean = 0;
	const bands = [
		0,
		0,
		0
	];
	for (let h = 0; h < hDist.length; h++) for (let a = 0; a < aDist.length; a++) {
		const probability = hDist[h] * aDist[a];
		const total = h + a;
		if (h > 0 && a > 0) btts += probability;
		if (total >= 2) over15 += probability;
		if (total >= 3) over25 += probability;
		if (total >= 4) over35 += probability;
		if (h === 0 && a === 0) nilNil += probability;
		if (h > a && a === 0) homeNil += probability;
		if (a > h && h === 0) awayNil += probability;
		if (a === 0) homeClean += probability;
		if (h === 0) awayClean += probability;
		bands[total <= 1 ? 0 : total <= 3 ? 1 : 2] += probability;
	}
	const firstScoringChance = 1 - nilNil;
	const firstHome = firstScoringChance * homeLambda / (homeLambda + awayLambda || 1);
	const firstAway = firstScoringChance - firstHome;
	const totalExpected = homeLambda + awayLambda;
	const gap = homeLambda - awayLambda;
	const count = (side) => namedAbsences(side);
	return [
		{
			id: "tool-over15",
			name: "Over 1.5 goals",
			value: formatPercent(over15),
			method: "Independent Poisson score grid from adjusted xG rates."
		},
		{
			id: "tool-over25",
			name: "Over 2.5 goals",
			value: formatPercent(over25),
			method: "Independent Poisson score grid from adjusted xG rates."
		},
		{
			id: "tool-under25",
			name: "Under 2.5 goals",
			value: formatPercent(1 - over25),
			method: "Complement of the same 2.5-goal probability."
		},
		{
			id: "tool-over35",
			name: "Over 3.5 goals",
			value: formatPercent(over35),
			method: "Independent Poisson score grid from adjusted xG rates."
		},
		{
			id: "tool-btts",
			name: "Both teams to score",
			value: formatPercent(btts),
			method: "Probability both sides score at least once in the score grid."
		},
		{
			id: "tool-nilnil",
			name: "0–0 scoreline",
			value: formatPercent(nilNil),
			method: "Joint zero-goal probability from both adjusted Poisson rates."
		},
		{
			id: "tool-home-clean",
			name: `${home.short} clean sheet`,
			value: formatPercent(homeClean),
			method: "Away side scores zero in the score grid."
		},
		{
			id: "tool-away-clean",
			name: `${away.short} clean sheet`,
			value: formatPercent(awayClean),
			method: "Home side scores zero in the score grid."
		},
		{
			id: "tool-home-nil",
			name: `${home.short} win to nil`,
			value: formatPercent(homeNil),
			method: "Home win with zero away goals in the score grid."
		},
		{
			id: "tool-away-nil",
			name: `${away.short} win to nil`,
			value: formatPercent(awayNil),
			method: "Away win with zero home goals in the score grid."
		},
		{
			id: "tool-first-score",
			name: "First-score proxy",
			value: `${home.short} ${formatPercent(firstHome)} · ${away.short} ${formatPercent(firstAway)} · no goal ${formatPercent(nilNil)}`,
			method: "Allocates the chance of at least one goal by relative scoring intensity; no time-to-goal data is available."
		},
		{
			id: "tool-goal-bands",
			name: "Total-goal bands",
			value: `0–1 ${formatPercent(bands[0])} · 2–3 ${formatPercent(bands[1])} · 4+ ${formatPercent(bands[2])}`,
			method: "Grouped total-goal probability from the independent score grid."
		},
		{
			id: "tool-xg-context",
			name: "Expected-goals context",
			value: `${home.short} ${homeLambda.toFixed(2)} · ${away.short} ${awayLambda.toFixed(2)} · total ${totalExpected.toFixed(2)} · gap ${gap >= 0 ? "+" : ""}${gap.toFixed(2)}`,
			method: `Pre-match rate inputs. Listed absences: ${home.short} ${count(home)}, ${away.short} ${count(away)}; absence counts are not player-specific weights.`
		}
	];
}
function pickName(pick) {
	if (pick === "home") return "Home";
	if (pick === "away") return "Away";
	return "Draw";
}
function buildAdvancedReport(home, away) {
	const base = baseLambdas(home, away);
	const adjusted = adjustedLambdas(home, away);
	const hAttack = shrinkRate(home.xgFor, home.played);
	const aAttack = shrinkRate(away.xgFor, away.played);
	const hDefence = shrinkRate(home.xgAgainst, home.played);
	const aDefence = shrinkRate(away.xgAgainst, away.played);
	const bayesHome = clamp((hAttack + aDefence) / 2 * 1.06, .35, 3.3);
	const bayesAway = clamp((aAttack + hDefence) / 2 * .94, .25, 3.1);
	const recencyGap = recentForm(home.form) - recentForm(away.form);
	const recencyHome = clamp(base.home * (1 + recencyGap * .2), .35, 3.3);
	const recencyAway = clamp(base.away * (1 - recencyGap * .2), .25, 3.1);
	const seed = hashedSeed(`${home.name}:${away.name}:${home.xgFor}:${away.xgFor}:${home.played}:${away.played}`);
	const homeGoalsRate = home.played > 0 ? home.gf / home.played : 1.35;
	const awayGoalsRate = away.played > 0 ? away.gf / away.played : 1.35;
	const homeConcedeRate = home.played > 0 ? home.ga / home.played : 1.35;
	const awayConcedeRate = away.played > 0 ? away.ga / away.played : 1.35;
	const observedHome = clamp((homeGoalsRate + awayConcedeRate) / 2 * 1.08, .35, 3.3);
	const observedAway = clamp((awayGoalsRate + homeConcedeRate) / 2 * .94, .25, 3.1);
	const bayesGoalsHome = clamp((shrinkRate(homeGoalsRate, home.played) + shrinkRate(awayConcedeRate, away.played)) / 2 * 1.06, .35, 3.3);
	const bayesGoalsAway = clamp((shrinkRate(awayGoalsRate, away.played) + shrinkRate(homeConcedeRate, home.played)) / 2 * .94, .25, 3.1);
	const threeGap = recentForm(home.form.slice(-3)) - recentForm(away.form.slice(-3));
	const rankGap = clamp(away.pos - home.pos, -20, 20);
	const difference = (home.played > 0 ? (home.gf - home.ga) / home.played : 0) - (away.played > 0 ? (away.gf - away.ga) / away.played : 0);
	const noAbsenceHome = namedAbsences(home);
	const noAbsenceAway = namedAbsences(away);
	const stressHome = clamp(adjusted.home * (1 - Math.min(noAbsenceHome, 4) * .06), .35, 3.3);
	const stressAway = clamp(adjusted.away * (1 - Math.min(noAbsenceAway, 4) * .06), .25, 3.1);
	const hDir = poissonDistribution(adjusted.home);
	const aDir = poissonDistribution(adjusted.away);
	const models = [
		{
			id: "dixon-coles",
			name: "Dixon–Coles",
			method: "Adjusted xG with a low-score dependence correction.",
			probabilities: scoreTriple(adjusted.home, adjusted.away, true)
		},
		{
			id: "bayesian-xg",
			name: "Bayesian xG shrinkage",
			method: "Team rates are pulled toward a 1.35-goal prior when the sample is small.",
			probabilities: scoreTriple(bayesHome, bayesAway, true)
		},
		{
			id: "decayed-form",
			name: "Recency-decay form",
			method: "Recent results receive exponential weights; older form fades faster.",
			probabilities: scoreTriple(recencyHome, recencyAway, false)
		},
		{
			id: "strength-proxy",
			name: "Strength-rating proxy",
			method: "Rating proxy from table position, form, goal difference, and home advantage—not official Elo ratings.",
			probabilities: strengthProxy(home, away)
		},
		{
			id: "feature-logit",
			name: "Logistic feature model",
			method: "Softmax classifier-style score from xG gap, table gap, recent form, and listed absences; hand-set, not trained.",
			probabilities: logisticFeatures(home, away)
		},
		{
			id: "monte-carlo",
			name: "Monte Carlo · 2,400 runs",
			method: "Seeded score simulation from adjusted Poisson rates; repeatable for the same fixture inputs.",
			probabilities: monteCarlo(adjusted.home, adjusted.away, seed)
		},
		{
			id: "season-rate",
			name: "Season-rate baseline",
			method: "Season xG-for and xG-against without recent-form adjustments.",
			probabilities: scoreTriple(base.home, base.away, false)
		},
		{
			id: "negative-binomial",
			name: "Negative-binomial overdispersion",
			method: "Overdispersed goal counts with dispersion r=6; allows more scoreline variance than Poisson.",
			probabilities: tripleFromDistributions(negativeBinomialDistribution(adjusted.home), negativeBinomialDistribution(adjusted.away))
		},
		{
			id: "zero-inflated",
			name: "Zero-inflated low-score model",
			method: "Adds 10% extra zero-goal mass to each team's Poisson distribution; scenario assumption, not learned from history.",
			probabilities: tripleFromDistributions(zeroInflate(hDir, .1), zeroInflate(aDir, .1))
		},
		{
			id: "bivariate",
			name: "Bivariate Poisson",
			method: "Shared latent goal component up to 0.12 plus independent scoring components.",
			probabilities: bivariatePoisson(adjusted.home, adjusted.away)
		},
		{
			id: "observed-goals",
			name: "Goals-for / goals-against",
			method: "Observed goals per game versus opponent concessions; does not use xG.",
			probabilities: scoreTriple(observedHome, observedAway, false)
		},
		{
			id: "bayes-goals",
			name: "Bayesian observed-goals",
			method: "Observed goals rates shrink toward a 1.35-goal prior using eight prior-match equivalents.",
			probabilities: scoreTriple(bayesGoalsHome, bayesGoalsAway, true)
		},
		{
			id: "last-three",
			name: "Last-three form tilt",
			method: "Exponential recency on the last three W/D/L marks tilts season xG rates.",
			probabilities: scoreTriple(clamp(base.home * (1 + threeGap * .25), .35, 3.3), clamp(base.away * (1 - threeGap * .25), .25, 3.1), false)
		},
		{
			id: "table-only",
			name: "Table-position-only",
			method: "League-rank gap maps to scoring rates with a small home factor; ignores xG and form.",
			probabilities: scoreTriple(clamp(1.35 + rankGap * .035, .35, 3.3), clamp(1.35 - rankGap * .035, .25, 3.1), false)
		},
		{
			id: "goal-difference",
			name: "Goal-difference model",
			method: "Season goal difference per game maps to scoring rates; no xG, form, or absence inputs.",
			probabilities: scoreTriple(clamp(1.5 + difference * .22, .35, 3.3), clamp(1.35 - difference * .22, .25, 3.1), false)
		},
		{
			id: "absence-stress",
			name: "Listed-absence stress",
			method: "Stress case applies a uniform 6% scoring reduction per named absence, capped at four; no player-specific impact data.",
			probabilities: scoreTriple(stressHome, stressAway, true)
		},
		{
			id: "neutral-venue",
			name: "Neutral-venue scenario",
			method: "Removes the base home multiplier (1.10) and away factor (0.92) before scoring.",
			probabilities: scoreTriple(clamp(base.home / 1.1, .35, 3.3), clamp(base.away / .92, .25, 3.1), false)
		},
		{
			id: "home-edge-stress",
			name: "Stronger home-edge scenario",
			method: "Stress case raises home rate 18% and trims away rate 10%; not a venue-specific estimate.",
			probabilities: scoreTriple(clamp(base.home * 1.18, .35, 3.3), clamp(base.away * .9, .25, 3.1), false)
		},
		{
			id: "dirichlet-form",
			name: "Dirichlet-smoothed W/D/L",
			method: "Recent W/D/L frequencies use a +1 prior for each result before mapping home wins, draws, and away wins.",
			probabilities: dirichletForm(home, away)
		},
		{
			id: "xg-only-neutral",
			name: "Neutral xG baseline",
			method: "Compares season xG rates with the home-venue multiplier removed.",
			probabilities: scoreTriple(clamp((hAttack + aDefence) / 2, .35, 3.3), clamp((aAttack + hDefence) / 2, .25, 3.1), false)
		},
		{
			id: "form-only",
			name: "Recent-form only",
			method: "Uses the recent W/D/L signal with a modest home edge; ignores season xG.",
			probabilities: scoreTriple(clamp(1.25 + recencyGap * .7, .35, 3.3), clamp(1.25 - recencyGap * .7, .25, 3.1), true)
		},
		{
			id: "goal-trend",
			name: "Observed scoring trend",
			method: "Uses goals scored and conceded per match with a small-sample shrinkage prior.",
			probabilities: scoreTriple(bayesGoalsHome, bayesGoalsAway, false)
		},
		{
			id: "draw-conservative",
			name: "Conservative draw scenario",
			method: "Pulls both scoring rates toward an even, lower-tempo match to test draw sensitivity.",
			probabilities: scoreTriple((adjusted.home + 1.25) / 2, (adjusted.away + 1.25) / 2, true)
		},
		{
			id: "table-form-blend",
			name: "Table + form blend",
			method: "Combines league-position gap and recent form using small capped adjustments.",
			probabilities: scoreTriple(clamp(base.home * (1 + recencyGap * .12 + rankGap * .003), .35, 3.3), clamp(base.away * (1 - recencyGap * .12 - rankGap * .003), .25, 3.1), true)
		},
		{
			id: "low-tempo-stress",
			name: "Low-tempo stress test",
			method: "Reduces both expected-goal rates by 15% to test a slower-match scenario.",
			probabilities: scoreTriple(adjusted.home * .85, adjusted.away * .85, true)
		}
	];
	const ensemble = weightedEnsemble(models);
	const pick = argmax(ensemble);
	const sortedOutcomes = Object.entries(ensemble).sort((a, b) => b[1] - a[1]);
	const outcomeMargin = sortedOutcomes[0][1] - sortedOutcomes[1][1];
	const homeFormVolatility = formPointsVolatility(home.form);
	const awayFormVolatility = formPointsVolatility(away.form);
	const tools = buildTools(home, away, adjusted.home, adjusted.away);
	tools.push({
		id: "tool-top-margin",
		name: "Top-result margin",
		value: formatPercent(outcomeMargin),
		method: "Difference between the ensemble's top and second outcome probabilities; a narrow margin means the lean is fragile, not a confidence interval."
	}, {
		id: "tool-form-volatility",
		name: "Recent-form volatility · points SD",
		value: `${home.short} ${homeFormVolatility === null ? "n/a" : homeFormVolatility.toFixed(2)} · ${away.short} ${awayFormVolatility === null ? "n/a" : awayFormVolatility.toFixed(2)}`,
		method: "Population standard deviation of listed W/D/L points (3/1/0); it describes the short form sequence and is not opponent- or venue-adjusted."
	});
	const agreement = models.filter((model) => argmax(model.probabilities) === pick).length;
	const pickValues = models.map((model) => model.probabilities[pick]);
	const spread = Math.max(...pickValues) - Math.min(...pickValues);
	const sampleGames = Math.min(home.played, away.played);
	const adjustedScore = scoreTriple(adjusted.home, adjusted.away, true);
	const stressPicks = [
		argmax(scoreTriple(adjusted.home * .9, adjusted.away * 1.1, true)),
		argmax(adjustedScore),
		argmax(scoreTriple(adjusted.home * 1.1, adjusted.away * .9, true))
	];
	const stressStable = stressPicks.every((scenarioPick) => scenarioPick === pick);
	const riskFlags = [];
	if (sampleGames < 8) riskFlags.push("Small sample: fewer than 8 games for at least one side.");
	if (Math.min(home.form.length, away.form.length) < 3) riskFlags.push("Short recent-form sequence: fewer than 3 results for at least one side.");
	if (outcomeMargin < .05) riskFlags.push("Narrow top-result margin: the leading outcome is less than 5 points ahead of second place.");
	if (agreement < models.length / 2) riskFlags.push("Model split: fewer than half of the formula outputs share the ensemble lean.");
	if (spread >= .18) riskFlags.push("Wide model spread: estimated probability varies by at least 18 points.");
	if (ensemble.draw >= .3) riskFlags.push("Draw risk: the ensemble draw probability is at least 30%.");
	if (!stressStable) riskFlags.push("Fragile lean: a ±10% xG stress case changes the top outcome.");
	return {
		models,
		tools,
		ensemble,
		pick,
		outcomeMargin,
		agreement,
		agreementRate: agreement / models.length,
		spread,
		sampleGames,
		sampleLabel: sampleGames < 8 ? "limited" : sampleGames < 16 ? "moderate" : "broader",
		stressStable,
		stressPicks,
		riskFlags
	};
}
function predictorPickLabel(pick, home, away) {
	if (pick === "home") return home;
	if (pick === "away") return away;
	return "Draw";
}
function predictorShortLabel(pick) {
	return pickName(pick);
}
/** Weight the statistical engine and the AI-style lab by Brier skill over the last 100 settled matches. */
function accuracyWeights(history, window = 100) {
	const last = history.slice(-window);
	if (last.length < 20) return {
		engine: .5,
		ai: .5,
		sample: last.length
	};
	const skill = (k) => Math.max(.05, 1 - brier(last.map((r) => ({
		p: r[k],
		result: r.result
	}))) / .667);
	const e = skill("engine");
	const a = skill("ai");
	return {
		engine: e / (e + a),
		ai: a / (e + a),
		sample: last.length
	};
}
var TIERS = [
	"A",
	"B",
	"C",
	"PASS"
];
function buildConsensus(home, away, opts = {}) {
	const engine = predictionFeeds(home, away);
	const ai = buildAdvancedReport(home, away);
	const history = opts.history ?? [];
	const weights = accuracyWeights(history);
	const mixed = {
		home: engine.blend.home * weights.engine + ai.ensemble.home * weights.ai,
		draw: engine.blend.draw * weights.engine + ai.ensemble.draw * weights.ai,
		away: engine.blend.away * weights.engine + ai.ensemble.away * weights.ai
	};
	const market = opts.odds ? removeVig(opts.odds) : null;
	const withSignals = applySignals(mixed, opts.signals);
	const past = history.slice(-100).map((r) => ({
		p: r.final ?? r.engine,
		result: r.result
	}));
	const temperature = fitTemperature(past);
	let probabilities = calibrate(reliabilityAdjust(blendWithMarket(withSignals.p, market, .5), history.slice(-100).map((r) => ({
		p: r.final ?? {
			home: (r.engine.home + r.ai.home) / 2,
			draw: (r.engine.draw + r.ai.draw) / 2,
			away: (r.engine.away + r.ai.away) / 2
		},
		result: r.result
	}))), temperature);
	const leagueHistory = opts.league ? history.filter((r) => r.league === opts.league) : [];
	if (leagueHistory.length >= 20) probabilities = applyLeagueDrawPrior(probabilities, leagueHistory.filter((r) => r.result === "draw").length, leagueHistory.length);
	else if (opts.signals?.drawPrior) probabilities = applyLeagueDrawPrior(probabilities, opts.signals.drawPrior.draws, opts.signals.drawPrior.sample);
	const lam = adjustedLambdas(home, away);
	const band = confidenceBand(lam.home, lam.away);
	const pick = argmax(probabilities);
	const agreement = (engine.agree / engine.core + ai.agreementRate) / 2;
	const freshness = opts.signals?.freshness ?? {
		status: "missing",
		action: "pass",
		ageHours: null,
		reasons: ["No timestamped required team-data source is available."]
	};
	const age = freshness.status === "fresh" ? freshness.ageHours ?? opts.dataAgeHours ?? 0 : freshness.ageHours ?? 49;
	const base = decide(probabilities, agreement, age);
	const cautions = [];
	if (freshness.action === "pass") cautions.push("Fresh required data is missing; the final tip is PASS.");
	else if (freshness.action === "downgrade") cautions.push("Required data is stale; confidence has been downgraded.");
	cautions.push(...freshness.reasons);
	if (!ai.stressStable) cautions.push("Result flips under a stress test");
	if (ai.sampleLabel === "limited") cautions.push("Small sample of games");
	if (ai.spread > .12) cautions.push("Models are widely spread");
	if (market && argmax(market) !== pick) cautions.push("Market favours a different outcome");
	if (band.stability < .6) cautions.push("Pick unstable when goal rates are perturbed");
	if (opts.signals?.dispersion !== void 0 && opts.signals.dispersion > .1) cautions.push("Bookmakers disagree");
	const conflict = argmax(engine.blend) !== argmax(ai.ensemble);
	if (conflict) cautions.push("Engine and AI lab disagreed; reconciled");
	const steps = cautions.filter((c) => !c.includes("reconciled")).length;
	const idx = Math.min(3, TIERS.indexOf(base.tier) + steps + (freshness.action === "downgrade" && age <= 48 ? 1 : 0));
	const tier = freshness.action === "pass" ? "PASS" : TIERS[idx];
	const code = tier === "PASS" ? "PASS" : base.pick;
	const color = opts.live ? "#06B6D4" : tier === "PASS" || probabilities[pick] < .42 ? "#EF4444" : tier === "A" && pick !== "draw" ? "#10B981" : "#F59E0B";
	const label = opts.live ? "Live consensus update" : color === "#10B981" ? "High-confidence consensus" : color === "#F59E0B" ? pick === "draw" ? "Draw option, moderate confidence" : "Moderate confidence" : "High risk, lower probability";
	return {
		probabilities,
		pick,
		code,
		tier,
		color,
		label,
		conflict,
		enginePick: argmax(engine.blend),
		aiPick: ai.pick,
		weights,
		cautions,
		engineProbs: engine.blend,
		aiProbs: ai.ensemble,
		signalNotes: withSignals.notes,
		band,
		freshness
	};
}
/**
* Live Final tip: the pre-match consensus fades into the in-play probabilities as the match goes on.
* In-play already contains the score, so its weight grows with the clock (20% at kick-off, 85% late).
*/
function liveConsensus(pre, play, minute) {
	const w = minute < 0 ? .2 : Math.min(.85, .2 + minute / 90 * .65);
	const mixed = {
		home: pre.probabilities.home * (1 - w) + play.home * w,
		draw: pre.probabilities.draw * (1 - w) + play.draw * w,
		away: pre.probabilities.away * (1 - w) + play.away * w
	};
	const sum = mixed.home + mixed.draw + mixed.away || 1;
	const probabilities = {
		home: mixed.home / sum,
		draw: mixed.draw / sum,
		away: mixed.away / sum
	};
	const pick = argmax(probabilities);
	const top = probabilities[pick];
	const tier = top >= .7 ? "A" : top >= .55 ? "B" : top >= .45 ? "C" : "PASS";
	const code = tier === "PASS" ? "PASS" : pick === "home" ? "1" : pick === "draw" ? "X" : "2";
	return {
		...pre,
		probabilities,
		pick,
		tier,
		code,
		color: "#06B6D4",
		label: "Live consensus update",
		conflict: false
	};
}
var KEYS = [
	"home",
	"draw",
	"away"
];
var top = (t) => [...KEYS].sort((a, b) => t[b] - t[a])[0];
var mean = (xs) => xs.length ? xs.reduce((s, x) => s + x, 0) / xs.length : NaN;
var onehot = (r) => ({
	home: r === "home" ? 1 : 0,
	draw: r === "draw" ? 1 : 0,
	away: r === "away" ? 1 : 0
});
var brierOne = (p, r) => KEYS.reduce((s, k) => s + (p[k] - onehot(r)[k]) ** 2, 0);
var logLossOne = (p, r) => -Math.log(Math.max(p[r], 1e-9));
/** Ranked probability score for the ordered outcomes home < draw < away (lower is better). */
var rpsOne = (p, r) => {
	const o = onehot(r);
	const c1 = p.home - o.home;
	const c2 = p.home + p.draw - o.home - o.draw;
	return (c1 ** 2 + c2 ** 2) / 2;
};
/** 95% Wilson interval for a hit rate. Honest about small samples, unlike a plain percentage. */
function wilson(hits, n, z = 1.96) {
	if (n === 0) return {
		low: NaN,
		high: NaN
	};
	const p = hits / n;
	const d = 1 + z * z / n;
	const centre = (p + z * z / (2 * n)) / d;
	const half = z * Math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d;
	return {
		low: Math.max(0, centre - half),
		high: Math.min(1, centre + half)
	};
}
function score(rows) {
	const n = rows.length;
	const hits = rows.filter((r) => top(r.p) === r.result).length;
	const w = wilson(hits, n);
	return {
		n,
		hits,
		hitRate: n ? hits / n : NaN,
		hitLow: w.low,
		hitHigh: w.high,
		brier: mean(rows.map((r) => brierOne(r.p, r.result))),
		logLoss: mean(rows.map((r) => logLossOne(r.p, r.result))),
		rps: mean(rows.map((r) => rpsOne(r.p, r.result)))
	};
}
var blend = (a, b) => ({
	home: (a.home + b.home) / 2,
	draw: (a.draw + b.draw) / 2,
	away: (a.away + b.away) / 2
});
/** Does "70% confident" really win about 70% of the time? Bins every outcome probability that was issued. */
function calibrationBins(rows, edges = [
	0,
	.2,
	.35,
	.5,
	.65,
	.8,
	1.0001
]) {
	const bins = edges.slice(0, -1).map((from, i) => ({
		from,
		to: edges[i + 1],
		preds: [],
		wins: 0
	}));
	for (const r of rows) for (const k of KEYS) {
		const b = bins.find((x) => r.p[k] >= x.from && r.p[k] < x.to);
		if (!b) continue;
		b.preds.push(r.p[k]);
		if (r.result === k) b.wins += 1;
	}
	return bins.filter((b) => b.preds.length).map((b) => ({
		from: b.from,
		to: Math.min(1, b.to),
		n: b.preds.length,
		predicted: mean(b.preds),
		observed: b.wins / b.preds.length
	}));
}
/**
* Historical backtest over completed matches. Every number comes from comparing stored probabilities with
* real final results; nothing here counts how many models agree as evidence of being right.
*/
function runBacktest(records) {
	const n = records.length;
	const rows = {
		engine: records.map((r) => ({
			p: r.engine,
			result: r.result
		})),
		ai: records.map((r) => ({
			p: r.ai,
			result: r.result
		})),
		blend: records.map((r) => ({
			p: blend(r.engine, r.ai),
			result: r.result
		})),
		primary: records.map((r) => ({
			p: r.final ?? blend(r.engine, r.ai),
			result: r.result
		}))
	};
	const freq = {
		home: n ? records.filter((r) => r.result === "home").length / n : 1 / 3,
		draw: n ? records.filter((r) => r.result === "draw").length / n : 1 / 3,
		away: n ? records.filter((r) => r.result === "away").length / n : 1 / 3
	};
	const baselines = {
		alwaysHome: score(records.map((r) => ({
			p: {
				home: .98,
				draw: .01,
				away: .01
			},
			result: r.result
		}))),
		frequency: score(records.map((r) => ({
			p: freq,
			result: r.result
		}))),
		uniform: score(records.map((r) => ({
			p: {
				home: 1 / 3,
				draw: 1 / 3,
				away: 1 / 3
			},
			result: r.result
		})))
	};
	const engine = score(rows.engine);
	const ai = score(rows.ai);
	const bl = score(rows.blend);
	const primary = score(rows.primary);
	const skill = (b) => Number.isFinite(b) && baselines.frequency.brier > 0 ? 1 - b / baselines.frequency.brier : NaN;
	const agreeRows = records.filter((r) => top(r.engine) === top(r.ai)).map((r) => ({
		p: r.final ?? blend(r.engine, r.ai),
		result: r.result
	}));
	const splitRows = records.filter((r) => top(r.engine) !== top(r.ai)).map((r) => ({
		p: r.final ?? blend(r.engine, r.ai),
		result: r.result
	}));
	const agree = score(agreeRows);
	const disagree = score(splitRows);
	const confidence = [
		[
			"Under 45%",
			0,
			.45
		],
		[
			"45-55%",
			.45,
			.55
		],
		[
			"55-65%",
			.55,
			.65
		],
		[
			"65% and over",
			.65,
			1.01
		]
	].map(([label, lo, hi]) => ({
		label,
		card: score(rows.primary.filter((r) => r.p[top(r.p)] >= lo && r.p[top(r.p)] < hi))
	})).filter((b) => b.card.n > 0);
	let verdict = "insufficient";
	let verdictText = `Only ${n} completed match${n === 1 ? "" : "es"} on record. At least 50 are needed before any accuracy claim means much.`;
	if (n >= 50) {
		const s = skill(primary.brier);
		verdict = s > 0 ? "beats-baseline" : "no-edge";
		verdictText = verdict === "beats-baseline" ? `Beats a base-rate guess on Brier score${s < .02 ? ", but only by a thin margin" : ""}. That is still not a guarantee on any single match.` : "Does not beat a simple base-rate guess yet. Do not treat these picks as an edge.";
	}
	return {
		n,
		engine,
		ai,
		blend: bl,
		primary,
		tiers: [
			"A",
			"B",
			"C",
			"PASS"
		].map((tier) => ({
			tier,
			card: score(records.filter((r) => r.tier === tier).map((r) => ({
				p: r.final ?? blend(r.engine, r.ai),
				result: r.result
			})))
		})).filter((t) => t.card.n > 0),
		baselines,
		skill: {
			engine: skill(engine.brier),
			ai: skill(ai.brier),
			blend: skill(bl.brier),
			primary: skill(primary.brier)
		},
		agreement: {
			agree,
			disagree,
			liftPoints: Number.isFinite(agree.hitRate) && Number.isFinite(disagree.hitRate) ? (agree.hitRate - disagree.hitRate) * 100 : NaN
		},
		confidence,
		calibration: calibrationBins(rows.primary),
		verdict,
		verdictText
	};
}
//#endregion
export { eloTriple as a, liveConsensus as c, runBacktest as d, score as f, buildConsensus as i, predictorPickLabel as l, boundedNudge as n, headToHead as o, buildAdvancedReport as r, injuryImpact as s, backtest_DeRv33Nh_exports as t, predictorShortLabel as u };
