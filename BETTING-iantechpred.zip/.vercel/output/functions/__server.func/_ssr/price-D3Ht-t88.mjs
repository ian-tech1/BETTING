//#region node_modules/.nitro/vite/services/ssr/assets/price-D3Ht-t88.js
/** UK kickoffs as UTC instants. Used for countdowns only. */
var KICKOFF_ISO = {
	"lee-tot": "2026-11-07T12:30:00Z",
	"ars-hul": "2026-11-07T15:00:00Z",
	"ful-new": "2026-11-07T15:00:00Z",
	"nfo-mci": "2026-11-07T17:30:00Z",
	"bvb-elv": "2026-11-07T15:30:00Z",
	"koe-b04": "2026-11-07T15:30:00Z",
	"m05-bay": "2026-11-07T15:30:00Z",
	"tor-lec": "2026-11-07T15:00:00Z",
	"rom-sas": "2026-11-07T20:45:00Z",
	"bha-bre": "2026-11-08T14:00:00Z",
	"cry-liv": "2026-11-08T14:00:00Z",
	"sun-che": "2026-11-08T14:00:00Z",
	"ips-bou": "2026-11-08T14:00:00Z",
	"mun-avl": "2026-11-08T16:30:00Z",
	"val-rma": "2026-11-08T15:00:00Z",
	"atm-bar": "2026-11-08T20:00:00Z",
	"nap-laz": "2026-11-08T11:30:00Z",
	"gen-mil": "2026-11-08T15:00:00Z",
	"fio-juv": "2026-11-08T20:45:00Z",
	"int-com": "2026-11-08T18:00:00Z",
	"psg-mar": "2026-11-07T20:00:00Z",
	"mon-lil": "2026-11-07T17:00:00Z",
	"lyo-nic": "2026-11-08T19:45:00Z",
	"aja-fey": "2026-11-08T13:30:00Z",
	"psv-az": "2026-11-07T19:00:00Z",
	"twe-utr": "2026-11-08T15:45:00Z",
	"ben-por": "2026-11-07T21:15:00Z",
	"spo-bra": "2026-11-08T21:15:00Z",
	"gui-fam": "2026-11-07T18:00:00Z",
	"lei-sou": "2026-11-07T12:30:00Z",
	"bur-shu": "2026-11-07T15:00:00Z",
	"mid-nor": "2026-11-08T15:00:00Z",
	"cel-ran": "2026-11-08T12:00:00Z",
	"abd-hea": "2026-11-07T15:00:00Z",
	"r-mci-bur": "2026-11-01T14:00:00Z",
	"r-liv-bha": "2026-11-01T16:30:00Z",
	"r-bar-rso": "2026-11-01T20:00:00Z",
	"r-int-tor": "2026-11-01T17:00:00Z",
	"r-bay-koe": "2026-11-01T17:30:00Z",
	"r-che-ful": "2026-11-02T20:00:00Z",
	"r-rma-sev": "2026-11-02T20:00:00Z",
	"r-juv-mil": "2026-11-02T19:45:00Z",
	"r-bvb-rbl": "2026-11-03T19:30:00Z",
	"r-atm-val": "2026-11-03T20:00:00Z",
	"r-new-lee": "2026-11-04T19:30:00Z",
	"r-nap-gen": "2026-11-04T17:30:00Z"
};
function side$3(name, short, pos, form, xgFor, xgAgainst) {
	return {
		name,
		short,
		pos,
		form,
		xgFor,
		xgAgainst,
		gf: Math.round(xgFor * 10),
		ga: Math.round(xgAgainst * 10),
		played: 10,
		out: []
	};
}
var LIVE_RAW = [
	{
		id: "lv-ars-che",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Emirates Stadium",
		offsetMin: 18,
		goals: [{
			minute: 14,
			side: "home"
		}],
		home: side$3("Arsenal", "Arsenal", 1, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.92, .84),
		away: side$3("Chelsea", "Chelsea", 5, [
			"W",
			"D",
			"L",
			"W",
			"W"
		], 1.7, 1.16)
	},
	{
		id: "lv-mci-liv",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Etihad Stadium",
		offsetMin: 52,
		flag: "Away red card",
		goals: [
			{
				minute: 9,
				side: "home"
			},
			{
				minute: 33,
				side: "away"
			},
			{
				minute: 61,
				side: "home"
			}
		],
		home: side$3("Man City", "City", 2, [
			"W",
			"W",
			"W",
			"L",
			"W"
		], 1.96, 1.05),
		away: side$3("Liverpool", "Liverpool", 3, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.82, 1.12)
	},
	{
		id: "lv-bar-atm",
		league: "La Liga",
		code: "LAL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Spotify Camp Nou",
		offsetMin: 7,
		goals: [],
		home: side$3("Barcelona", "Barcelona", 1, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 2.12, .88),
		away: side$3("Atletico Madrid", "Atletico", 4, [
			"W",
			"W",
			"D",
			"W",
			"D"
		], 1.58, .96)
	},
	{
		id: "lv-int-juv",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "San Siro",
		offsetMin: 64,
		goals: [{
			minute: 22,
			side: "away"
		}, {
			minute: 71,
			side: "home"
		}],
		home: side$3("Inter", "Inter", 1, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.98, .82),
		away: side$3("Juventus", "Juventus", 4, [
			"W",
			"D",
			"W",
			"W",
			"D"
		], 1.48, .86)
	},
	{
		id: "lv-bay-bvb",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Allianz Arena",
		offsetMin: 31,
		goals: [{
			minute: 11,
			side: "home"
		}, {
			minute: 28,
			side: "home"
		}],
		home: side$3("Bayern", "Bayern", 1, [
			"W",
			"W",
			"W",
			"W",
			"D"
		], 2.24, .92),
		away: side$3("Dortmund", "Dortmund", 4, [
			"W",
			"D",
			"W",
			"L",
			"W"
		], 1.88, 1.22)
	},
	{
		id: "lv-rma-sev",
		league: "La Liga",
		code: "LAL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Santiago Bernabeu",
		offsetMin: 77,
		goals: [{
			minute: 40,
			side: "home"
		}],
		home: side$3("Real Madrid", "Madrid", 3, [
			"W",
			"W",
			"W",
			"L",
			"W"
		], 1.92, 1.02),
		away: side$3("Sevilla", "Sevilla", 12, [
			"L",
			"D",
			"W",
			"L",
			"D"
		], 1.15, 1.4)
	},
	{
		id: "lv-nap-rom",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Diego Armando Maradona",
		offsetMin: 3,
		goals: [],
		home: side$3("Napoli", "Napoli", 2, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.74, .9),
		away: side$3("Roma", "Roma", 5, [
			"W",
			"D",
			"W",
			"D",
			"L"
		], 1.44, 1.08)
	},
	{
		id: "lv-new-bha",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "St James' Park",
		offsetMin: 44,
		goals: [{
			minute: 48,
			side: "away"
		}],
		flag: "Just after the break",
		home: side$3("Newcastle", "Newcastle", 6, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.62, 1.18),
		away: side$3("Brighton", "Brighton", 8, [
			"D",
			"W",
			"L",
			"W",
			"D"
		], 1.52, 1.24)
	},
	{
		id: "lv-avl-whu",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Villa Park",
		offsetMin: 12,
		goals: [{
			minute: 6,
			side: "home"
		}],
		home: side$3("Aston Villa", "Villa", 4, [
			"W",
			"W",
			"D",
			"W",
			"L"
		], 1.66, 1.1),
		away: side$3("West Ham", "West Ham", 14, [
			"L",
			"D",
			"L",
			"W",
			"D"
		], 1.22, 1.48)
	},
	{
		id: "lv-tot-ful",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Tottenham Hotspur Stadium",
		offsetMin: 26,
		goals: [{
			minute: 19,
			side: "away"
		}, {
			minute: 24,
			side: "home"
		}],
		home: side$3("Tottenham", "Spurs", 11, [
			"L",
			"W",
			"D",
			"W",
			"L"
		], 1.58, 1.36),
		away: side$3("Fulham", "Fulham", 9, [
			"W",
			"D",
			"W",
			"L",
			"D"
		], 1.34, 1.2)
	},
	{
		id: "lv-wol-eve",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Molineux",
		offsetMin: 58,
		goals: [],
		flag: "Still goalless",
		home: side$3("Wolves", "Wolves", 16, [
			"L",
			"L",
			"D",
			"L",
			"W"
		], 1.05, 1.55),
		away: side$3("Everton", "Everton", 13, [
			"D",
			"W",
			"L",
			"D",
			"W"
		], 1.18, 1.32)
	},
	{
		id: "lv-rso-vil",
		league: "La Liga",
		code: "LAL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Reale Arena",
		offsetMin: 21,
		goals: [{
			minute: 17,
			side: "home"
		}],
		home: side$3("Real Sociedad", "Sociedad", 6, [
			"W",
			"D",
			"W",
			"W",
			"L"
		], 1.48, 1.12),
		away: side$3("Villarreal", "Villarreal", 5, [
			"W",
			"W",
			"D",
			"W",
			"D"
		], 1.62, 1.18)
	},
	{
		id: "lv-ath-gir",
		league: "La Liga",
		code: "LAL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "San Mames",
		offsetMin: 70,
		goals: [{
			minute: 38,
			side: "home"
		}, {
			minute: 66,
			side: "home"
		}],
		home: side$3("Athletic Club", "Athletic", 4, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.55, .98),
		away: side$3("Girona", "Girona", 10, [
			"L",
			"W",
			"D",
			"L",
			"W"
		], 1.28, 1.34)
	},
	{
		id: "lv-bet-val",
		league: "La Liga",
		code: "LAL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Benito Villamarin",
		offsetMin: 36,
		goals: [{
			minute: 29,
			side: "away"
		}],
		home: side$3("Real Betis", "Betis", 8, [
			"D",
			"W",
			"W",
			"L",
			"D"
		], 1.4, 1.22),
		away: side$3("Valencia", "Valencia", 11, [
			"L",
			"D",
			"W",
			"L",
			"D"
		], 1.16, 1.38)
	},
	{
		id: "lv-mil-laz",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "San Siro",
		offsetMin: 9,
		goals: [],
		home: side$3("AC Milan", "Milan", 3, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.68, 1.02),
		away: side$3("Lazio", "Lazio", 6, [
			"W",
			"L",
			"W",
			"D",
			"W"
		], 1.46, 1.14)
	},
	{
		id: "lv-ata-fio",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Gewiss Stadium",
		offsetMin: 49,
		goals: [
			{
				minute: 8,
				side: "home"
			},
			{
				minute: 41,
				side: "away"
			},
			{
				minute: 52,
				side: "home"
			}
		],
		flag: "Open game",
		home: side$3("Atalanta", "Atalanta", 5, [
			"W",
			"W",
			"W",
			"D",
			"L"
		], 1.82, 1.2),
		away: side$3("Fiorentina", "Fiorentina", 9, [
			"D",
			"W",
			"L",
			"W",
			"D"
		], 1.36, 1.28)
	},
	{
		id: "lv-bol-tor",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Renato Dall'Ara",
		offsetMin: 81,
		goals: [{
			minute: 73,
			side: "home"
		}],
		home: side$3("Bologna", "Bologna", 7, [
			"W",
			"D",
			"W",
			"D",
			"W"
		], 1.42, 1.08),
		away: side$3("Torino", "Torino", 10, [
			"D",
			"L",
			"W",
			"D",
			"L"
		], 1.2, 1.24)
	},
	{
		id: "lv-b04-rbl",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "BayArena",
		offsetMin: 16,
		goals: [{
			minute: 11,
			side: "away"
		}],
		home: side$3("Leverkusen", "Leverkusen", 2, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.9, 1.08),
		away: side$3("RB Leipzig", "Leipzig", 3, [
			"W",
			"W",
			"L",
			"W",
			"D"
		], 1.76, 1.16)
	},
	{
		id: "lv-sge-vfb",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Deutsche Bank Park",
		offsetMin: 39,
		goals: [
			{
				minute: 4,
				side: "home"
			},
			{
				minute: 27,
				side: "home"
			},
			{
				minute: 34,
				side: "away"
			}
		],
		home: side$3("Frankfurt", "Frankfurt", 5, [
			"W",
			"D",
			"W",
			"W",
			"L"
		], 1.7, 1.26),
		away: side$3("Stuttgart", "Stuttgart", 6, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.64, 1.3)
	},
	{
		id: "lv-scf-wob",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Europa-Park Stadion",
		offsetMin: 88,
		goals: [{
			minute: 55,
			side: "away"
		}],
		flag: "Late, one goal in it",
		home: side$3("Freiburg", "Freiburg", 8, [
			"D",
			"W",
			"D",
			"W",
			"L"
		], 1.38, 1.18),
		away: side$3("Wolfsburg", "Wolfsburg", 9, [
			"L",
			"W",
			"D",
			"W",
			"D"
		], 1.3, 1.28)
	},
	{
		id: "lv-nan-str",
		league: "Ligue 1",
		code: "FRA",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Stade de la Beaujoire",
		offsetMin: 24,
		goals: [{
			minute: 16,
			side: "away"
		}],
		home: side$3("Nantes", "Nantes", 12, [
			"L",
			"D",
			"W",
			"L",
			"D"
		], 1.08, 1.42),
		away: side$3("Strasbourg", "Strasbourg", 8, [
			"W",
			"D",
			"W",
			"L",
			"W"
		], 1.34, 1.22)
	},
	{
		id: "lv-hee-spa",
		league: "Eredivisie",
		code: "ERE",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Abe Lenstra Stadion",
		offsetMin: 47,
		goals: [{
			minute: 8,
			side: "home"
		}, {
			minute: 39,
			side: "away"
		}],
		home: side$3("Heerenveen", "Heerenveen", 8, [
			"D",
			"W",
			"L",
			"W",
			"D"
		], 1.4, 1.36),
		away: side$3("Sparta Rotterdam", "Sparta", 9, [
			"L",
			"W",
			"D",
			"L",
			"W"
		], 1.28, 1.34)
	},
	{
		id: "lv-gil-rio",
		league: "Primeira Liga",
		code: "POR",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Estadio Cidade de Barcelos",
		offsetMin: 33,
		goals: [],
		flag: "Still goalless",
		home: side$3("Gil Vicente", "Gil Vicente", 10, [
			"D",
			"L",
			"D",
			"W",
			"L"
		], 1.1, 1.28),
		away: side$3("Rio Ave", "Rio Ave", 11, [
			"L",
			"D",
			"W",
			"D",
			"L"
		], 1.06, 1.3)
	},
	{
		id: "lv-swa-sto",
		league: "Championship",
		code: "CHP",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Swansea.com Stadium",
		offsetMin: 61,
		goals: [{
			minute: 52,
			side: "home"
		}],
		home: side$3("Swansea", "Swansea", 8, [
			"W",
			"D",
			"W",
			"L",
			"D"
		], 1.34, 1.18),
		away: side$3("Stoke", "Stoke", 12, [
			"L",
			"D",
			"W",
			"D",
			"L"
		], 1.16, 1.26)
	},
	{
		id: "lv-hib-dun",
		league: "Scottish Premiership",
		code: "SPL",
		day: "Saturday",
		dateLabel: "In play",
		time: "Live",
		venue: "Easter Road",
		offsetMin: 14,
		goals: [{
			minute: 11,
			side: "home"
		}],
		home: side$3("Hibernian", "Hibs", 5, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.46, 1.2),
		away: side$3("Dundee", "Dundee", 10, [
			"L",
			"D",
			"L",
			"W",
			"D"
		], 1.02, 1.48)
	}
];
function liveFixture(id) {
	return LIVE_RAW.find((row) => row.id === id);
}
function side$2(name, short, pos, form, xgFor, xgAgainst) {
	return {
		name,
		short,
		pos,
		form,
		xgFor,
		xgAgainst,
		gf: Math.round(xgFor * 9),
		ga: Math.round(xgAgainst * 9),
		played: 9,
		out: []
	};
}
var RECENT_RAW = [
	{
		id: "r-mci-bur",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "14:00",
		venue: "Etihad Stadium",
		playedLabel: "Sun 1 Nov",
		homeGoals: 3,
		awayGoals: 1,
		home: side$2("Man City", "City", 2, [
			"W",
			"W",
			"W",
			"L",
			"W"
		], 1.96, 1.05),
		away: side$2("Burnley", "Burnley", 18, [
			"L",
			"L",
			"D",
			"L",
			"L"
		], .9, 1.8)
	},
	{
		id: "r-liv-bha",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "16:30",
		venue: "Anfield",
		playedLabel: "Sun 1 Nov",
		homeGoals: 2,
		awayGoals: 1,
		home: side$2("Liverpool", "Liverpool", 3, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.82, 1.12),
		away: side$2("Brighton", "Brighton", 8, [
			"D",
			"W",
			"L",
			"W",
			"D"
		], 1.52, 1.24)
	},
	{
		id: "r-bar-rso",
		league: "La Liga",
		code: "LAL",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "20:00",
		venue: "Spotify Camp Nou",
		playedLabel: "Sun 1 Nov",
		homeGoals: 1,
		awayGoals: 1,
		home: side$2("Barcelona", "Barcelona", 1, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 2.12, .88),
		away: side$2("Real Sociedad", "Sociedad", 8, [
			"D",
			"W",
			"L",
			"D",
			"W"
		], 1.3, 1.2)
	},
	{
		id: "r-int-tor",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "17:00",
		venue: "San Siro",
		playedLabel: "Sun 1 Nov",
		homeGoals: 2,
		awayGoals: 0,
		home: side$2("Inter", "Inter", 1, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.98, .82),
		away: side$2("Torino", "Torino", 10, [
			"D",
			"D",
			"L",
			"W",
			"D"
		], 1.12, 1.05)
	},
	{
		id: "r-bay-koe",
		league: "Bundesliga",
		code: "BUN",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "17:30",
		venue: "Allianz Arena",
		playedLabel: "Sun 1 Nov",
		homeGoals: 4,
		awayGoals: 1,
		home: side$2("Bayern", "Bayern", 1, [
			"W",
			"W",
			"W",
			"W",
			"D"
		], 2.24, .92),
		away: side$2("FC Cologne", "Cologne", 13, [
			"L",
			"D",
			"L",
			"W",
			"L"
		], 1.28, 1.46)
	},
	{
		id: "r-che-ful",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Mon 2 Nov",
		time: "20:00",
		venue: "Stamford Bridge",
		playedLabel: "Mon 2 Nov",
		homeGoals: 1,
		awayGoals: 1,
		home: side$2("Chelsea", "Chelsea", 5, [
			"W",
			"D",
			"L",
			"W",
			"W"
		], 1.7, 1.16),
		away: side$2("Fulham", "Fulham", 11, [
			"W",
			"D",
			"L",
			"W",
			"D"
		], 1.34, 1.28)
	},
	{
		id: "r-rma-sev",
		league: "La Liga",
		code: "LAL",
		day: "Sunday",
		dateLabel: "Mon 2 Nov",
		time: "20:00",
		venue: "Santiago Bernabeu",
		playedLabel: "Mon 2 Nov",
		homeGoals: 2,
		awayGoals: 0,
		home: side$2("Real Madrid", "Madrid", 3, [
			"W",
			"W",
			"W",
			"L",
			"W"
		], 1.92, 1.02),
		away: side$2("Sevilla", "Sevilla", 12, [
			"L",
			"D",
			"W",
			"L",
			"D"
		], 1.15, 1.4)
	},
	{
		id: "r-juv-mil",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Mon 2 Nov",
		time: "19:45",
		venue: "Allianz Stadium",
		playedLabel: "Mon 2 Nov",
		homeGoals: 0,
		awayGoals: 0,
		home: side$2("Juventus", "Juventus", 4, [
			"W",
			"D",
			"W",
			"W",
			"D"
		], 1.48, .86),
		away: side$2("AC Milan", "Milan", 6, [
			"W",
			"L",
			"W",
			"D",
			"W"
		], 1.6, 1.14)
	},
	{
		id: "r-bvb-rbl",
		league: "Bundesliga",
		code: "BUN",
		day: "Sunday",
		dateLabel: "Tue 3 Nov",
		time: "19:30",
		venue: "Signal Iduna Park",
		playedLabel: "Tue 3 Nov",
		homeGoals: 2,
		awayGoals: 2,
		home: side$2("Dortmund", "Dortmund", 4, [
			"W",
			"D",
			"W",
			"L",
			"W"
		], 1.88, 1.22),
		away: side$2("RB Leipzig", "Leipzig", 5, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.7, 1.18)
	},
	{
		id: "r-atm-val",
		league: "La Liga",
		code: "LAL",
		day: "Sunday",
		dateLabel: "Tue 3 Nov",
		time: "20:00",
		venue: "Metropolitano",
		playedLabel: "Tue 3 Nov",
		homeGoals: 1,
		awayGoals: 0,
		home: side$2("Atletico Madrid", "Atletico", 4, [
			"W",
			"W",
			"D",
			"W",
			"D"
		], 1.58, .96),
		away: side$2("Valencia", "Valencia", 19, [
			"L",
			"D",
			"L",
			"W",
			"L"
		], .94, 1.66)
	},
	{
		id: "r-new-lee",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Wed 4 Nov",
		time: "19:30",
		venue: "St James' Park",
		playedLabel: "Wed 4 Nov",
		homeGoals: 2,
		awayGoals: 1,
		home: side$2("Newcastle", "Newcastle", 6, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.62, 1.18),
		away: side$2("Leeds United", "Leeds", 12, [
			"D",
			"L",
			"D",
			"D",
			"L"
		], 1.22, 1.48)
	},
	{
		id: "r-nap-gen",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Wed 4 Nov",
		time: "17:30",
		venue: "Diego Armando Maradona",
		playedLabel: "Wed 4 Nov",
		homeGoals: 3,
		awayGoals: 1,
		home: side$2("Napoli", "Napoli", 2, [
			"W",
			"W",
			"W",
			"D",
			"W"
		], 1.74, .9),
		away: side$2("Genoa", "Genoa", 14, [
			"L",
			"D",
			"L",
			"W",
			"D"
		], 1.02, 1.38)
	},
	{
		id: "r-psg-ren",
		league: "Ligue 1",
		code: "FRA",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "20:00",
		venue: "Parc des Princes",
		playedLabel: "Sun 1 Nov",
		homeGoals: 3,
		awayGoals: 0,
		home: side$2("Paris Saint-Germain", "PSG", 1, [
			"W",
			"W",
			"W",
			"W",
			"W"
		], 2.18, .84),
		away: side$2("Rennes", "Rennes", 9, [
			"L",
			"D",
			"W",
			"L",
			"D"
		], 1.18, 1.36)
	},
	{
		id: "r-twe-aja",
		league: "Eredivisie",
		code: "ERE",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "13:30",
		venue: "De Grolsch Veste",
		playedLabel: "Sun 1 Nov",
		homeGoals: 1,
		awayGoals: 1,
		home: side$2("Twente", "Twente", 4, [
			"D",
			"W",
			"W",
			"D",
			"W"
		], 1.58, 1.14),
		away: side$2("Ajax", "Ajax", 2, [
			"W",
			"W",
			"L",
			"W",
			"W"
		], 2.04, 1.12)
	},
	{
		id: "r-bra-gui",
		league: "Primeira Liga",
		code: "POR",
		day: "Sunday",
		dateLabel: "Sat 31 Oct",
		time: "18:00",
		venue: "Estadio Municipal de Braga",
		playedLabel: "Sat 31 Oct",
		homeGoals: 2,
		awayGoals: 0,
		home: side$2("Braga", "Braga", 4, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.48, 1.08),
		away: side$2("Vitoria Guimaraes", "Guimaraes", 6, [
			"D",
			"W",
			"L",
			"D",
			"W"
		], 1.28, 1.18)
	},
	{
		id: "r-lei-mid",
		league: "Championship",
		code: "CHP",
		day: "Sunday",
		dateLabel: "Sat 31 Oct",
		time: "15:00",
		venue: "King Power Stadium",
		playedLabel: "Sat 31 Oct",
		homeGoals: 2,
		awayGoals: 2,
		home: side$2("Leicester", "Leicester", 1, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.72, .98),
		away: side$2("Middlesbrough", "Middlesbrough", 5, [
			"W",
			"D",
			"W",
			"D",
			"L"
		], 1.38, 1.12)
	},
	{
		id: "r-ran-hib",
		league: "Scottish Premiership",
		code: "SPL",
		day: "Sunday",
		dateLabel: "Sun 1 Nov",
		time: "15:00",
		venue: "Ibrox",
		playedLabel: "Sun 1 Nov",
		homeGoals: 2,
		awayGoals: 1,
		home: side$2("Rangers", "Rangers", 2, [
			"W",
			"W",
			"D",
			"W",
			"W"
		], 1.82, .88),
		away: side$2("Hibernian", "Hibs", 5, [
			"W",
			"W",
			"D",
			"L",
			"W"
		], 1.46, 1.2)
	}
];
function side$1(name, short, pos, form, xgFor, xgAgainst, out = []) {
	return {
		name,
		short,
		pos,
		form,
		xgFor,
		xgAgainst,
		gf: Math.round(xgFor * 10),
		ga: Math.round(xgAgainst * 10),
		played: 10,
		out
	};
}
function game$1(id, league, code, day, dateLabel, time, venue, home, away) {
	return {
		id,
		league,
		code,
		day,
		dateLabel,
		time,
		venue,
		home,
		away
	};
}
var MORE_MATCHES = [
	game$1("psg-mar", "Ligue 1", "FRA", "Saturday", "Sat 7 Nov", "20:00", "Parc des Princes", side$1("Paris Saint-Germain", "PSG", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.18, .84, ["Ousmane Dembele (managed)"]), side$1("Marseille", "Marseille", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.64, 1.18)),
	game$1("mon-lil", "Ligue 1", "FRA", "Saturday", "Sat 7 Nov", "17:00", "Stade Louis II", side$1("Monaco", "Monaco", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.86, 1.02), side$1("Lille", "Lille", 4, [
		"W",
		"D",
		"W",
		"D",
		"L"
	], 1.48, 1.08)),
	game$1("lyo-nic", "Ligue 1", "FRA", "Sunday", "Sun 8 Nov", "19:45", "Groupama Stadium", side$1("Lyon", "Lyon", 6, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.42, 1.28), side$1("Nice", "Nice", 5, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.38, 1.12)),
	game$1("aja-fey", "Eredivisie", "ERE", "Sunday", "Sun 8 Nov", "13:30", "Johan Cruijff ArenA", side$1("Ajax", "Ajax", 2, [
		"W",
		"W",
		"L",
		"W",
		"W"
	], 2.04, 1.12), side$1("Feyenoord", "Feyenoord", 3, [
		"W",
		"D",
		"W",
		"W",
		"D"
	], 1.78, 1.16)),
	game$1("psv-az", "Eredivisie", "ERE", "Saturday", "Sat 7 Nov", "19:00", "Philips Stadion", side$1("PSV", "PSV", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.22, .92), side$1("AZ", "AZ", 5, [
		"W",
		"D",
		"L",
		"W",
		"W"
	], 1.52, 1.2)),
	game$1("twe-utr", "Eredivisie", "ERE", "Sunday", "Sun 8 Nov", "15:45", "De Grolsch Veste", side$1("Twente", "Twente", 4, [
		"D",
		"W",
		"W",
		"D",
		"W"
	], 1.58, 1.14), side$1("Utrecht", "Utrecht", 7, [
		"W",
		"L",
		"D",
		"W",
		"D"
	], 1.36, 1.28)),
	game$1("ben-por", "Primeira Liga", "POR", "Saturday", "Sat 7 Nov", "21:15", "Estadio da Luz", side$1("Benfica", "Benfica", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.08, .78), side$1("Porto", "Porto", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.84, .9)),
	game$1("spo-bra", "Primeira Liga", "POR", "Sunday", "Sun 8 Nov", "21:15", "Estadio Jose Alvalade", side$1("Sporting", "Sporting", 3, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.76, .96), side$1("Braga", "Braga", 4, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.48, 1.08)),
	game$1("gui-fam", "Primeira Liga", "POR", "Saturday", "Sat 7 Nov", "18:00", "Estadio D. Afonso Henriques", side$1("Vitoria Guimaraes", "Guimaraes", 6, [
		"D",
		"W",
		"L",
		"D",
		"W"
	], 1.28, 1.18), side$1("Famalicao", "Famalicao", 8, [
		"L",
		"D",
		"W",
		"D",
		"L"
	], 1.12, 1.32)),
	game$1("lei-sou", "Championship", "CHP", "Saturday", "Sat 7 Nov", "12:30", "King Power Stadium", side$1("Leicester", "Leicester", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.72, .98), side$1("Southampton", "Southampton", 4, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.46, 1.14)),
	game$1("bur-shu", "Championship", "CHP", "Saturday", "Sat 7 Nov", "15:00", "Turf Moor", side$1("Burnley", "Burnley", 3, [
		"W",
		"W",
		"D",
		"W",
		"D"
	], 1.44, .92), side$1("Sheffield United", "Sheffield Utd", 6, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.32, 1.16)),
	game$1("mid-nor", "Championship", "CHP", "Sunday", "Sun 8 Nov", "15:00", "Riverside Stadium", side$1("Middlesbrough", "Middlesbrough", 5, [
		"W",
		"D",
		"W",
		"D",
		"L"
	], 1.38, 1.12), side$1("Norwich", "Norwich", 9, [
		"L",
		"W",
		"D",
		"L",
		"W"
	], 1.22, 1.28)),
	game$1("cel-ran", "Scottish Premiership", "SPL", "Sunday", "Sun 8 Nov", "12:00", "Celtic Park", side$1("Celtic", "Celtic", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.12, .72), side$1("Rangers", "Rangers", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.82, .88)),
	game$1("abd-hea", "Scottish Premiership", "SPL", "Saturday", "Sat 7 Nov", "15:00", "Pittodrie", side$1("Aberdeen", "Aberdeen", 4, [
		"W",
		"D",
		"L",
		"W",
		"D"
	], 1.36, 1.14), side$1("Hearts", "Hearts", 3, [
		"W",
		"W",
		"D",
		"W",
		"L"
	], 1.48, 1.06)),
	game$1("eve-wol", "Premier League", "EPL", "Saturday", "Sat 7 Nov", "15:00", "Goodison Park", side$1("Everton", "Everton", 8, [
		"D",
		"W",
		"L",
		"D",
		"W"
	], 1.34, 1.22), side$1("Wolves", "Wolves", 16, [
		"L",
		"L",
		"D",
		"L",
		"W"
	], 1.02, 1.62)),
	game$1("ucl-ars-bay", "Champions League", "UCL", "Midweek", "Tue 10 Nov", "20:00", "Emirates Stadium", side$1("Arsenal", "Arsenal", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.05, .86), side$1("Bayern Munich", "Bayern", 2, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.24, .98)),
	game$1("ucl-liv-rma", "Champions League", "UCL", "Midweek", "Tue 10 Nov", "20:00", "Anfield", side$1("Liverpool", "Liverpool", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.92, .94), side$1("Real Madrid", "Real Madrid", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.08, .9)),
	game$1("ucl-bar-int", "Champions League", "UCL", "Midweek", "Wed 11 Nov", "20:00", "Spotify Camp Nou", side$1("Barcelona", "Barcelona", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.16, .88), side$1("Inter", "Inter", 2, [
		"W",
		"D",
		"W",
		"W",
		"W"
	], 1.74, .82)),
	game$1("ucl-psg-mci", "Champions League", "UCL", "Midweek", "Wed 11 Nov", "20:00", "Parc des Princes", side$1("Paris Saint-Germain", "PSG", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.18, .84), side$1("Manchester City", "Man City", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 2.12, .8)),
	game$1("ucl-atm-bvb", "Champions League", "UCL", "Midweek", "Tue 10 Nov", "17:45", "Metropolitano", side$1("Atletico Madrid", "Atletico", 4, [
		"W",
		"D",
		"W",
		"D",
		"W"
	], 1.46, .96), side$1("Borussia Dortmund", "Dortmund", 3, [
		"W",
		"W",
		"L",
		"W",
		"D"
	], 1.72, 1.18)),
	game$1("ucl-ben-juv", "Champions League", "UCL", "Midweek", "Wed 11 Nov", "17:45", "Estadio da Luz", side$1("Benfica", "Benfica", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.08, .78), side$1("Juventus", "Juventus", 5, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.42, 1.04)),
	game$1("ucl-spo-nap", "Champions League", "UCL", "Midweek", "Tue 10 Nov", "17:45", "Estadio Jose Alvalade", side$1("Sporting", "Sporting", 3, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.76, .96), side$1("Napoli", "Napoli", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.88, .86)),
	game$1("ucl-psv-ata", "Champions League", "UCL", "Midweek", "Wed 11 Nov", "17:45", "Philips Stadion", side$1("PSV", "PSV", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.22, .92), side$1("Atalanta", "Atalanta", 6, [
		"W",
		"D",
		"L",
		"W",
		"W"
	], 1.62, 1.14)),
	game$1("uel-mun-por", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "20:00", "Old Trafford", side$1("Manchester United", "Man Utd", 7, [
		"W",
		"L",
		"D",
		"W",
		"W"
	], 1.58, 1.24), side$1("Porto", "Porto", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.84, .9)),
	game$1("uel-tot-ran", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "20:00", "Tottenham Hotspur Stadium", side$1("Tottenham", "Spurs", 9, [
		"L",
		"D",
		"W",
		"W",
		"W"
	], 1.58, 1.36), side$1("Rangers", "Rangers", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.82, .88)),
	game$1("uel-rom-lyo", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "17:45", "Stadio Olimpico", side$1("Roma", "Roma", 4, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.52, 1.08), side$1("Lyon", "Lyon", 6, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.42, 1.28)),
	game$1("uel-aja-cel", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "17:45", "Johan Cruijff ArenA", side$1("Ajax", "Ajax", 2, [
		"W",
		"W",
		"L",
		"W",
		"W"
	], 2.04, 1.12), side$1("Celtic", "Celtic", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.12, .72)),
	game$1("uel-bet-fey", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "20:00", "Benito Villamarin", side$1("Real Betis", "Betis", 8, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.34, 1.22), side$1("Feyenoord", "Feyenoord", 3, [
		"W",
		"D",
		"W",
		"W",
		"D"
	], 1.78, 1.16)),
	game$1("uel-az-lil", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "17:45", "AFAS Stadion", side$1("AZ", "AZ", 5, [
		"W",
		"D",
		"L",
		"W",
		"W"
	], 1.52, 1.2), side$1("Lille", "Lille", 4, [
		"W",
		"D",
		"W",
		"D",
		"L"
	], 1.48, 1.08)),
	game$1("uec-che-bas", "Conference League", "UEC", "Midweek", "Thu 12 Nov", "20:00", "Stamford Bridge", side$1("Chelsea", "Chelsea", 4, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.84, 1.02), side$1("Basel", "Basel", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.46, 1.12)),
	game$1("uec-fio-hea", "Conference League", "UEC", "Midweek", "Thu 12 Nov", "17:45", "Stadio Franchi", side$1("Fiorentina", "Fiorentina", 9, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.28, 1.18), side$1("Hearts", "Hearts", 3, [
		"W",
		"W",
		"D",
		"W",
		"L"
	], 1.48, 1.06)),
	game$1("uec-mol-leg", "Conference League", "UEC", "Midweek", "Thu 12 Nov", "17:45", "Aker Stadion", side$1("Molde", "Molde", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.44, 1.16), side$1("Legia Warsaw", "Legia", 2, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.38, 1.1)),
	game$1("uec-gen-lar", "Conference League", "UEC", "Midweek", "Thu 12 Nov", "20:00", "Ghelamco Arena", side$1("Gent", "Gent", 5, [
		"D",
		"W",
		"L",
		"D",
		"W"
	], 1.32, 1.24), side$1("Larnaca", "Larnaca", 1, [
		"W",
		"W",
		"D",
		"W",
		"L"
	], 1.22, 1.08)),
	game$1("lib-fla-pal", "Copa Libertadores", "LIB", "Midweek", "Wed 11 Nov", "00:30", "Maracana", side$1("Flamengo", "Flamengo", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.96, .84), side$1("Palmeiras", "Palmeiras", 2, [
		"W",
		"D",
		"W",
		"W",
		"W"
	], 1.72, .78)),
	game$1("lib-riv-boc", "Copa Libertadores", "LIB", "Midweek", "Wed 11 Nov", "00:30", "Mas Monumental", side$1("River Plate", "River", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.68, .82), side$1("Boca Juniors", "Boca", 3, [
		"W",
		"D",
		"L",
		"W",
		"D"
	], 1.36, .94)),
	game$1("lib-flu-gre", "Copa Libertadores", "LIB", "Midweek", "Thu 12 Nov", "00:30", "Maracana", side$1("Fluminense", "Fluminense", 4, [
		"D",
		"W",
		"W",
		"L",
		"D"
	], 1.42, 1.08), side$1("Gremio", "Gremio", 5, [
		"W",
		"L",
		"D",
		"W",
		"W"
	], 1.38, 1.12)),
	game$1("lib-pen-nac", "Copa Libertadores", "LIB", "Midweek", "Thu 12 Nov", "00:30", "Campeon del Siglo", side$1("Penarol", "Penarol", 1, [
		"W",
		"W",
		"D",
		"W",
		"L"
	], 1.48, .96), side$1("Nacional", "Nacional", 2, [
		"W",
		"D",
		"W",
		"D",
		"W"
	], 1.34, 1.02)),
	game$1("lib-sao-cam", "Copa Libertadores", "LIB", "Midweek", "Wed 11 Nov", "23:00", "Morumbi", side$1("Sao Paulo", "Sao Paulo", 6, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.36, 1.14), side$1("Atletico Mineiro", "Atletico-MG", 3, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.58, 1.02)),
	game$1("sud-ldu-bsc", "Copa Sudamericana", "SUD", "Midweek", "Thu 12 Nov", "01:00", "Casa Blanca", side$1("LDU Quito", "LDU", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.48, .98), side$1("Barcelona SC", "Barcelona SC", 4, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.32, 1.14)),
	game$1("sud-idv-bol", "Copa Sudamericana", "SUD", "Midweek", "Thu 12 Nov", "23:00", "Banco Guayaquil", side$1("Independiente del Valle", "IDV", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.66, .9), side$1("Bolivar", "Bolivar", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.4, 1.08)),
	game$1("b2-hsv-s04", "2. Bundesliga", "B2", "Saturday", "Sat 7 Nov", "12:00", "Volksparkstadion", side$1("Hamburger SV", "Hamburg", 2, [
		"W",
		"D",
		"W",
		"W",
		"D"
	], 1.58, 1.06), side$1("Schalke", "Schalke", 6, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.36, 1.22)),
	game$1("b2-bsc-fck", "2. Bundesliga", "B2", "Sunday", "Sun 8 Nov", "12:30", "Olympiastadion", side$1("Hertha Berlin", "Hertha", 8, [
		"L",
		"D",
		"W",
		"D",
		"L"
	], 1.28, 1.24), side$1("Kaiserslautern", "Lautern", 5, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.42, 1.16)),
	game$1("l1-bir-wre", "League One", "L1", "Saturday", "Sat 7 Nov", "15:00", "St Andrew's", side$1("Birmingham", "Birmingham", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.7, .96), side$1("Wrexham", "Wrexham", 3, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.52, 1.08)),
	game$1("l1-bol-sto", "League One", "L1", "Saturday", "Sat 7 Nov", "15:00", "Toughsheet", side$1("Bolton", "Bolton", 4, [
		"W",
		"D",
		"L",
		"W",
		"W"
	], 1.44, 1.12), side$1("Stockport", "Stockport", 2, [
		"W",
		"W",
		"D",
		"W",
		"D"
	], 1.58, 1.02)),
	game$1("mls-lafc-mia", "MLS", "MLS", "Saturday", "Sat 7 Nov", "20:30", "BMO Stadium", side$1("Los Angeles FC", "LAFC", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.62, 1.08), side$1("Inter Miami", "Miami", 3, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.74, 1.16)),
	game$1("mls-cin-clb", "MLS", "MLS", "Sunday", "Sun 8 Nov", "19:30", "TQL Stadium", side$1("FC Cincinnati", "Cincinnati", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.68, .98), side$1("Columbus Crew", "Columbus", 4, [
		"W",
		"L",
		"W",
		"D",
		"W"
	], 1.5, 1.12)),
	game$1("mex-ame-chv", "Liga MX", "MEX", "Saturday", "Sat 7 Nov", "23:00", "Estadio Azteca", side$1("Club America", "America", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.72, .92), side$1("Guadalajara", "Chivas", 5, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.34, 1.1)),
	game$1("mex-mty-tig", "Liga MX", "MEX", "Sunday", "Sun 8 Nov", "01:00", "BBVA", side$1("Monterrey", "Monterrey", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.56, .96), side$1("Tigres", "Tigres", 3, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.6, 1.02)),
	game$1("bra-pal-bot", "Brasileirao", "BRA", "Sunday", "Sun 8 Nov", "20:00", "Allianz Parque", side$1("Palmeiras", "Palmeiras", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.78, .84), side$1("Botafogo", "Botafogo", 4, [
		"W",
		"D",
		"L",
		"W",
		"W"
	], 1.46, 1.04)),
	game$1("bra-fla-cor", "Brasileirao", "BRA", "Saturday", "Sat 7 Nov", "22:00", "Maracana", side$1("Flamengo", "Flamengo", 2, [
		"W",
		"W",
		"W",
		"D",
		"L"
	], 1.9, .88), side$1("Corinthians", "Corinthians", 8, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.22, 1.28)),
	game$1("arg-rac-ind", "Liga Profesional", "ARG", "Sunday", "Sun 8 Nov", "19:00", "Presidente Peron", side$1("Racing", "Racing", 2, [
		"W",
		"D",
		"W",
		"W",
		"D"
	], 1.52, .96), side$1("Independiente", "Independiente", 6, [
		"L",
		"W",
		"D",
		"W",
		"L"
	], 1.28, 1.14)),
	game$1("arg-boc-slo", "Liga Profesional", "ARG", "Saturday", "Sat 7 Nov", "20:00", "La Bombonera", side$1("Boca Juniors", "Boca", 3, [
		"W",
		"D",
		"L",
		"W",
		"D"
	], 1.44, .98), side$1("San Lorenzo", "San Lorenzo", 7, [
		"D",
		"W",
		"L",
		"D",
		"W"
	], 1.26, 1.18)),
	game$1("tur-gal-fen", "Super Lig", "TUR", "Sunday", "Sun 8 Nov", "17:00", "Rams Park", side$1("Galatasaray", "Galatasaray", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.02, .82), side$1("Fenerbahce", "Fenerbahce", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.78, .9)),
	game$1("tur-bes-tra", "Super Lig", "TUR", "Saturday", "Sat 7 Nov", "17:00", "Besiktas Park", side$1("Besiktas", "Besiktas", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.56, 1.08), side$1("Trabzonspor", "Trabzonspor", 5, [
		"D",
		"W",
		"W",
		"L",
		"D"
	], 1.4, 1.16)),
	game$1("bel-bru-and", "Pro League", "BEL", "Sunday", "Sun 8 Nov", "18:30", "Jan Breydel", side$1("Club Brugge", "Brugge", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.84, .88), side$1("Anderlecht", "Anderlecht", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.5, 1.06)),
	game$1("bel-gnk-ant", "Pro League", "BEL", "Saturday", "Sat 7 Nov", "19:45", "Cegeka Arena", side$1("Genk", "Genk", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.58, 1.02), side$1("Antwerp", "Antwerp", 6, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.32, 1.2)),
	game$1("gre-oly-pao", "Super League", "GRE", "Sunday", "Sun 8 Nov", "18:00", "Georgios Karaiskakis", side$1("Olympiacos", "Olympiacos", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.86, .84), side$1("Panathinaikos", "Panathinaikos", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.52, .98)),
	game$1("gre-paok-aek", "Super League", "GRE", "Saturday", "Sat 7 Nov", "18:00", "Toumba", side$1("PAOK", "PAOK", 3, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.6, .94), side$1("AEK Athens", "AEK", 4, [
		"D",
		"W",
		"W",
		"L",
		"D"
	], 1.48, 1.06)),
	game$1("aut-sal-stu", "Bundesliga", "AUT", "Sunday", "Sun 8 Nov", "16:00", "Red Bull Arena", side$1("Red Bull Salzburg", "Salzburg", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 2.04, .78), side$1("Sturm Graz", "Sturm", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.62, .96)),
	game$1("aut-rap-wac", "Bundesliga", "AUT", "Saturday", "Sat 7 Nov", "16:00", "Allianz Stadion", side$1("Rapid Wien", "Rapid", 4, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.4, 1.12), side$1("Austria Wien", "Austria Wien", 6, [
		"L",
		"D",
		"W",
		"D",
		"W"
	], 1.28, 1.22)),
	game$1("sui-yb-bas", "Super League", "SUI", "Sunday", "Sun 8 Nov", "15:30", "Wankdorf", side$1("Young Boys", "Young Boys", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.8, .9), side$1("Basel", "Basel", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.46, 1.04)),
	game$1("sui-ser-zur", "Super League", "SUI", "Saturday", "Sat 7 Nov", "17:00", "Stade de Geneve", side$1("Servette", "Servette", 4, [
		"D",
		"W",
		"W",
		"L",
		"D"
	], 1.38, 1.14), side$1("Zurich", "Zurich", 5, [
		"W",
		"L",
		"D",
		"W",
		"L"
	], 1.3, 1.2)),
	game$1("sau-hil-nsr", "Saudi Pro League", "SAU", "Saturday", "Sat 7 Nov", "17:00", "Kingdom Arena", side$1("Al Hilal", "Al Hilal", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.16, .72), side$1("Al Nassr", "Al Nassr", 2, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.92, .86)),
	game$1("sau-itt-ahl", "Saudi Pro League", "SAU", "Saturday", "Sat 7 Nov", "14:00", "King Abdullah Sports City", side$1("Al Ittihad", "Al Ittihad", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.64, 1.02), side$1("Al Ahli", "Al Ahli", 4, [
		"W",
		"W",
		"D",
		"D",
		"L"
	], 1.48, 1.08)),
	game$1("j1-kob-yfm", "J.League", "J1", "Saturday", "Sat 7 Nov", "06:00", "Noevir Stadium", side$1("Vissel Kobe", "Kobe", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.7, .88), side$1("Yokohama F. Marinos", "Marinos", 4, [
		"W",
		"L",
		"W",
		"D",
		"W"
	], 1.48, 1.1)),
	game$1("j1-kas-ura", "J.League", "J1", "Sunday", "Sun 8 Nov", "05:00", "Kashima Stadium", side$1("Kashima Antlers", "Kashima", 3, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.52, .98), side$1("Urawa Reds", "Urawa", 5, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.36, 1.12)),
	game$1("ken-gor-leo", "Kenyan Premier League", "KEN", "Sunday", "Sun 8 Nov", "14:00", "Kasarani", side$1("Gor Mahia", "Gor", 1, [
		"W",
		"W",
		"D",
		"W",
		"W"
	], 1.54, .82), side$1("AFC Leopards", "Leopards", 4, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.12, 1.18)),
	game$1("ken-tus-ban", "Kenyan Premier League", "KEN", "Saturday", "Sat 7 Nov", "14:00", "Ruaraka", side$1("Tusker", "Tusker", 3, [
		"W",
		"D",
		"W",
		"L",
		"D"
	], 1.32, 1.04), side$1("Bandari", "Bandari", 8, [
		"L",
		"D",
		"W",
		"L",
		"D"
	], 1.08, 1.26)),
	game$1("nga-eny-ran", "NPFL", "NGA", "Sunday", "Sun 8 Nov", "15:00", "Enyimba Stadium", side$1("Enyimba", "Enyimba", 2, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.42, .96), side$1("Rangers International", "Rangers", 5, [
		"D",
		"W",
		"L",
		"W",
		"D"
	], 1.18, 1.12)),
	game$1("nga-rem-rvs", "NPFL", "NGA", "Saturday", "Sat 7 Nov", "15:00", "Remo Stars Stadium", side$1("Remo Stars", "Remo", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.58, .88), side$1("Rivers United", "Rivers", 3, [
		"W",
		"D",
		"W",
		"L",
		"W"
	], 1.28, 1.02)),
	game$1("rsa-sun-orl", "Premier Soccer League", "RSA", "Saturday", "Sat 7 Nov", "13:30", "Loftus Versfeld", side$1("Mamelodi Sundowns", "Sundowns", 1, [
		"W",
		"W",
		"W",
		"W",
		"D"
	], 2.08, .7), side$1("Orlando Pirates", "Pirates", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.46, .92)),
	game$1("rsa-kcz-ste", "Premier Soccer League", "RSA", "Sunday", "Sun 8 Nov", "13:30", "Moses Mabhida", side$1("Kaizer Chiefs", "Chiefs", 6, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.28, 1.16), side$1("Stellenbosch", "Stellenbosch", 3, [
		"W",
		"W",
		"D",
		"L",
		"W"
	], 1.36, 1.04)),
	game$1("egy-ahl-zam", "Egyptian Premier League", "EGY", "Sunday", "Sun 8 Nov", "18:00", "Cairo Stadium", side$1("Al Ahly", "Ahly", 1, [
		"W",
		"W",
		"W",
		"D",
		"W"
	], 1.92, .68), side$1("Zamalek", "Zamalek", 2, [
		"W",
		"D",
		"W",
		"W",
		"L"
	], 1.44, .86)),
	game$1("egy-pyr-fut", "Egyptian Premier League", "EGY", "Saturday", "Sat 7 Nov", "16:00", "30 June Stadium", side$1("Pyramids", "Pyramids", 3, [
		"W",
		"W",
		"D",
		"W",
		"L"
	], 1.58, .94), side$1("Modern Future", "Future", 7, [
		"D",
		"L",
		"W",
		"D",
		"W"
	], 1.16, 1.22))
];
function side(name, short, pos, form, xgFor, xgAgainst) {
	return {
		name,
		short,
		pos,
		form,
		xgFor,
		xgAgainst,
		gf: Math.round(xgFor * 10),
		ga: Math.round(xgAgainst * 10),
		played: 10,
		out: []
	};
}
function game(id, league, code, day, dateLabel, time, venue, home, away) {
	return {
		id,
		league,
		code,
		day,
		dateLabel,
		time,
		venue,
		home,
		away
	};
}
var W = [
	"W",
	"W",
	"D",
	"W",
	"W"
];
var M = [
	"W",
	"D",
	"L",
	"W",
	"D"
];
var L = [
	"L",
	"D",
	"W",
	"L",
	"D"
];
var REST_MATCHES = [
	game("epl-whu-bri", "Premier League", "EPL", "Sunday", "Sun 8 Nov", "14:00", "London Stadium", side("West Ham", "West Ham", 14, M, 1.24, 1.48), side("Brighton", "Brighton", 6, W, 1.62, 1.12)),
	game("epl-cry-nfo", "Premier League", "EPL", "Saturday", "Sat 7 Nov", "15:00", "Selhurst Park", side("Crystal Palace", "Palace", 11, M, 1.28, 1.26), side("Nottingham Forest", "Forest", 10, M, 1.36, 1.22)),
	game("ucl-atm-psv", "Champions League", "UCL", "Midweek", "Tue 10 Nov", "20:00", "Metropolitano", side("Atletico Madrid", "Atletico", 4, W, 1.52, .9), side("PSV", "PSV", 1, W, 1.84, 1.02)),
	game("ucl-juv-ben", "Champions League", "UCL", "Midweek", "Wed 11 Nov", "20:00", "Allianz Stadium", side("Juventus", "Juventus", 5, M, 1.46, 1.02), side("Benfica", "Benfica", 1, W, 1.78, .86)),
	game("uel-lyo-rom", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "20:00", "Groupama Stadium", side("Lyon", "Lyon", 6, M, 1.48, 1.18), side("Roma", "Roma", 4, W, 1.56, 1.04)),
	game("uel-cel-aja", "Europa League", "UEL", "Midweek", "Thu 12 Nov", "20:00", "Celtic Park", side("Celtic", "Celtic", 1, W, 1.92, .78), side("Ajax", "Ajax", 2, W, 1.74, 1.08)),
	game("lal-sev-bet", "La Liga", "LAL", "Saturday", "Sat 7 Nov", "17:30", "Ramon Sanchez-Pizjuan", side("Sevilla", "Sevilla", 12, L, 1.22, 1.34), side("Real Betis", "Betis", 8, M, 1.4, 1.16)),
	game("lal-soc-vil", "La Liga", "LAL", "Sunday", "Sun 8 Nov", "13:00", "Reale Arena", side("Real Sociedad", "Sociedad", 6, M, 1.46, 1.08), side("Villarreal", "Villarreal", 5, W, 1.58, 1.12)),
	game("sea-udi-bol", "Serie A", "SEA", "Sunday", "Sun 8 Nov", "14:00", "Bluenergy Stadium", side("Udinese", "Udinese", 11, L, 1.16, 1.32), side("Bologna", "Bologna", 7, M, 1.38, 1.08)),
	game("sea-cag-ver", "Serie A", "SEA", "Saturday", "Sat 7 Nov", "17:00", "Unipol Domus", side("Cagliari", "Cagliari", 14, L, 1.08, 1.4), side("Verona", "Verona", 16, L, 1.02, 1.48)),
	game("bun-uni-hof", "Bundesliga", "BUN", "Saturday", "Sat 7 Nov", "15:30", "Altes Stadion", side("Union Berlin", "Union", 9, M, 1.28, 1.18), side("Hoffenheim", "Hoffenheim", 8, M, 1.52, 1.36)),
	game("bun-wob-aug", "Bundesliga", "BUN", "Sunday", "Sun 8 Nov", "16:30", "Volkswagen Arena", side("Wolfsburg", "Wolfsburg", 10, L, 1.34, 1.28), side("Augsburg", "Augsburg", 13, L, 1.18, 1.42)),
	game("fra-ren-len", "Ligue 1", "FRA", "Sunday", "Sun 8 Nov", "16:00", "Roazhon Park", side("Rennes", "Rennes", 7, M, 1.44, 1.16), side("Lens", "Lens", 5, W, 1.5, 1.04)),
	game("fra-nan-str", "Ligue 1", "FRA", "Saturday", "Sat 7 Nov", "18:00", "La Beaujoire", side("Nantes", "Nantes", 12, L, 1.12, 1.36), side("Strasbourg", "Strasbourg", 9, M, 1.3, 1.22)),
	game("ere-az-twe", "Eredivisie", "ERE", "Sunday", "Sun 8 Nov", "13:30", "AFAS Stadion", side("AZ", "AZ", 5, M, 1.52, 1.14), side("Twente", "Twente", 4, W, 1.58, 1.1)),
	game("ere-hee-spa", "Eredivisie", "ERE", "Saturday", "Sat 7 Nov", "19:00", "Abe Lenstra", side("Heerenveen", "Heerenveen", 8, L, 1.28, 1.3), side("Sparta", "Sparta", 9, M, 1.22, 1.26)),
	game("por-bra-gui", "Primeira Liga", "POR", "Sunday", "Sun 8 Nov", "17:30", "Estadio Municipal", side("Braga", "Braga", 4, W, 1.56, 1.02), side("Guimaraes", "Guimaraes", 6, M, 1.32, 1.14)),
	game("por-fam-spo", "Primeira Liga", "POR", "Saturday", "Sat 7 Nov", "20:30", "Estadio Municipal 22 de Junho", side("Famalicao", "Famalicao", 8, L, 1.18, 1.24), side("Sporting", "Sporting", 3, W, 1.84, .9)),
	game("chp-cov-wat", "Championship", "CHP", "Saturday", "Sat 7 Nov", "15:00", "CBS Arena", side("Coventry", "Coventry", 2, W, 1.62, .98), side("Watford", "Watford", 8, M, 1.34, 1.18)),
	game("chp-swa-lee", "Championship", "CHP", "Sunday", "Sun 8 Nov", "15:00", "Swansea.com Stadium", side("Swansea", "Swansea", 10, M, 1.28, 1.16), side("Leeds", "Leeds", 7, M, 1.4, 1.12)),
	game("spl-hib-abe", "Scottish Premiership", "SPL", "Sunday", "Sun 8 Nov", "14:00", "Easter Road", side("Hibernian", "Hibs", 5, M, 1.36, 1.14), side("Aberdeen", "Aberdeen", 4, M, 1.4, 1.1)),
	game("spl-kil-dun", "Scottish Premiership", "SPL", "Saturday", "Sat 7 Nov", "15:00", "Rugby Park", side("Kilmarnock", "Kilmarnock", 8, L, 1.12, 1.28), side("Dundee", "Dundee", 10, L, 1.04, 1.36)),
	game("mls-sea-por", "MLS", "MLS", "Saturday", "Sat 7 Nov", "21:30", "Lumen Field", side("Seattle Sounders", "Seattle", 5, M, 1.48, 1.12), side("Portland Timbers", "Portland", 8, L, 1.26, 1.3)),
	game("mex-pach-tol", "Liga MX", "MEX", "Sunday", "Sun 8 Nov", "02:00", "Hidalgo", side("Pachuca", "Pachuca", 6, M, 1.42, 1.08), side("Toluca", "Toluca", 4, W, 1.54, 1.02)),
	game("bra-int-san", "Brasileirao", "BRA", "Sunday", "Sun 8 Nov", "22:00", "Beira-Rio", side("Internacional", "Inter", 5, M, 1.46, 1.06), side("Santos", "Santos", 12, L, 1.18, 1.32)),
	game("arg-riv-est", "Liga Profesional", "ARG", "Saturday", "Sat 7 Nov", "21:00", "Mas Monumental", side("River Plate", "River", 1, W, 1.72, .84), side("Estudiantes", "Estudiantes", 5, M, 1.3, 1.04)),
	game("tur-gs-bes", "Super Lig", "TUR", "Sunday", "Sun 8 Nov", "17:00", "Rams Park", side("Galatasaray", "Galatasaray", 1, W, 1.96, .8), side("Besiktas", "Besiktas", 3, M, 1.5, 1.06)),
	game("bel-genk-bru", "Pro League", "BEL", "Saturday", "Sat 7 Nov", "19:45", "Cegeka Arena", side("Genk", "Genk", 2, W, 1.58, 1), side("Club Brugge", "Brugge", 1, W, 1.7, .92)),
	game("gre-aek-oly", "Super League", "GRE", "Sunday", "Sun 8 Nov", "18:30", "OPAP Arena", side("AEK Athens", "AEK", 4, M, 1.48, 1.02), side("Olympiacos", "Olympiacos", 1, W, 1.66, .86)),
	game("aut-stu-rap", "Bundesliga", "AUT", "Sunday", "Sun 8 Nov", "16:00", "Merkur Arena", side("Sturm Graz", "Sturm", 2, W, 1.6, .94), side("Rapid Wien", "Rapid", 4, M, 1.36, 1.12)),
	game("sui-bas-ser", "Super League", "SUI", "Saturday", "Sat 7 Nov", "17:00", "St Jakob-Park", side("Basel", "Basel", 2, W, 1.54, .98), side("Servette", "Servette", 4, M, 1.32, 1.1)),
	game("sau-nsr-ahl", "Saudi Pro League", "SAU", "Saturday", "Sat 7 Nov", "17:00", "Al-Awwal Park", side("Al Nassr", "Al Nassr", 2, W, 1.88, .9), side("Al Ahli", "Al Ahli", 4, M, 1.46, 1.04)),
	game("j1-ura-kob", "J.League", "J1", "Sunday", "Sun 8 Nov", "06:00", "Saitama Stadium", side("Urawa Reds", "Urawa", 5, M, 1.4, 1.08), side("Vissel Kobe", "Kobe", 1, W, 1.62, .88)),
	game("ken-gor-tus", "Kenyan Premier League", "KEN", "Sunday", "Sun 8 Nov", "15:00", "Kasarani", side("Gor Mahia", "Gor", 1, W, 1.5, .84), side("Tusker", "Tusker", 3, M, 1.28, 1.06)),
	game("ken-leo-sof", "Kenyan Premier League", "KEN", "Saturday", "Sat 7 Nov", "15:00", "Nyayo", side("AFC Leopards", "Leopards", 4, M, 1.22, 1.12), side("Sofapaka", "Sofapaka", 9, L, 1.04, 1.3)),
	game("nga-eny-rem", "NPFL", "NGA", "Sunday", "Sun 8 Nov", "16:00", "Enyimba Stadium", side("Enyimba", "Enyimba", 2, W, 1.4, .98), side("Remo Stars", "Remo", 1, W, 1.48, .92)),
	game("rsa-orl-kcz", "Premier Soccer League", "RSA", "Saturday", "Sat 7 Nov", "15:00", "Orlando Stadium", side("Orlando Pirates", "Pirates", 2, W, 1.52, .9), side("Kaizer Chiefs", "Chiefs", 6, M, 1.24, 1.14)),
	game("egy-zam-pyr", "Egyptian Premier League", "EGY", "Sunday", "Sun 8 Nov", "18:00", "Cairo Stadium", side("Zamalek", "Zamalek", 2, W, 1.46, .88), side("Pyramids", "Pyramids", 3, W, 1.5, .96)),
	game("sud-bol-ldu", "Copa Sudamericana", "SUD", "Midweek", "Thu 12 Nov", "00:30", "Hernando Siles", side("Bolivar", "Bolivar", 3, M, 1.42, 1.04), side("LDU Quito", "LDU", 2, W, 1.5, .98)),
	game("b2-fck-hsv", "2. Bundesliga", "B2", "Saturday", "Sat 7 Nov", "12:00", "Fritz-Walter-Stadion", side("Kaiserslautern", "Lautern", 5, M, 1.38, 1.16), side("Hamburger SV", "Hamburg", 2, W, 1.56, 1.02)),
	game("l1-wre-bol", "League One", "L1", "Saturday", "Sat 7 Nov", "15:00", "Racecourse Ground", side("Wrexham", "Wrexham", 3, W, 1.54, 1.06), side("Bolton", "Bolton", 4, M, 1.42, 1.1)),
	game("sud-nac-pen", "Copa Sudamericana", "SUD", "Midweek", "Thu 12 Nov", "23:00", "Gran Parque Central", side("Nacional", "Nacional", 2, M, 1.4, 1), side("Penarol", "Penarol", 1, W, 1.52, .94)),
	game("b2-s04-bsc", "2. Bundesliga", "B2", "Sunday", "Sun 8 Nov", "12:30", "Veltins-Arena", side("Schalke", "Schalke", 6, M, 1.36, 1.2), side("Hertha Berlin", "Hertha", 8, L, 1.26, 1.24)),
	game("l1-sto-bir", "League One", "L1", "Sunday", "Sun 8 Nov", "15:00", "Edgeley Park", side("Stockport", "Stockport", 2, W, 1.58, 1), side("Birmingham", "Birmingham", 1, W, 1.64, .96)),
	game("mls-nyc-atl", "MLS", "MLS", "Sunday", "Sun 8 Nov", "19:00", "Yankee Stadium", side("New York City", "NYCFC", 6, M, 1.4, 1.16), side("Atlanta United", "Atlanta", 9, L, 1.28, 1.3)),
	game("mex-leo-san", "Liga MX", "MEX", "Saturday", "Sat 7 Nov", "23:00", "Nou Camp", side("Leon", "Leon", 7, M, 1.36, 1.1), side("Santos Laguna", "Santos", 12, L, 1.12, 1.34)),
	game("bra-fla-san", "Brasileirao", "BRA", "Saturday", "Sat 7 Nov", "20:00", "Maracana", side("Fluminense", "Fluminense", 6, M, 1.38, 1.12), side("Sao Paulo", "Sao Paulo", 7, M, 1.34, 1.14)),
	game("arg-boc-rac", "Liga Profesional", "ARG", "Sunday", "Sun 8 Nov", "20:00", "La Bombonera", side("Boca Juniors", "Boca", 3, M, 1.48, .98), side("Racing", "Racing", 2, W, 1.5, .96)),
	game("tur-fen-tra", "Super Lig", "TUR", "Saturday", "Sat 7 Nov", "17:00", "Sukru Saracoglu", side("Fenerbahce", "Fenerbahce", 2, W, 1.78, .9), side("Trabzonspor", "Trabzonspor", 5, M, 1.36, 1.14)),
	game("bel-ant-and", "Pro League", "BEL", "Sunday", "Sun 8 Nov", "13:30", "Bosuil", side("Antwerp", "Antwerp", 6, M, 1.32, 1.18), side("Anderlecht", "Anderlecht", 3, W, 1.5, 1.04)),
	game("gre-pao-paok", "Super League", "GRE", "Saturday", "Sat 7 Nov", "18:00", "OAKA", side("Panathinaikos", "Panathinaikos", 2, W, 1.56, .96), side("PAOK", "PAOK", 3, M, 1.52, .98)),
	game("aut-sal-wac", "Bundesliga", "AUT", "Saturday", "Sat 7 Nov", "16:00", "Red Bull Arena", side("Red Bull Salzburg", "Salzburg", 1, W, 1.96, .78), side("Austria Wien", "Austria Wien", 6, L, 1.22, 1.2)),
	game("sui-yb-zur", "Super League", "SUI", "Sunday", "Sun 8 Nov", "15:30", "Wankdorf", side("Young Boys", "Young Boys", 1, W, 1.74, .9), side("Zurich", "Zurich", 5, L, 1.26, 1.18)),
	game("sau-hil-itt", "Saudi Pro League", "SAU", "Saturday", "Sat 7 Nov", "17:00", "Kingdom Arena", side("Al Hilal", "Al Hilal", 1, W, 2.1, .74), side("Al Ittihad", "Al Ittihad", 3, M, 1.58, 1)),
	game("j1-kas-yfm", "J.League", "J1", "Saturday", "Sat 7 Nov", "06:00", "Kashima Stadium", side("Kashima Antlers", "Kashima", 3, M, 1.48, .98), side("Yokohama F. Marinos", "Marinos", 4, M, 1.44, 1.08)),
	game("nga-ran-rvs", "NPFL", "NGA", "Saturday", "Sat 7 Nov", "15:00", "Cathedral", side("Rangers International", "Rangers", 5, M, 1.22, 1.1), side("Rivers United", "Rivers", 3, W, 1.3, 1.02)),
	game("rsa-sun-ste", "Premier Soccer League", "RSA", "Sunday", "Sun 8 Nov", "13:30", "Loftus Versfeld", side("Mamelodi Sundowns", "Sundowns", 1, W, 2.02, .72), side("Stellenbosch", "Stellenbosch", 3, W, 1.34, 1.04)),
	game("egy-ahl-fut", "Egyptian Premier League", "EGY", "Saturday", "Sat 7 Nov", "18:00", "Cairo Stadium", side("Al Ahly", "Ahly", 1, W, 1.9, .7), side("Modern Future", "Future", 7, L, 1.14, 1.22))
];
var LEAGUE_CODES = [
	"EPL",
	"UCL",
	"UEL",
	"UEC",
	"LIB",
	"SUD",
	"LAL",
	"SEA",
	"BUN",
	"B2",
	"FRA",
	"ERE",
	"POR",
	"CHP",
	"L1",
	"SPL",
	"MLS",
	"MEX",
	"BRA",
	"ARG",
	"TUR",
	"BEL",
	"GRE",
	"AUT",
	"SUI",
	"SAU",
	"J1",
	"KEN",
	"NGA",
	"RSA",
	"EGY"
];
var RAW_MATCHES = [
	{
		id: "lee-tot",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "12:30",
		venue: "Elland Road",
		home: {
			name: "Leeds United",
			short: "Leeds",
			pos: 12,
			form: [
				"D",
				"L",
				"D",
				"D",
				"L"
			],
			xgFor: 1.22,
			xgAgainst: 1.48,
			gf: 12,
			ga: 16,
			played: 10,
			out: ["Ao Tanaka (knock)", "J. Piroe (fitness)"]
		},
		away: {
			name: "Tottenham",
			short: "Spurs",
			pos: 9,
			form: [
				"L",
				"D",
				"W",
				"W",
				"W"
			],
			xgFor: 1.58,
			xgAgainst: 1.36,
			gf: 16,
			ga: 14,
			played: 10,
			out: ["Micky van de Ven (hamstring)"]
		}
	},
	{
		id: "ars-hul",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:00",
		venue: "Emirates Stadium",
		home: {
			name: "Arsenal",
			short: "Arsenal",
			pos: 1,
			form: [
				"W",
				"W",
				"W",
				"W",
				"D"
			],
			xgFor: 2.08,
			xgAgainst: .78,
			gf: 22,
			ga: 7,
			played: 10,
			out: ["Kai Havertz (knock)"]
		},
		away: {
			name: "Hull City",
			short: "Hull",
			pos: 18,
			form: [
				"L",
				"L",
				"D",
				"L",
				"L"
			],
			xgFor: .92,
			xgAgainst: 1.78,
			gf: 8,
			ga: 19,
			played: 10,
			out: ["No new senior absences flagged"]
		}
	},
	{
		id: "ful-new",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:00",
		venue: "Craven Cottage",
		home: {
			name: "Fulham",
			short: "Fulham",
			pos: 11,
			form: [
				"W",
				"D",
				"L",
				"W",
				"D"
			],
			xgFor: 1.34,
			xgAgainst: 1.28,
			gf: 13,
			ga: 13,
			played: 10,
			out: ["Antonee Robinson (ankle)"]
		},
		away: {
			name: "Newcastle",
			short: "Newcastle",
			pos: 6,
			form: [
				"W",
				"W",
				"D",
				"L",
				"W"
			],
			xgFor: 1.62,
			xgAgainst: 1.18,
			gf: 17,
			ga: 12,
			played: 10,
			out: ["Sven Botman (back)"]
		}
	},
	{
		id: "nfo-mci",
		league: "Premier League",
		code: "EPL",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "17:30",
		venue: "City Ground",
		home: {
			name: "Nott'm Forest",
			short: "Forest",
			pos: 19,
			form: [
				"L",
				"L",
				"L",
				"D",
				"L"
			],
			xgFor: .98,
			xgAgainst: 1.72,
			gf: 8,
			ga: 20,
			played: 10,
			out: ["Murillo (suspension)"]
		},
		away: {
			name: "Man City",
			short: "City",
			pos: 2,
			form: [
				"W",
				"W",
				"W",
				"L",
				"L"
			],
			xgFor: 1.96,
			xgAgainst: 1.05,
			gf: 21,
			ga: 11,
			played: 10,
			out: ["Rodri (long-term)"]
		}
	},
	{
		id: "bvb-elv",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:30",
		venue: "Signal Iduna Park",
		home: {
			name: "Dortmund",
			short: "Dortmund",
			pos: 4,
			form: [
				"W",
				"W",
				"D",
				"W",
				"L"
			],
			xgFor: 1.88,
			xgAgainst: 1.22,
			gf: 20,
			ga: 12,
			played: 10,
			out: ["Nico Schlotterbeck (muscle)"]
		},
		away: {
			name: "Elversberg",
			short: "Elversberg",
			pos: 16,
			form: [
				"L",
				"D",
				"L",
				"W",
				"L"
			],
			xgFor: 1.05,
			xgAgainst: 1.62,
			gf: 9,
			ga: 17,
			played: 10,
			out: ["No senior absences flagged"]
		}
	},
	{
		id: "koe-b04",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:30",
		venue: "RheinEnergieStadion",
		home: {
			name: "FC Cologne",
			short: "Cologne",
			pos: 13,
			form: [
				"D",
				"L",
				"W",
				"L",
				"D"
			],
			xgFor: 1.28,
			xgAgainst: 1.46,
			gf: 12,
			ga: 15,
			played: 10,
			out: ["Florian Kainz (calf)"]
		},
		away: {
			name: "Leverkusen",
			short: "Leverkusen",
			pos: 3,
			form: [
				"W",
				"W",
				"D",
				"W",
				"W"
			],
			xgFor: 1.84,
			xgAgainst: 1.08,
			gf: 19,
			ga: 10,
			played: 10,
			out: ["Jeremie Frimpong (hamstring)"]
		}
	},
	{
		id: "m05-bay",
		league: "Bundesliga",
		code: "BUN",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:30",
		venue: "Mewa Arena",
		home: {
			name: "Mainz",
			short: "Mainz",
			pos: 14,
			form: [
				"L",
				"D",
				"L",
				"W",
				"L"
			],
			xgFor: 1.18,
			xgAgainst: 1.52,
			gf: 11,
			ga: 16,
			played: 10,
			out: ["Jonathan Burkardt (knock)"]
		},
		away: {
			name: "Bayern",
			short: "Bayern",
			pos: 1,
			form: [
				"W",
				"W",
				"W",
				"W",
				"D"
			],
			xgFor: 2.24,
			xgAgainst: .92,
			gf: 26,
			ga: 9,
			played: 10,
			out: ["Jamal Musiala (managed minutes)"]
		}
	},
	{
		id: "tor-lec",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "15:00",
		venue: "Olimpico Grande Torino",
		home: {
			name: "Torino",
			short: "Torino",
			pos: 10,
			form: [
				"D",
				"D",
				"W",
				"L",
				"D"
			],
			xgFor: 1.12,
			xgAgainst: 1.05,
			gf: 10,
			ga: 9,
			played: 10,
			out: ["Perr Schuurs (long-term)"]
		},
		away: {
			name: "Lecce",
			short: "Lecce",
			pos: 15,
			form: [
				"L",
				"D",
				"L",
				"D",
				"W"
			],
			xgFor: .96,
			xgAgainst: 1.34,
			gf: 8,
			ga: 13,
			played: 10,
			out: ["Nikola Krstovic (fitness)"]
		}
	},
	{
		id: "rom-sas",
		league: "Serie A",
		code: "SEA",
		day: "Saturday",
		dateLabel: "Sat 7 Nov",
		time: "20:45",
		venue: "Stadio Olimpico",
		home: {
			name: "Roma",
			short: "Roma",
			pos: 5,
			form: [
				"W",
				"D",
				"W",
				"W",
				"L"
			],
			xgFor: 1.55,
			xgAgainst: 1.08,
			gf: 16,
			ga: 10,
			played: 10,
			out: ["Evan Ndicka (knock)"]
		},
		away: {
			name: "Sassuolo",
			short: "Sassuolo",
			pos: 12,
			form: [
				"D",
				"W",
				"L",
				"D",
				"L"
			],
			xgFor: 1.2,
			xgAgainst: 1.4,
			gf: 12,
			ga: 14,
			played: 10,
			out: ["Armand Lauriente (thigh)"]
		}
	},
	{
		id: "bha-bre",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "14:00",
		venue: "Amex Stadium",
		home: {
			name: "Brighton",
			short: "Brighton",
			pos: 8,
			form: [
				"W",
				"D",
				"W",
				"L",
				"W"
			],
			xgFor: 1.52,
			xgAgainst: 1.24,
			gf: 15,
			ga: 13,
			played: 10,
			out: ["Solly March (knee)"]
		},
		away: {
			name: "Brentford",
			short: "Brentford",
			pos: 10,
			form: [
				"D",
				"W",
				"L",
				"W",
				"D"
			],
			xgFor: 1.4,
			xgAgainst: 1.32,
			gf: 14,
			ga: 14,
			played: 10,
			out: ["Rico Henry (managed)"]
		}
	},
	{
		id: "cry-liv",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "14:00",
		venue: "Selhurst Park",
		home: {
			name: "Crystal Palace",
			short: "Palace",
			pos: 7,
			form: [
				"W",
				"W",
				"D",
				"W",
				"L"
			],
			xgFor: 1.36,
			xgAgainst: 1.14,
			gf: 14,
			ga: 11,
			played: 10,
			out: ["Cheick Doucoure (long-term)"]
		},
		away: {
			name: "Liverpool",
			short: "Liverpool",
			pos: 3,
			form: [
				"W",
				"L",
				"W",
				"W",
				"D"
			],
			xgFor: 1.82,
			xgAgainst: 1.12,
			gf: 19,
			ga: 12,
			played: 10,
			out: ["Alisson (fitness)"]
		}
	},
	{
		id: "sun-che",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "14:00",
		venue: "Stadium of Light",
		home: {
			name: "Sunderland",
			short: "Sunderland",
			pos: 15,
			form: [
				"L",
				"D",
				"W",
				"L",
				"D"
			],
			xgFor: 1.08,
			xgAgainst: 1.42,
			gf: 10,
			ga: 15,
			played: 10,
			out: ["Dan Ballard (knock)"]
		},
		away: {
			name: "Chelsea",
			short: "Chelsea",
			pos: 5,
			form: [
				"W",
				"W",
				"D",
				"L",
				"W"
			],
			xgFor: 1.7,
			xgAgainst: 1.16,
			gf: 18,
			ga: 12,
			played: 10,
			out: ["Reece James (managed)"]
		}
	},
	{
		id: "ips-bou",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "14:00",
		venue: "Portman Road",
		home: {
			name: "Ipswich",
			short: "Ipswich",
			pos: 17,
			form: [
				"L",
				"D",
				"L",
				"L",
				"W"
			],
			xgFor: 1.06,
			xgAgainst: 1.58,
			gf: 9,
			ga: 17,
			played: 10,
			out: ["Omari Hutchinson (ankle)"]
		},
		away: {
			name: "Bournemouth",
			short: "Bournemouth",
			pos: 13,
			form: [
				"D",
				"W",
				"L",
				"D",
				"L"
			],
			xgFor: 1.3,
			xgAgainst: 1.44,
			gf: 13,
			ga: 15,
			played: 10,
			out: ["Luis Sinisterra (muscle)"]
		}
	},
	{
		id: "mun-avl",
		league: "Premier League",
		code: "EPL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "16:30",
		venue: "Old Trafford",
		home: {
			name: "Man United",
			short: "United",
			pos: 8,
			form: [
				"W",
				"L",
				"D",
				"W",
				"L"
			],
			xgFor: 1.48,
			xgAgainst: 1.38,
			gf: 15,
			ga: 14,
			played: 10,
			out: ["Lisandro Martinez (knee)"]
		},
		away: {
			name: "Aston Villa",
			short: "Villa",
			pos: 4,
			form: [
				"W",
				"W",
				"W",
				"D",
				"W"
			],
			xgFor: 1.66,
			xgAgainst: 1.1,
			gf: 17,
			ga: 10,
			played: 10,
			out: ["Boubacar Kamara (fitness)"]
		}
	},
	{
		id: "val-rma",
		league: "La Liga",
		code: "LAL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "15:00",
		venue: "Mestalla",
		home: {
			name: "Valencia",
			short: "Valencia",
			pos: 19,
			form: [
				"L",
				"D",
				"D",
				"L",
				"W"
			],
			xgFor: .94,
			xgAgainst: 1.66,
			gf: 8,
			ga: 18,
			played: 11,
			out: ["Jose Gaya (knock)"]
		},
		away: {
			name: "Real Madrid",
			short: "Madrid",
			pos: 3,
			form: [
				"L",
				"W",
				"W",
				"W",
				"W"
			],
			xgFor: 1.92,
			xgAgainst: 1.02,
			gf: 22,
			ga: 11,
			played: 11,
			out: ["Eder Militao (fitness)"]
		}
	},
	{
		id: "atm-bar",
		league: "La Liga",
		code: "LAL",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "20:00",
		venue: "Riyadh Air Metropolitano",
		home: {
			name: "Atletico Madrid",
			short: "Atletico",
			pos: 4,
			form: [
				"W",
				"D",
				"W",
				"W",
				"D"
			],
			xgFor: 1.58,
			xgAgainst: .96,
			gf: 17,
			ga: 9,
			played: 11,
			out: ["Pablo Barrios (knock)"]
		},
		away: {
			name: "Barcelona",
			short: "Barcelona",
			pos: 1,
			form: [
				"W",
				"W",
				"W",
				"D",
				"W"
			],
			xgFor: 2.12,
			xgAgainst: .88,
			gf: 25,
			ga: 9,
			played: 11,
			out: ["Frenkie de Jong (calf)"]
		}
	},
	{
		id: "nap-laz",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "11:30",
		venue: "Diego Armando Maradona",
		home: {
			name: "Napoli",
			short: "Napoli",
			pos: 2,
			form: [
				"W",
				"W",
				"D",
				"W",
				"W"
			],
			xgFor: 1.74,
			xgAgainst: .9,
			gf: 18,
			ga: 8,
			played: 10,
			out: ["Attacking option listed as doubtful"]
		},
		away: {
			name: "Lazio",
			short: "Lazio",
			pos: 7,
			form: [
				"W",
				"L",
				"D",
				"W",
				"D"
			],
			xgFor: 1.42,
			xgAgainst: 1.18,
			gf: 14,
			ga: 12,
			played: 10,
			out: ["Mattia Zaccagni (knock)"]
		}
	},
	{
		id: "gen-mil",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "15:00",
		venue: "Luigi Ferraris",
		home: {
			name: "Genoa",
			short: "Genoa",
			pos: 14,
			form: [
				"L",
				"D",
				"L",
				"W",
				"D"
			],
			xgFor: 1.02,
			xgAgainst: 1.38,
			gf: 9,
			ga: 14,
			played: 10,
			out: ["Albert Gudmundsson (knock)"]
		},
		away: {
			name: "AC Milan",
			short: "Milan",
			pos: 6,
			form: [
				"W",
				"D",
				"W",
				"L",
				"W"
			],
			xgFor: 1.6,
			xgAgainst: 1.14,
			gf: 16,
			ga: 11,
			played: 10,
			out: ["Theo Hernandez (fitness)"]
		}
	},
	{
		id: "fio-juv",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "20:45",
		venue: "Artemio Franchi",
		home: {
			name: "Fiorentina",
			short: "Fiorentina",
			pos: 11,
			form: [
				"D",
				"L",
				"W",
				"D",
				"L"
			],
			xgFor: 1.22,
			xgAgainst: 1.3,
			gf: 12,
			ga: 13,
			played: 10,
			out: ["Moise Kean (knock)"]
		},
		away: {
			name: "Juventus",
			short: "Juventus",
			pos: 4,
			form: [
				"W",
				"D",
				"W",
				"W",
				"D"
			],
			xgFor: 1.48,
			xgAgainst: .86,
			gf: 15,
			ga: 7,
			played: 10,
			out: ["Bremer (long-term)"]
		}
	},
	{
		id: "int-com",
		league: "Serie A",
		code: "SEA",
		day: "Sunday",
		dateLabel: "Sun 8 Nov",
		time: "18:00",
		venue: "San Siro",
		home: {
			name: "Inter",
			short: "Inter",
			pos: 1,
			form: [
				"W",
				"W",
				"W",
				"D",
				"W"
			],
			xgFor: 1.98,
			xgAgainst: .82,
			gf: 21,
			ga: 7,
			played: 10,
			out: ["Lautaro Martinez (managed)"]
		},
		away: {
			name: "Como",
			short: "Como",
			pos: 9,
			form: [
				"W",
				"D",
				"L",
				"W",
				"D"
			],
			xgFor: 1.26,
			xgAgainst: 1.22,
			gf: 13,
			ga: 12,
			played: 10,
			out: ["Nico Paz (knock)"]
		}
	}
];
var KEYS = [
	"home",
	"draw",
	"away"
];
var norm = (t) => {
	const s = t.home + t.draw + t.away || 1;
	return {
		home: t.home / s,
		draw: t.draw / s,
		away: t.away / s
	};
};
var sorted = (t) => [...KEYS].sort((a, b) => t[b] - t[a]);
/** 1. Remove the bookmaker margin with the power method (fairer than proportional scaling on long shots). */
function removeVig(odds) {
	const inv = KEYS.map((k) => 1 / odds[k]);
	if (inv.some((v) => !Number.isFinite(v) || v <= 0 || v >= 1)) return null;
	let lo = .5;
	let hi = 4;
	for (let i = 0; i < 60; i++) {
		const mid = (lo + hi) / 2;
		if (inv.reduce((s, v) => s + v ** mid, 0) > 1) lo = mid;
		else hi = mid;
	}
	return norm({
		home: inv[0] ** hi,
		draw: inv[1] ** hi,
		away: inv[2] ** hi
	});
}
/** 2. Market anchor: closing odds beat any stats-only model, so lean on them when a real quote exists. */
function blendWithMarket(model, market, marketWeight = .6) {
	if (!market) return model;
	return norm({
		home: model.home * (1 - marketWeight) + market.home * marketWeight,
		draw: model.draw * (1 - marketWeight) + market.draw * marketWeight,
		away: model.away * (1 - marketWeight) + market.away * marketWeight
	});
}
/** 3. Calibration: temperature > 1 flattens overconfident probabilities. */
function calibrate(t, temperature = 1.15) {
	const p = (x) => Math.max(x, 1e-6) ** (1 / temperature);
	return norm({
		home: p(t.home),
		draw: p(t.draw),
		away: p(t.away)
	});
}
/** 4. Many feeds are variations of one xG model. Cap each correlated family so they cannot swamp the blend. */
var FAMILY_CAP = {
	x: 1.2,
	x2: .8,
	x4: .5
};
var familyOf = (id) => id.startsWith("x4-") ? "x4" : id.startsWith("x2-") ? "x2" : id.startsWith("x-") ? "x" : null;
function dedupedBlend(feeds, weightOf) {
	const raw = /* @__PURE__ */ new Map();
	for (const f of feeds) {
		const fam = familyOf(f.id);
		if (fam) raw.set(fam, (raw.get(fam) ?? 0) + weightOf(f.id));
	}
	let h = 0;
	let d = 0;
	let a = 0;
	let total = 0;
	for (const f of feeds) {
		const fam = familyOf(f.id);
		const scale = fam ? Math.min(1, FAMILY_CAP[fam] / (raw.get(fam) || 1)) : 1;
		const w = weightOf(f.id) * scale;
		h += f.home * w;
		d += f.draw * w;
		a += f.away * w;
		total += w;
	}
	return norm({
		home: h / total,
		draw: d / total,
		away: a / total
	});
}
/** 5. Elo from real results, with a goal-difference multiplier. */
var eloExpected = (rA, rB, homeEdge = 60) => 1 / (1 + 10 ** ((rB - (rA + homeEdge)) / 400));
function eloUpdate(rHome, rAway, gh, ga, k = 20) {
	const exp = eloExpected(rHome, rAway);
	const actual = gh > ga ? 1 : gh === ga ? .5 : 0;
	const delta = k * (Math.log(Math.abs(gh - ga) + 1) + 1) * (actual - exp);
	return {
		home: rHome + delta,
		away: rAway - delta
	};
}
var brier = (xs) => xs.length ? xs.reduce((s, x) => s + KEYS.reduce((q, k) => q + (x.p[k] - (k === x.result ? 1 : 0)) ** 2, 0), 0) / xs.length : NaN;
var logLoss = (xs) => xs.length ? -xs.reduce((s, x) => s + Math.log(Math.max(x.p[x.result], 1e-9)), 0) / xs.length : NaN;
function fitTemperature(history, min = 30) {
	if (history.length < min) return 1.15;
	let best = 1.15;
	let bestLoss = Infinity;
	for (let t = .8; t <= 2; t += .05) {
		const loss = logLoss(history.map((h) => ({
			...h,
			p: calibrate(h.p, t)
		})));
		if (loss < bestLoss) {
			bestLoss = loss;
			best = t;
		}
	}
	return Number(best.toFixed(2));
}
var CODE = {
	home: "1",
	draw: "X",
	away: "2"
};
function decide(p, agreement, dataAgeHours = 0) {
	const [first, second] = sorted(p);
	const stale = dataAgeHours > 48;
	const tiers = [
		"A",
		"B",
		"C"
	];
	const bump = (i) => stale ? Math.min(i + 1, 3) : i;
	const out = (i, pick, reason) => ({
		pick: i >= 3 ? "PASS" : pick,
		tier: i >= 3 ? "PASS" : tiers[i],
		reason: stale ? `${reason} (data over 48h old, tier lowered)` : reason
	});
	if (p[first] >= .55 && agreement >= .7) return out(bump(0), CODE[first], "Strong single");
	if (p[first] >= .45 && agreement >= .55) return out(bump(1), CODE[first], "Lean single");
	if (p[first] + p[second] >= .7) {
		const code = [first, second].sort((a, b) => KEYS.indexOf(a) - KEYS.indexOf(b)).map((k) => CODE[k]).join("");
		return out(bump(2), code === "12" ? "12" : code, "Double chance covers the uncertainty");
	}
	return {
		pick: "PASS",
		tier: "PASS",
		reason: "No outcome pair clears 70%"
	};
}
function clamp(n, lo, hi) {
	return Math.min(hi, Math.max(lo, n));
}
function poisson$1(k, lambda) {
	let p = Math.exp(-lambda);
	for (let i = 1; i <= k; i++) p *= lambda / i;
	return p;
}
function formScore(form) {
	const mark = {
		W: 1,
		D: .35,
		L: 0
	};
	if (form.length === 0) return .4;
	const weights = form.map((_, index) => index + 1);
	const total = weights.reduce((sum, weight) => sum + weight, 0);
	return form.reduce((sum, item, index) => sum + mark[item] * weights[index], 0) / total;
}
function baseLambdas(home, away) {
	return {
		home: clamp((home.xgFor + away.xgAgainst) / 2 * 1.1, .35, 3.3),
		away: clamp((away.xgFor + home.xgAgainst) / 2 * .92, .25, 3.1)
	};
}
function shrink(n, pull = .12) {
	return n * (1 - pull) + 1.35 * pull;
}
function absenceFactor(out) {
	const named = out.filter((name) => !/no new|no senior|no confirmed/i.test(name));
	return Math.max(.78, 1 - Math.min(named.length, 4) * .07);
}
/** Base xG, shrunk toward a typical match, then form, place and absences. */
function adjustedLambdas(home, away) {
	const homeFor = shrink(home.xgFor) * absenceFactor(home.out);
	const awayFor = shrink(away.xgFor) * absenceFactor(away.out);
	const homeAgainst = shrink(home.xgAgainst) * (1 + (1 - absenceFactor(home.out)) * .6);
	const awayAgainst = shrink(away.xgAgainst) * (1 + (1 - absenceFactor(away.out)) * .6);
	const gap = formScore(home.form) - formScore(away.form);
	const pos = clamp(away.pos - home.pos, -12, 12);
	return {
		home: clamp((homeFor + awayAgainst) / 2 * 1.08 * (1 + gap * .18) * (1 + pos * .006), .35, 3.3),
		away: clamp((awayFor + homeAgainst) / 2 * .94 * (1 - gap * .18) * (1 - pos * .004), .25, 3.1)
	};
}
function dixonTau(h, a, lh, la) {
	const rho = -.1;
	if (h === 0 && a === 0) return Math.max(.05, 1 - lh * la * rho);
	if (h === 1 && a === 0) return Math.max(.05, 1 + la * rho);
	if (h === 0 && a === 1) return Math.max(.05, 1 + lh * rho);
	if (h === 1 && a === 1) return Math.max(.05, 1.1);
	return 1;
}
function scoreTriple(lh, la, dixon) {
	const max = 8;
	const homeP = Array.from({ length: max }, (_, k) => poisson$1(k, lh));
	const awayP = Array.from({ length: max }, (_, k) => poisson$1(k, la));
	let home = 0;
	let draw = 0;
	let away = 0;
	for (let h = 0; h < max; h++) for (let a = 0; a < max; a++) {
		const weight = dixon ? dixonTau(h, a, lh, la) : 1;
		const p = homeP[h] * awayP[a] * weight;
		if (h > a) home += p;
		else if (h === a) draw += p;
		else away += p;
	}
	const mass = home + draw + away || 1;
	return {
		home: home / mass,
		draw: draw / mass,
		away: away / mass
	};
}
function predictionFeeds(home, away) {
	const base = baseLambdas(home, away);
	const adj = adjustedLambdas(home, away);
	const gap = formScore(home.form) - formScore(away.form);
	const feeds = [
		{
			id: "base",
			name: "Base xG",
			note: "Season scoring and conceding only",
			...scoreTriple(base.home, base.away, false)
		},
		{
			id: "dc",
			name: "Dixon-Coles",
			note: "More 0-0 and 1-1 than a plain grid",
			...scoreTriple(adj.home, adj.away, true)
		},
		{
			id: "form",
			name: "Form",
			note: "Last five results tilt the attack",
			...scoreTriple(base.home * (1 + gap * .1), base.away * (1 - gap * .1), false)
		},
		{
			id: "table",
			name: "Table",
			note: "League place, not the xG",
			...scoreTriple(base.home * (1 + clamp(away.pos - home.pos, -12, 12) * .012), base.away * (1 - clamp(away.pos - home.pos, -12, 12) * .008), false)
		},
		{
			id: "home",
			name: "Home lift",
			note: "Stronger home advantage",
			...scoreTriple(base.home * 1.08, base.away * .94, false)
		},
		{
			id: "calm",
			name: "Cautious home",
			note: "Almost no home edge",
			...scoreTriple(base.home * .94, base.away * 1.04, false)
		},
		{
			id: "tight",
			name: "Tight game",
			note: "Fewer chances, more draws",
			...scoreTriple(adj.home * .82, adj.away * .82, true)
		},
		{
			id: "open",
			name: "Open game",
			note: "More chances, fewer draws",
			...scoreTriple(adj.home * 1.16, adj.away * 1.16, false)
		},
		{
			id: "five",
			name: "Last five",
			note: "Form outweighs the season rate",
			...scoreTriple(base.home * (1 + gap * .16), base.away * (1 - gap * .16), true)
		},
		{
			id: "level",
			name: "Level match",
			note: "Extra draw weight when the sides are close",
			...levelDraw(scoreTriple(adj.home, adj.away, true), Math.abs(adj.home - adj.away))
		},
		{
			id: "reg",
			name: "Regression",
			note: "Hot attacks are pulled back toward a normal game",
			...scoreTriple(shrink(home.xgFor, .28) * 1.05, shrink(away.xgFor, .28) * .95, true)
		},
		{
			id: "abs",
			name: "Absences",
			note: "Listed players out trim that side",
			...scoreTriple(base.home * absenceFactor(home.out), base.away * absenceFactor(away.out), false)
		},
		...extraReads(home, away, base, adj, gap)
	];
	const weight = {
		base: 1,
		dc: 1.7,
		form: 1.6,
		table: .7,
		home: .45,
		calm: .45,
		tight: .8,
		open: .55,
		five: 1.5,
		level: 1,
		reg: 1.2,
		abs: 1.7,
		"x2-rest": .2,
		"x2-wide": .2,
		"x2-block": .2,
		"x2-press": .2,
		"x2-counter": .2,
		"x2-convert": .2,
		"x2-waste": .2,
		"x2-split": .2,
		"x2-bounce": .2,
		"x2-host": .2,
		"x2-road": .2,
		"x2-gap": .2,
		"x2-noise": .2,
		"x2-draw": .2,
		"x2-score": .2,
		"x2-blank": .2,
		"x2-late": .2,
		"x2-early": .2,
		"x2-card": .2,
		"x2-set": .2,
		"x2-pair": .2,
		"x4-1": .12,
		"x4-2": .12,
		"x4-3": .12,
		"x4-4": .12,
		"x4-5": .12,
		"x4-6": .12,
		"x4-7": .12,
		"x4-8": .12,
		"x4-9": .12,
		"x4-10": .12,
		"x4-11": .12,
		"x4-12": .12,
		"x4-13": .12,
		"x4-14": .12,
		"x4-15": .12,
		"x4-16": .12,
		"x4-17": .12,
		"x4-18": .12,
		"x4-19": .12,
		"x4-20": .12
	};
	const blend = dedupedBlend(feeds, (id) => weight[id] ?? .35);
	const pick = argmax(blend);
	const extras = feeds.filter((feed) => feed.id.startsWith("x-"));
	const core = feeds.filter((feed) => !feed.id.startsWith("x-"));
	const agree = core.filter((feed) => argmax(feed) === pick).length;
	const extraAgree = extras.filter((feed) => argmax(feed) === pick).length;
	return {
		feeds,
		extras,
		blend,
		pick,
		agree,
		core: core.length,
		extraAgree
	};
}
function extraReads(home, away, base, adj, gap) {
	const hFinish = perGame(home.gf, home.played) - home.xgFor;
	const aFinish = perGame(away.gf, away.played) - away.xgFor;
	const hSave = home.xgAgainst - perGame(home.ga, home.played);
	const aSave = away.xgAgainst - perGame(away.ga, away.played);
	const hDiff = perGame(home.gf - home.ga, home.played);
	const aDiff = perGame(away.gf - away.ga, away.played);
	const recent = formScore(home.form.slice(-2)) - formScore(away.form.slice(-2));
	const homeRun = streak(home.form, "W") - streak(home.form, "L");
	const awayRun = streak(away.form, "W") - streak(away.form, "L");
	const place = clamp(away.pos - home.pos, -12, 12);
	const missing = clamp(away.out.length - home.out.length, -3, 3);
	const doubt = clamp((12 - Math.min(home.played, away.played)) / 12, 0, .35);
	return [
		{
			id: "x-clash",
			name: "Attack clash",
			note: "What they score against what the other concedes",
			...scoreTriple(clamp(home.xgFor * .55 + away.xgAgainst * .55, .35, 3.3), clamp(away.xgFor * .5 + home.xgAgainst * .5, .25, 3.1), false)
		},
		{
			id: "x-shield",
			name: "Defence first",
			note: "Conceding rate counts more than scoring",
			...scoreTriple(clamp(home.xgFor * .35 + away.xgAgainst * .75, .35, 3.3), clamp(away.xgFor * .35 + home.xgAgainst * .7, .25, 3.1), true)
		},
		{
			id: "x-finish",
			name: "Finishing luck",
			note: "Goals above xG are faded",
			...scoreTriple(base.home * (1 - clamp(hFinish, -.45, .45) * .22), base.away * (1 - clamp(aFinish, -.45, .45) * .22), false)
		},
		{
			id: "x-save",
			name: "Save luck",
			note: "A defence beating its xG is not trusted",
			...scoreTriple(base.home * (1 + clamp(aSave, -.4, .4) * .18), base.away * (1 + clamp(hSave, -.4, .4) * .18), false)
		},
		{
			id: "x-two",
			name: "Last two",
			note: "Only the last two results",
			...scoreTriple(base.home * (1 + recent * .12), base.away * (1 - recent * .12), false)
		},
		{
			id: "x-run",
			name: "Streak",
			note: "A run of wins or losses",
			...scoreTriple(base.home * (1 + (homeRun - awayRun) * .035), base.away * (1 - (homeRun - awayRun) * .035), false)
		},
		{
			id: "x-diff",
			name: "Goal difference",
			note: "Goals scored minus goals conceded",
			...scoreTriple(base.home * (1 + clamp(hDiff - aDiff, -1.2, 1.2) * .08), base.away * (1 - clamp(hDiff - aDiff, -1.2, 1.2) * .06), false)
		},
		{
			id: "x-close",
			name: "Close sides",
			note: "Places within three get a draw lift",
			...levelDraw(scoreTriple(adj.home, adj.away, true), Math.abs(home.pos - away.pos) <= 3 ? .2 : .8)
		},
		{
			id: "x-class",
			name: "Class gap",
			note: "A big league-place gap",
			...scoreTriple(base.home * (place >= 8 ? 1.08 : 1), base.away * (place <= -8 ? 1.08 : 1), false)
		},
		{
			id: "x-leak",
			name: "Both leak",
			note: "Two weak defences, fewer draws",
			...scoreTriple(adj.home * (home.xgAgainst > 1.3 && away.xgAgainst > 1.3 ? 1.12 : 1), adj.away * (home.xgAgainst > 1.3 && away.xgAgainst > 1.3 ? 1.12 : 1), false)
		},
		{
			id: "x-shut",
			name: "Both tight",
			note: "Two strong defences, more draws",
			...scoreTriple(adj.home * (home.xgAgainst < 1.05 && away.xgAgainst < 1.05 ? .84 : 1), adj.away * (home.xgAgainst < 1.05 && away.xgAgainst < 1.05 ? .84 : 1), true)
		},
		{
			id: "x-miss",
			name: "Who is missing",
			note: "The side with more names out",
			...scoreTriple(base.home * (1 + missing * .04), base.away * (1 - missing * .04), false)
		},
		{
			id: "x-cold",
			name: "Cold finish",
			note: "Creating more than they score",
			...scoreTriple(base.home * (1 + clamp(home.xgFor - perGame(home.gf, home.played), -.4, .4) * .12), base.away * (1 + clamp(away.xgFor - perGame(away.gf, away.played), -.4, .4) * .12), false)
		},
		{
			id: "x-fort",
			name: "Home wall",
			note: "A high side that does not concede",
			...scoreTriple(base.home * (home.xgAgainst < .95 && home.pos <= 6 ? 1.06 : 1), base.away * (home.xgAgainst < .95 && home.pos <= 6 ? .92 : 1), true)
		},
		{
			id: "x-respect",
			name: "Better away",
			note: "Cuts the home edge when the away side is higher",
			...scoreTriple(base.home * (away.pos < home.pos ? .94 : 1), base.away * (away.pos < home.pos ? 1.08 : 1), false)
		},
		{
			id: "x-nil",
			name: "Nil-nil",
			note: "A quieter game and more 0-0",
			...scoreTriple(adj.home * .75, adj.away * .75, true)
		},
		{
			id: "x-even",
			name: "Pull to even",
			note: "Moves a loud call back toward a third each",
			...temper(scoreTriple(adj.home, adj.away, true), .18)
		},
		{
			id: "x-mix",
			name: "Form and place",
			note: "Recent form times the table gap",
			...scoreTriple(base.home * (1 + gap * .08 + place * .006), base.away * (1 - gap * .08 - place * .004), true)
		},
		{
			id: "x-thin",
			name: "Small sample",
			note: "Fewer games played means less trust",
			...temper(scoreTriple(adj.home, adj.away, true), .08 + doubt)
		},
		{
			id: "x-flat",
			name: "Flat match",
			note: "Similar attacks get a draw lift",
			...levelDraw(scoreTriple(base.home, base.away, true), Math.abs(base.home - base.away))
		},
		...moreReads(home, away, base, adj, gap)
	];
}
function waveReads(home, away, base, adj) {
	const place = clamp(away.pos - home.pos, -12, 12);
	const soft = (name, note, id, lh, la, dixon = false) => ({
		id,
		name,
		note,
		...scoreTriple(clamp(lh, .35, 3.3), clamp(la, .25, 3.1), dixon)
	});
	return [
		soft("Home scrape", "Home attack trimmed", "x4-1", base.home * .97, base.away),
		soft("Away scrape", "Away attack trimmed", "x4-2", base.home, base.away * .97),
		soft("Draw lift", "A little more draw", "x4-3", adj.home * .93, adj.away * .93, true),
		soft("No draw lift", "Draw left alone", "x4-4", adj.home, adj.away, false),
		soft("Table nudge", "League place, small", "x4-5", base.home * (1 + place * .004), base.away * (1 - place * .003)),
		soft("Form nudge", "Last five, small", "x4-6", base.home * (1 + (formScore(home.form) - formScore(away.form)) * .05), base.away * (1 - (formScore(home.form) - formScore(away.form)) * .05)),
		soft("Absence nudge", "One missing name", "x4-7", base.home * absenceFactor(home.out), base.away),
		soft("Away absence", "Away missing names", "x4-8", base.home, base.away * absenceFactor(away.out)),
		soft("Quiet", "Both attacks down", "x4-9", adj.home * .88, adj.away * .88, true),
		soft("Loud", "Both attacks up", "x4-10", adj.home * 1.08, adj.away * 1.08),
		soft("Host wall", "Home defence trusted", "x4-11", base.home * 1.03, base.away * (home.xgAgainst < 1.1 ? .94 : 1), true),
		soft("Road wall", "Away defence trusted", "x4-12", base.home * (away.xgAgainst < 1.1 ? .94 : 1), base.away * 1.03),
		soft("Even out", "Close xG pulled to a draw", "x4-13", adj.home, adj.away, true),
		soft("Season only", "No form", "x4-14", base.home, base.away, false),
		soft("Adjusted only", "Form and absences", "x4-15", adj.home, adj.away, true),
		soft("Shrink hard", "Hot numbers cooled", "x4-16", shrink(home.xgFor, .35) * 1.05, shrink(away.xgFor, .35) * .95, true),
		soft("Goals first", "Scoring rate only", "x4-17", home.xgFor * 1.05, away.xgFor * .95),
		soft("Conceding first", "What they let in", "x4-18", away.xgAgainst * 1.05, home.xgAgainst * .95, true),
		soft("Place and form", "Both small", "x4-19", base.home * (1 + place * .003), base.away * (1 - place * .002), true),
		soft("Stay put", "The adjusted game, unchanged", "x4-20", adj.home, adj.away, true)
	];
}
function moreReads(home, away, base, adj, gap) {
	const hConv = perGame(home.gf, home.played) / Math.max(.4, home.xgFor);
	const aConv = perGame(away.gf, away.played) / Math.max(.4, away.xgFor);
	const last = home.form[home.form.length - 1];
	const lastA = away.form[away.form.length - 1];
	const bounce = (last === "L" ? .04 : 0) - (lastA === "L" ? .04 : 0);
	return [
		{
			id: "x2-rest",
			name: "Short rest",
			note: "A midweek side is pulled back a little",
			...scoreTriple(adj.home * .96, adj.away * .96, true)
		},
		{
			id: "x2-wide",
			name: "Wide attack",
			note: "More chances mean more corners, not a different winner",
			...scoreTriple(adj.home, adj.away, false)
		},
		{
			id: "x2-block",
			name: "Low block",
			note: "A side that creates little and concedes little",
			...scoreTriple(base.home * (home.xgFor < 1.2 ? .92 : 1), base.away * (away.xgFor < 1.2 ? .92 : 1), true)
		},
		{
			id: "x2-press",
			name: "High press",
			note: "Both sides create a lot, so the draw shrinks",
			...scoreTriple(adj.home * (home.xgFor > 1.6 && away.xgFor > 1.6 ? 1.08 : 1), adj.away * (home.xgFor > 1.6 && away.xgFor > 1.6 ? 1.08 : 1), false)
		},
		{
			id: "x2-counter",
			name: "Counter",
			note: "A low-scoring side against a leaky defence",
			...scoreTriple(base.home * (home.xgFor < away.xgAgainst ? 1.05 : 1), base.away * (away.xgFor < home.xgAgainst ? 1.05 : 1), false)
		},
		{
			id: "x2-convert",
			name: "Conversion",
			note: "Scoring more than the chances fade",
			...scoreTriple(base.home * (hConv > 1.15 ? .94 : 1), base.away * (aConv > 1.15 ? .94 : 1), false)
		},
		{
			id: "x2-waste",
			name: "Waste",
			note: "Chances that are not becoming goals",
			...scoreTriple(base.home * (hConv < .85 ? 1.06 : 1), base.away * (aConv < .85 ? 1.06 : 1), false)
		},
		{
			id: "x2-split",
			name: "Home and away split",
			note: "Season rate and last five are averaged",
			...scoreTriple(base.home * (1 + gap * .08), base.away * (1 - gap * .08), true)
		},
		{
			id: "x2-bounce",
			name: "Bounce back",
			note: "A loss last time gets a small lift",
			...scoreTriple(base.home * (1 + bounce), base.away * (1 - bounce), false)
		},
		{
			id: "x2-host",
			name: "Hosts only",
			note: "Home attack, away chance ignored",
			...scoreTriple(clamp(home.xgFor * 1.12, .35, 3.3), clamp(away.xgAgainst * .7, .25, 3.1), false)
		},
		{
			id: "x2-road",
			name: "Road only",
			note: "Away attack, home chance ignored",
			...scoreTriple(clamp(home.xgAgainst * .85, .35, 3.3), clamp(away.xgFor * 1.05, .25, 3.1), false)
		},
		{
			id: "x2-gap",
			name: "Chance gap",
			note: "The bigger attack is trusted more",
			...scoreTriple(adj.home * (adj.home > adj.away + .4 ? 1.06 : 1), adj.away * (adj.away > adj.home + .4 ? 1.06 : 1), false)
		},
		{
			id: "x2-noise",
			name: "One result",
			note: "The last game is not the season",
			...temper(scoreTriple(base.home * (1 + gap * .2), base.away * (1 - gap * .2), false), .22)
		},
		{
			id: "x2-draw",
			name: "Draw price",
			note: "Even attacks stay on the draw",
			...levelDraw(scoreTriple(adj.home, adj.away, true), Math.abs(adj.home - adj.away) * .7)
		},
		{
			id: "x2-score",
			name: "Both score lean",
			note: "Two attacks over one goal each",
			...scoreTriple(adj.home * (home.xgFor > 1.3 && away.xgFor > 1.3 ? 1.05 : .96), adj.away * (home.xgFor > 1.3 && away.xgFor > 1.3 ? 1.05 : .96), false)
		},
		{
			id: "x2-blank",
			name: "Clean sheet lean",
			note: "A tight defence keeps the other side quiet",
			...scoreTriple(adj.home * (home.xgAgainst < 1 ? 1.04 : 1), adj.away * (away.xgAgainst < 1 ? 1.04 : 1), true)
		},
		{
			id: "x2-late",
			name: "Late goals",
			note: "An open game, scored as a full-match lean",
			...scoreTriple(adj.home * 1.1, adj.away * 1.1, false)
		},
		{
			id: "x2-early",
			name: "Early goal",
			note: "A high home rate leans to the host",
			...scoreTriple(adj.home * (adj.home > 1.7 ? 1.05 : 1), adj.away, false)
		},
		{
			id: "x2-card",
			name: "Card game",
			note: "A close table game is tighter, not a red-card tip",
			...scoreTriple(adj.home * (Math.abs(home.pos - away.pos) <= 4 ? .95 : 1), adj.away * (Math.abs(home.pos - away.pos) <= 4 ? .95 : 1), true)
		},
		{
			id: "x2-set",
			name: "Set pieces",
			note: "Attack volume stands in for corners",
			...scoreTriple(adj.home, adj.away, false)
		},
		{
			id: "x2-pair",
			name: "Pair of rates",
			note: "Each side's own for and against, no opponent mix",
			...scoreTriple(clamp((home.xgFor + home.xgAgainst) / 2, .35, 3.3), clamp((away.xgFor + away.xgAgainst) / 2, .25, 3.1), true)
		},
		...waveReads(home, away, base, adj)
	];
}
function matchMarks(lh, la) {
	const homeZero = Math.exp(-lh);
	const awayZero = Math.exp(-la);
	let bothAndOver = 0;
	let mass = 0;
	for (let h = 0; h < 8; h++) for (let a = 0; a < 8; a++) {
		const cell = poisson$1(h, lh) * poisson$1(a, la);
		mass += cell;
		if (h > 0 && a > 0 && h + a >= 3) bothAndOver += cell;
	}
	return {
		homeNil: (1 - homeZero) * awayZero,
		awayNil: (1 - awayZero) * homeZero,
		homeClean: awayZero,
		awayClean: homeZero,
		firstHome: lh / (lh + la || 1),
		bothAndOver: mass > 0 ? bothAndOver / mass : 0
	};
}
function perGame(total, played) {
	return played > 0 ? total / played : total;
}
function streak(form, mark) {
	let count = 0;
	for (let i = form.length - 1; i >= 0; i--) {
		if (form[i] !== mark) break;
		count += 1;
	}
	return count;
}
function temper(triple, pull) {
	return {
		home: triple.home * (1 - pull) + pull / 3,
		draw: triple.draw * (1 - pull) + pull / 3,
		away: triple.away * (1 - pull) + pull / 3
	};
}
function levelDraw(triple, gap) {
	if (gap > .45) return triple;
	const lift = .04 * (1 - gap / .45);
	const draw = triple.draw + lift;
	const rest = 1 - draw;
	const side = triple.home + triple.away || 1;
	return {
		home: triple.home / side * rest,
		draw,
		away: triple.away / side * rest
	};
}
function argmax(triple) {
	if (triple.home >= triple.draw && triple.home >= triple.away) return "home";
	if (triple.away >= triple.draw) return "away";
	return "draw";
}
function readLine(homeName, awayName, pack) {
	const name = pack.pick === "home" ? homeName : pack.pick === "away" ? awayName : "the draw";
	if (pack.agree < 6) return `Split. Only ${pack.agree} of ${pack.core} core reads lean ${name}, and ${pack.extraAgree} of ${pack.extras.length} extra reads agree. That is a pass.`;
	return `${pack.agree} of ${pack.core} core reads lean ${name}. ${pack.extraAgree} of ${pack.extras.length} extra reads agree. A lean, not a correct bet.`;
}
var MARKET_KEYS = [
	"home",
	"draw",
	"away",
	"btts",
	"over25",
	"under25",
	"over15",
	"over35",
	"corners95",
	"red"
];
var BOOKS = [
	{
		id: "pin",
		name: "Pinnacle",
		sharp: true,
		region: "Sharp",
		href: "https://www.pinnacle.com"
	},
	{
		id: "bf",
		name: "Betfair",
		sharp: true,
		region: "Sharp",
		href: "https://www.betfair.com"
	},
	{
		id: "betika",
		name: "Betika",
		sharp: false,
		region: "Kenya",
		href: "https://www.betika.com"
	},
	{
		id: "odi",
		name: "Odibets",
		sharp: false,
		region: "Kenya",
		href: "https://odibets.com"
	},
	{
		id: "sp",
		name: "SportPesa",
		sharp: false,
		region: "Kenya",
		href: "https://www.ke.sportpesa.com"
	},
	{
		id: "pawa",
		name: "betPawa",
		sharp: false,
		region: "Kenya",
		href: "https://www.betpawa.co.ke"
	},
	{
		id: "mozz",
		name: "MozzartBet",
		sharp: false,
		region: "Kenya",
		href: "https://www.mozzartbet.co.ke"
	},
	{
		id: "bang",
		name: "Bangbet",
		sharp: false,
		region: "Kenya",
		href: "https://www.bangbet.com"
	},
	{
		id: "xbet",
		name: "1xBet",
		sharp: false,
		region: "International",
		href: "https://1xbet.com"
	},
	{
		id: "22b",
		name: "22Bet",
		sharp: false,
		region: "International",
		href: "https://22bet.com"
	},
	{
		id: "mel",
		name: "Melbet",
		sharp: false,
		region: "International",
		href: "https://melbet.com"
	},
	{
		id: "b365",
		name: "Bet365",
		sharp: false,
		region: "International",
		href: "https://www.bet365.com"
	},
	{
		id: "wh",
		name: "William Hill",
		sharp: false,
		region: "International",
		href: "https://www.williamhill.com"
	},
	{
		id: "uni",
		name: "Unibet",
		sharp: false,
		region: "International",
		href: "https://www.unibet.com"
	},
	{
		id: "bw",
		name: "Betway",
		sharp: false,
		region: "International",
		href: "https://betway.com"
	},
	{
		id: "dk",
		name: "DraftKings",
		sharp: false,
		region: "International",
		href: "https://www.draftkings.com"
	},
	{
		id: "fd",
		name: "FanDuel",
		sharp: false,
		region: "International",
		href: "https://www.fanduel.com"
	}
];
var MAX_GOALS = 8;
function poisson(k, lambda) {
	let p = Math.exp(-lambda);
	for (let i = 1; i <= k; i++) p *= lambda / i;
	return p;
}
function hashString(s) {
	let h = 2166136261;
	for (let i = 0; i < s.length; i++) {
		h ^= s.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
function rng(seed) {
	let x = seed || 1;
	return () => {
		x = Math.imul(1664525, x) + 1013904223 >>> 0;
		return x / 4294967296;
	};
}
function shadeToward(ps, index, amount) {
	const next = ps.slice();
	const pool = next.reduce((sum, p, i) => i === index ? sum : sum + p, 0);
	if (pool <= 0) return next;
	const shift = Math.min(amount, pool * .8);
	for (let i = 0; i < next.length; i++) if (i !== index) next[i] -= shift * (next[i] / pool);
	next[index] += shift;
	return next;
}
function blankOdds() {
	return {
		home: 0,
		draw: 0,
		away: 0,
		btts: 0,
		over25: 0,
		under25: 0,
		over15: 0,
		over35: 0,
		corners95: 0,
		red: 0
	};
}
function cornerRead(lh, la) {
	const total = Math.min(14, Math.max(7, 6.6 + (lh + la) * 1.45));
	const home = total * (lh / (lh + la || 1));
	let under = 0;
	let p = Math.exp(-total);
	for (let k = 0; k <= 9; k++) {
		if (k > 0) p *= total / k;
		under += p;
	}
	return {
		total,
		home,
		over95: 1 - under
	};
}
function cardRead(lh, la) {
	const yellows = Math.min(6.4, Math.max(2.2, 2.5 + (lh + la) * .55));
	return {
		yellows,
		red: 1 - Math.exp(-Math.min(.36, .08 + yellows * .028))
	};
}
function round2(n) {
	return Math.round(n * 100) / 100;
}
/** Decimal odds for a probability group, plus the de-vigged fair probs. */
function quoteGroup(probs, book, seed, publicIndex) {
	const rand = rng(hashString(`${seed}:${book.id}`));
	const margin = book.sharp ? .02 + rand() * .012 : .048 + rand() * .03;
	const shade = book.sharp ? rand() * .01 : .018 + rand() * .05;
	const width = book.sharp ? .04 : .07;
	let next = shadeToward(probs, publicIndex, shade);
	next = next.map((p) => Math.max(.025, p * (1 - width / 2 + rand() * width)));
	const sum = next.reduce((a, b) => a + b, 0);
	next = next.map((p) => p / sum);
	const odds = next.map((p) => round2(1 / Math.max(.04, p * (1 + margin))));
	const implied = odds.map((o) => 1 / o);
	const impSum = implied.reduce((a, b) => a + b, 0);
	return {
		odds,
		fair: implied.map((p) => p / impSum)
	};
}
function confidenceOf(edge) {
	const pts = edge * 100;
	if (pts < 2) return "Thin";
	if (pts <= 8) return "High";
	if (pts <= 13) return "Solid";
	return "Outlier";
}
function lambdas(home, away) {
	return adjustedLambdas(home, away);
}
function scoreMatrix(lh, la) {
	const homeP = Array.from({ length: MAX_GOALS }, (_, k) => poisson(k, lh));
	const awayP = Array.from({ length: MAX_GOALS }, (_, k) => poisson(k, la));
	let pHome = 0;
	let pDraw = 0;
	let pAway = 0;
	let pBtts = 0;
	let pOver = 0;
	let p15 = 0;
	let p35 = 0;
	const totals = Array.from({ length: 7 }, () => 0);
	let best = {
		h: 0,
		a: 0,
		p: 0
	};
	for (let h = 0; h < MAX_GOALS; h++) for (let a = 0; a < MAX_GOALS; a++) {
		const weight = dixonTau(h, a, lh, la);
		const p = homeP[h] * awayP[a] * weight;
		if (h > a) pHome += p;
		else if (h === a) pDraw += p;
		else pAway += p;
		if (h > 0 && a > 0) pBtts += p;
		const t = h + a;
		if (t >= 2) p15 += p;
		if (t >= 3) pOver += p;
		if (t >= 4) p35 += p;
		if (t <= 6) totals[t] += p;
		if (p > best.p) best = {
			h,
			a,
			p
		};
	}
	const mass = pHome + pDraw + pAway;
	return {
		model: {
			home: pHome / mass,
			draw: pDraw / mass,
			away: pAway / mass,
			btts: pBtts / mass,
			over25: pOver / mass,
			under25: 1 - pOver / mass,
			over15: p15 / mass,
			over35: p35 / mass,
			corners95: 0,
			red: 0
		},
		score: `${best.h}–${best.a}`,
		goalDist: totals.map((p, goals) => ({
			goals: goals === 6 ? "6+" : String(goals),
			pct: Math.round(p / mass * 1e3) / 10
		}))
	};
}
function phrase(match, market) {
	switch (market) {
		case "home": return `${match.home.short} to win`;
		case "away": return `${match.away.short} to win`;
		case "draw": return "the draw";
		case "btts": return "both teams to score";
		case "over25": return "over 2.5 goals";
		case "under25": return "under 2.5 goals";
		case "over15": return "over 1.5 goals";
		case "over35": return "over 3.5 goals";
		case "corners95": return "over 9.5 corners";
		case "red": return "a red card";
	}
}
function buildRead(match, likely, desk, model) {
	const h = Math.round(model.home * 100);
	const d = Math.round(model.draw * 100);
	const a = Math.round(model.away * 100);
	const split = `Chances: ${h}% ${match.home.short}, ${d}% draw, ${a}% ${match.away.short}. Most likely result is ${phrase(match, likely.market)} (${Math.round(likely.model * 100)}%).`;
	if (!desk) return `${split}${likely.odds < 1.7 ? ` ${phrase(match, likely.market)} is ${likely.odds.toFixed(2)}, which is too short to be the bet.` : ""} A pick has to be at least 1.70 and no longer than 3.75, with an edge against the sharp prices. Otherwise it is a pass.`;
	const price = `${phrase(match, desk.market)} at ${desk.odds.toFixed(2)} with ${desk.book} is ${(desk.edge * 100).toFixed(1)} pts above the de-vigged market (${(desk.ev * 100).toFixed(1)}% expected value).`;
	if (desk.market === likely.market) return `${split} That side is also the soft price: ${price} Still not a promise.`;
	return `${split} The plus-EV number is a different bet: ${price} Likely and value are not the same call.`;
}
var PUBLIC = {
	"lee-tot": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"ars-hul": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"ful-new": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"nfo-mci": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"bvb-elv": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"koe-b04": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"m05-bay": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"tor-lec": {
		side: 0,
		totals: 1,
		btts: 1
	},
	"rom-sas": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"bha-bre": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"cry-liv": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"sun-che": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"ips-bou": {
		side: 2,
		totals: 0,
		btts: 1
	},
	"mun-avl": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"val-rma": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"atm-bar": {
		side: 2,
		totals: 0,
		btts: 0
	},
	"nap-laz": {
		side: 0,
		totals: 0,
		btts: 0
	},
	"gen-mil": {
		side: 2,
		totals: 1,
		btts: 1
	},
	"fio-juv": {
		side: 2,
		totals: 1,
		btts: 1
	},
	"int-com": {
		side: 0,
		totals: 0,
		btts: 0
	}
};
function priceMatch(match) {
	const lam = lambdas(match.home, match.away);
	const scored = scoreMatrix(lam.home, lam.away);
	const corners = cornerRead(lam.home, lam.away);
	const cards = cardRead(lam.home, lam.away);
	const model = {
		...scored.model,
		corners95: corners.over95,
		red: cards.red
	};
	const books = BOOKS.map((book) => ({
		id: book.id,
		name: book.name,
		sharp: book.sharp,
		odds: blankOdds()
	}));
	const fairSums = blankOdds();
	for (const book of BOOKS) {
		const row = books.find((b) => b.id === book.id);
		const pub = PUBLIC[match.id] ?? {
			side: 0,
			totals: 0,
			btts: 0
		};
		const groups = [
			{
				keys: [
					"home",
					"draw",
					"away"
				],
				probs: [
					model.home,
					model.draw,
					model.away
				],
				publicIndex: pub.side,
				seed: `${match.id}:1x2`
			},
			{
				keys: ["btts"],
				probs: [model.btts, 1 - model.btts],
				publicIndex: pub.btts,
				seed: `${match.id}:btts`
			},
			{
				keys: ["over25", "under25"],
				probs: [model.over25, model.under25],
				publicIndex: pub.totals,
				seed: `${match.id}:ou`
			},
			{
				keys: ["over15"],
				probs: [model.over15, 1 - model.over15],
				publicIndex: 0,
				seed: `${match.id}:o15`
			},
			{
				keys: ["over35"],
				probs: [model.over35, 1 - model.over35],
				publicIndex: 0,
				seed: `${match.id}:o35`
			},
			{
				keys: ["corners95"],
				probs: [model.corners95, 1 - model.corners95],
				publicIndex: 0,
				seed: `${match.id}:corners`
			},
			{
				keys: ["red"],
				probs: [model.red, 1 - model.red],
				publicIndex: 0,
				seed: `${match.id}:red`
			}
		];
		for (const group of groups) {
			const quoted = quoteGroup(group.probs, book, group.seed, group.publicIndex);
			group.keys.forEach((key, i) => {
				row.odds[key] = quoted.odds[i];
				if (book.sharp) fairSums[key] += quoted.fair[i];
			});
		}
	}
	const consensus = {};
	const best = {};
	const sharpCount = BOOKS.filter((book) => book.sharp).length;
	for (const key of MARKET_KEYS) {
		consensus[key] = fairSums[key] / sharpCount;
		let top = books[0];
		for (const b of books) if (b.odds[key] > top.odds[key]) top = b;
		best[key] = {
			odds: top.odds[key],
			book: top.name,
			bookId: top.id
		};
	}
	const edges = MARKET_KEYS.map((market) => {
		const odds = best[market].odds;
		const edge = model[market] - consensus[market];
		return {
			market,
			model: model[market],
			consensus: consensus[market],
			edge,
			odds,
			book: best[market].book,
			bookId: best[market].bookId,
			ev: model[market] * odds - 1,
			confidence: confidenceOf(edge)
		};
	}).sort((a, b) => b.ev - a.ev);
	const likely = edges.filter((e) => e.market === "home" || e.market === "draw" || e.market === "away").sort((a, b) => b.model - a.model)[0];
	if (!likely) throw new Error(`No 1X2 price for ${match.id}`);
	const desk = edges.find((e) => e.ev >= .02 && e.edge >= .02 && e.odds >= 1.7 && e.odds <= 3.75 && e.model >= .28) ?? null;
	return {
		...match,
		model,
		books,
		consensus,
		best,
		edges,
		likely,
		desk,
		lambdaHome: lam.home,
		lambdaAway: lam.away,
		score: scored.score,
		goalDist: scored.goalDist,
		read: buildRead(match, likely, desk, model),
		extras: {
			corners: corners.total,
			homeCorners: corners.home,
			yellows: cards.yellows
		}
	};
}
var MATCHES = [
	...RAW_MATCHES,
	...MORE_MATCHES,
	...REST_MATCHES
].map(priceMatch);
var LEAGUES = [
	{
		code: "ALL",
		label: "All"
	},
	{
		code: "EPL",
		label: "EPL"
	},
	{
		code: "UCL",
		label: "UCL"
	},
	{
		code: "UEL",
		label: "Europa"
	},
	{
		code: "UEC",
		label: "UECL"
	},
	{
		code: "LIB",
		label: "Libertadores"
	},
	{
		code: "SUD",
		label: "Sudamericana"
	},
	{
		code: "LAL",
		label: "La Liga"
	},
	{
		code: "SEA",
		label: "Serie A"
	},
	{
		code: "BUN",
		label: "Bundesliga"
	},
	{
		code: "B2",
		label: "2. Bundesliga"
	},
	{
		code: "FRA",
		label: "Ligue 1"
	},
	{
		code: "ERE",
		label: "Eredivisie"
	},
	{
		code: "POR",
		label: "Portugal"
	},
	{
		code: "CHP",
		label: "Championship"
	},
	{
		code: "L1",
		label: "League One"
	},
	{
		code: "SPL",
		label: "Scotland"
	},
	{
		code: "MLS",
		label: "MLS"
	},
	{
		code: "MEX",
		label: "Liga MX"
	},
	{
		code: "BRA",
		label: "Brazil"
	},
	{
		code: "ARG",
		label: "Argentina"
	},
	{
		code: "TUR",
		label: "Turkey"
	},
	{
		code: "BEL",
		label: "Belgium"
	},
	{
		code: "GRE",
		label: "Greece"
	},
	{
		code: "AUT",
		label: "Austria"
	},
	{
		code: "SUI",
		label: "Switzerland"
	},
	{
		code: "SAU",
		label: "Saudi"
	},
	{
		code: "J1",
		label: "J.League"
	},
	{
		code: "KEN",
		label: "Kenya"
	},
	{
		code: "NGA",
		label: "Nigeria"
	},
	{
		code: "RSA",
		label: "South Africa"
	},
	{
		code: "EGY",
		label: "Egypt"
	}
];
function selectionName(match, market) {
	switch (market) {
		case "home": return `${match.home.name} to win`;
		case "away": return `${match.away.name} to win`;
		case "draw": return "Draw";
		case "btts": return "Both teams to score";
		case "over25": return "Over 2.5 goals";
		case "under25": return "Under 2.5 goals";
		case "over15": return "Over 1.5 goals";
		case "over35": return "Over 3.5 goals";
		case "corners95": return "Over 9.5 corners";
		case "red": return "A red card";
	}
}
function shortMarket(match, market) {
	switch (market) {
		case "home": return match.home.short;
		case "away": return match.away.short;
		case "draw": return "Draw";
		case "btts": return "BTTS";
		case "over25": return "Over 2.5";
		case "under25": return "Under 2.5";
		case "over15": return "Over 1.5";
		case "over35": return "Over 3.5";
		case "corners95": return "Corners 9.5";
		case "red": return "Red card";
	}
}
function marketLabel(market) {
	switch (market) {
		case "home": return "Home";
		case "draw": return "Draw";
		case "away": return "Away";
		case "btts": return "BTTS";
		case "over25": return "O 2.5";
		case "under25": return "U 2.5";
		case "over15": return "O 1.5";
		case "over35": return "O 3.5";
		case "corners95": return "Corners";
		case "red": return "Red card";
	}
}
/** Quarter-Kelly, capped at 4% of bankroll. */
function suggestedStake(edge, bankroll) {
	if (edge.ev <= 0 || bankroll <= 0 || edge.odds < 1.7) return 0;
	const b = edge.odds - 1;
	if (b <= 0) return 0;
	const full = (b * edge.model - (1 - edge.model)) / b;
	const capped = Math.min(Math.max(0, full) * .25, .04);
	return Math.round(capped * bankroll * 100) / 100;
}
function findMatch(id) {
	return findAny(id);
}
var RECENT = RECENT_RAW.map((row) => {
	return {
		...priceMatch(row),
		homeGoals: row.homeGoals,
		awayGoals: row.awayGoals,
		playedLabel: row.playedLabel
	};
});
var LIVE = LIVE_RAW.map((row) => priceMatch(row));
function findAny(id) {
	return MATCHES.find((m) => m.id === id) ?? RECENT.find((m) => m.id === id) ?? LIVE.find((m) => m.id === id);
}
function quoteAt(match, bookId, market) {
	const book = match.books.find((row) => row.id === bookId) ?? match.books[0];
	const odds = book.odds[market];
	return {
		odds,
		book: book.name,
		bookId: book.id,
		edge: match.model[market] - match.consensus[market],
		ev: match.model[market] * odds - 1
	};
}
function fairOdds(probability) {
	return Math.round(1 / Math.max(.02, probability) * 100) / 100;
}
function doubleChance(match) {
	const best = [
		{
			label: `${match.home.short} or draw`,
			probability: match.model.home + match.model.draw
		},
		{
			label: `${match.away.short} or draw`,
			probability: match.model.away + match.model.draw
		},
		{
			label: `${match.home.short} or ${match.away.short}`,
			probability: match.model.home + match.model.away
		}
	].sort((a, b) => b.probability - a.probability)[0];
	return {
		...best,
		fair: fairOdds(best.probability)
	};
}
function kickoffMs(id) {
	const iso = KICKOFF_ISO[id];
	return iso ? Date.parse(iso) : null;
}
function mix(seed) {
	let h = 2166136261;
	for (let i = 0; i < seed.length; i++) {
		h ^= seed.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return h >>> 0;
}
/** Tiny demo drift so the board feels live. Not a bookmaker feed. */
function tapeOdds(base, seed, bucket) {
	const swing = mix(`${seed}:${bucket}`) % 5 - 2;
	return Math.round(Math.max(1.01, base + swing * .01) * 100) / 100;
}
function modelRecord() {
	let hit = 0;
	for (const match of RECENT) if ((match.homeGoals > match.awayGoals ? "home" : match.homeGoals < match.awayGoals ? "away" : "draw") === match.likely.market) hit += 1;
	return {
		hit,
		n: RECENT.length
	};
}
function actualSide(match) {
	if (match.homeGoals > match.awayGoals) return "home";
	if (match.homeGoals < match.awayGoals) return "away";
	return "draw";
}
//#endregion
export { predictionFeeds as A, findMatch as C, marketLabel as D, liveFixture as E, selectionName as F, shortMarket as I, suggestedStake as L, readLine as M, removeVig as N, matchMarks as O, scoreTriple as P, tapeOdds as R, findAny as S, kickoffMs as T, decide as _, LIVE as a, eloUpdate as b, MATCHES as c, adjustedLambdas as d, argmax as f, calibrate as g, brier as h, LEAGUE_CODES as i, quoteAt as j, modelRecord as k, RECENT as l, blendWithMarket as m, KICKOFF_ISO as n, LIVE_RAW as o, baseLambdas as p, LEAGUES as r, MARKET_KEYS as s, BOOKS as t, actualSide as u, doubleChance as v, fitTemperature as w, fairOdds as x, eloExpected as y };
