import { r as __exportAll } from "../_runtime.mjs";
import { t as __exportAll$1 } from "./rolldown-runtime-D7D4PA-g.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/analysis-Cbzgc3mb.js
var analysis_Cbzgc3mb_exports = /* @__PURE__ */ __exportAll({
	a: () => fatigueFactor,
	c: () => multiSeasonElo,
	d: () => tableMotivation,
	f: () => venuePpg,
	i: () => closingLineComparison,
	l: () => oddsMovement,
	m: () => weatherDiagnostics,
	n: () => applyLeagueDrawPrior,
	o: () => fitTimeDecayedDixonColes,
	p: () => venueSplitFactor,
	r: () => assessFreshness,
	s: () => fittedDcProbabilities,
	t: () => analysis_exports,
	u: () => perLeagueAccuracy
});
var analysis_exports = /* @__PURE__ */ __exportAll$1({
	applyLeagueDrawPrior: () => applyLeagueDrawPrior,
	assessFreshness: () => assessFreshness,
	closingLineComparison: () => closingLineComparison,
	fatigueFactor: () => fatigueFactor,
	fitTimeDecayedDixonColes: () => fitTimeDecayedDixonColes,
	fittedDcProbabilities: () => fittedDcProbabilities,
	multiSeasonElo: () => multiSeasonElo,
	oddsMovement: () => oddsMovement,
	perLeagueAccuracy: () => perLeagueAccuracy,
	restDays: () => restDays,
	tableMotivation: () => tableMotivation,
	venuePpg: () => venuePpg,
	venueSplitFactor: () => venueSplitFactor,
	weatherDiagnostics: () => weatherDiagnostics
});
var KEYS = [
	"home",
	"draw",
	"away"
];
var clamp = (n, lo, hi) => Math.min(hi, Math.max(lo, n));
var finiteDate = (value) => Number.isFinite(Date.parse(value));
function normalize(p) {
	const values = KEYS.map((key) => Number.isFinite(p[key]) ? Math.max(0, p[key]) : 0);
	const sum = values.reduce((a, b) => a + b, 0);
	if (!sum) return {
		home: 1 / 3,
		draw: 1 / 3,
		away: 1 / 3
	};
	return {
		home: values[0] / sum,
		draw: values[1] / sum,
		away: values[2] / sum
	};
}
/** Computes non-negative recovery time between completed fixture and kickoff. */
function restDays(previousKickoff, nextKickoff) {
	if (!previousKickoff || !finiteDate(previousKickoff) || !finiteDate(nextKickoff)) return null;
	const hours = (Date.parse(nextKickoff) - Date.parse(previousKickoff)) / 36e5;
	return hours >= 0 ? hours / 24 : null;
}
/** Small, bounded fatigue multiplier; unknown rest is neutral but remains an explicit missing signal. */
function fatigueFactor(days, recentMatchesIn14Days = 0) {
	if (days === null || !Number.isFinite(days)) return 1;
	return clamp((days <= 2 ? .92 : days <= 3 ? .96 : days <= 4 ? .985 : days >= 9 ? 1.01 : 1) - Math.max(0, recentMatchesIn14Days - 2) * .012, .86, 1.02);
}
/** Home/away PPG summaries from completed real results, kept separate from overall form. */
function venuePpg(matches, teamId, venue) {
	const selected = matches.filter((m) => venue === "home" ? m.homeId === teamId : m.awayId === teamId);
	const points = selected.reduce((sum, m) => {
		const gf = venue === "home" ? m.homeGoals : m.awayGoals;
		const ga = venue === "home" ? m.awayGoals : m.homeGoals;
		return sum + (gf > ga ? 3 : gf === ga ? 1 : 0);
	}, 0);
	return {
		games: selected.length,
		ppg: selected.length ? points / selected.length : null
	};
}
/** Shrink a venue PPG ratio toward neutral and cap its effect to avoid small-sample overreaction. */
function venueSplitFactor(overallPpg, venueSpecificPpg, games, priorGames = 8) {
	if (games < 4 || overallPpg === null || venueSpecificPpg === null || overallPpg <= 0) return 1;
	return clamp(1 + (venueSpecificPpg / overallPpg - 1) * (games / (games + priorGames)), .9, 1.1);
}
function tableMotivation(position, totalTeams, gamesLeft) {
	if (!position || !totalTeams || gamesLeft === null || !Number.isFinite(position + totalTeams + gamesLeft) || position < 1 || totalTeams < position || gamesLeft < 0) return {
		stakes: "unknown",
		factor: null
	};
	if (gamesLeft > 14) return {
		stakes: "unknown",
		factor: 1
	};
	if (position <= 2) return {
		stakes: "title-race",
		factor: 1.02
	};
	if (position <= 4) return {
		stakes: "continental-race",
		factor: 1.015
	};
	if (position >= totalTeams - 2) return {
		stakes: "relegation-risk",
		factor: 1.02
	};
	if (gamesLeft <= 5 && position > 6 && position < totalTeams - 4) return {
		stakes: "mid-table",
		factor: .99
	};
	return {
		stakes: "unknown",
		factor: 1
	};
}
/** Reweights a fair 1X2 market from two real timestamped quotes; null means not enough evidence. */
function oddsMovement(opening, current) {
	const fair = (o) => {
		if (!o || KEYS.some((k) => !Number.isFinite(o[k]) || o[k] <= 1)) return null;
		return normalize({
			home: 1 / o.home,
			draw: 1 / o.draw,
			away: 1 / o.away
		});
	};
	const a = fair(opening), b = fair(current);
	if (!a || !b) return null;
	return {
		home: b.home - a.home,
		draw: b.draw - a.draw,
		away: b.away - a.away
	};
}
/** Forecast-to-close comparison. This is not a placed-bet CLV without the user's actual taken price. */
function closingLineComparison(model, closingOdds) {
	if (!closingOdds || KEYS.some((k) => !Number.isFinite(closingOdds[k]) || closingOdds[k] <= 1)) return null;
	const fairClose = normalize({
		home: 1 / closingOdds.home,
		draw: 1 / closingOdds.draw,
		away: 1 / closingOdds.away
	});
	const p = normalize(model);
	const pick = KEYS.reduce((best, key) => p[key] > p[best] ? key : best, "home");
	return {
		pick,
		modelProbability: p[pick],
		closingFairProbability: fairClose[pick],
		probabilityGap: p[pick] - fairClose[pick],
		fairOddsGapPct: (1 / fairClose[pick] / (1 / p[pick]) - 1) * 100
	};
}
/** Per-fixture source gate. Missing or stale required data cannot silently count as fresh. */
function assessFreshness(sources, nowMs = Date.now()) {
	const reasons = [];
	const required = sources.filter((s) => s.required);
	if (!required.length) return {
		status: "missing",
		action: "pass",
		ageHours: null,
		reasons: ["No required source was declared."]
	};
	const ages = required.map((source) => {
		if (!source.observedAt || !finiteDate(source.observedAt)) {
			reasons.push(`${source.name}: timestamp missing`);
			return null;
		}
		const age = (nowMs - Date.parse(source.observedAt)) / 36e5;
		if (age < 0) {
			reasons.push(`${source.name}: timestamp is in the future`);
			return null;
		}
		if (age > (source.maxAgeHours ?? 24)) reasons.push(`${source.name}: stale (${age.toFixed(1)} h old)`);
		return age;
	});
	if (ages.some((age) => age === null)) return {
		status: "missing",
		action: "pass",
		ageHours: null,
		reasons
	};
	const maxAge = Math.max(...ages);
	const stale = required.some((s) => (nowMs - Date.parse(s.observedAt)) / 36e5 > (s.maxAgeHours ?? 24));
	return {
		status: stale ? "stale" : "fresh",
		action: stale ? maxAge > 48 ? "pass" : "downgrade" : "allow",
		ageHours: maxAge,
		reasons
	};
}
/** Shrink league draw frequency toward the global prior and move only a bounded amount of probability. */
function applyLeagueDrawPrior(p, leagueDraws, sample, globalDrawRate = .26, priorMatches = 60) {
	if (sample < 20 || !Number.isFinite(leagueDraws) || leagueDraws < 0 || leagueDraws > sample) return normalize(p);
	const target = (leagueDraws + globalDrawRate * priorMatches) / (sample + priorMatches);
	const strength = sample / (sample + priorMatches);
	const shift = clamp((target - p.draw) * strength, -.03, .03);
	const oldSides = p.home + p.away || 1;
	return normalize({
		home: p.home - shift * (p.home / oldSides),
		draw: p.draw + shift,
		away: p.away - shift * (p.away / oldSides)
	});
}
/** Elo with between-season regression toward the global prior; caller supplies multi-season real results. */
function multiSeasonElo(matches, options = {}) {
	const k = options.k ?? 20, homeEdge = options.homeEdge ?? 60, carry = clamp(options.carry ?? .75, 0, 1);
	const ratings = /* @__PURE__ */ new Map();
	const ordered = [...matches].filter((m) => m.homeId && m.awayId && m.homeId !== m.awayId && Number.isInteger(m.homeGoals) && Number.isInteger(m.awayGoals) && m.homeGoals >= 0 && m.awayGoals >= 0 && finiteDate(m.kickoffAt)).sort((a, b) => Date.parse(a.kickoffAt) - Date.parse(b.kickoffAt));
	let previousSeason;
	for (const m of ordered) {
		if (m.season !== void 0 && previousSeason !== void 0 && m.season !== previousSeason) for (const [id, rating] of ratings) ratings.set(id, 1500 + (rating - 1500) * carry);
		previousSeason = m.season ?? previousSeason;
		const rh = ratings.get(m.homeId) ?? 1500, ra = ratings.get(m.awayId) ?? 1500;
		const expected = 1 / (1 + 10 ** ((ra - (rh + homeEdge)) / 400));
		const actual = m.homeGoals > m.awayGoals ? 1 : m.homeGoals === m.awayGoals ? .5 : 0;
		const delta = k * (Math.log(Math.abs(m.homeGoals - m.awayGoals) + 1) + 1) * (actual - expected);
		ratings.set(m.homeId, rh + delta);
		ratings.set(m.awayId, ra - delta);
	}
	return {
		ratings,
		matches: ordered.length,
		seasons: [...new Set(ordered.map((m) => m.season).filter((x) => x !== void 0))].sort()
	};
}
function factorial(n) {
	let value = 1;
	for (let i = 2; i <= n; i++) value *= i;
	return value;
}
function poisson(k, lambda) {
	return Math.exp(-lambda) * lambda ** k / factorial(k);
}
function tauAndDerivatives(h, a, lh, la, rho) {
	if (h === 0 && a === 0) {
		const t = 1 - lh * la * rho;
		return {
			t,
			gh: -lh * la * rho / t,
			ga: -lh * la * rho / t,
			gr: -lh * la / t
		};
	}
	if (h === 0 && a === 1) {
		const t = 1 + lh * rho;
		return {
			t,
			gh: lh * rho / t,
			ga: 0,
			gr: lh / t
		};
	}
	if (h === 1 && a === 0) {
		const t = 1 + la * rho;
		return {
			t,
			gh: 0,
			ga: la * rho / t,
			gr: la / t
		};
	}
	if (h === 1 && a === 1) {
		const t = 1 - rho;
		return {
			t,
			gh: 0,
			ga: 0,
			gr: -1 / t
		};
	}
	return {
		t: 1,
		gh: 0,
		ga: 0,
		gr: 0
	};
}
/**
* Fits attack/defence, home advantage, and low-score rho by time-decayed maximum likelihood.
* Returns null for an under-sized or malformed corpus; do not market this as a trained model until present.
*/
function fitTimeDecayedDixonColes(matches, options = {}) {
	const valid = matches.filter((m) => m.homeId && m.awayId && m.homeId !== m.awayId && Number.isInteger(m.homeGoals) && Number.isInteger(m.awayGoals) && m.homeGoals >= 0 && m.awayGoals >= 0 && finiteDate(m.kickoffAt));
	const minMatches = options.minMatches ?? 100;
	const teams = [...new Set(valid.flatMap((m) => [m.homeId, m.awayId]))];
	const appearances = /* @__PURE__ */ new Map();
	for (const m of valid) {
		appearances.set(m.homeId, (appearances.get(m.homeId) ?? 0) + 1);
		appearances.set(m.awayId, (appearances.get(m.awayId) ?? 0) + 1);
	}
	if (valid.length < minMatches || teams.length < 4 || teams.some((team) => (appearances.get(team) ?? 0) < 5)) return null;
	const halfLifeDays = options.halfLifeDays ?? 365;
	if (!(halfLifeDays > 0)) return null;
	const nowMs = options.nowMs ?? Date.now();
	const weights = valid.map((m) => Math.exp(-Math.LN2 * Math.max(0, (nowMs - Date.parse(m.kickoffAt)) / 864e5) / halfLifeDays));
	const weightSum = weights.reduce((a, b) => a + b, 0);
	const avg = valid.reduce((s, m, i) => s + (m.homeGoals + m.awayGoals) * weights[i], 0) / (2 * weightSum);
	let mu = Math.log(clamp(avg, .35, 3.5));
	let homeAdv = .08, rho = -.06;
	const att = new Map(teams.map((t) => [t, 0]));
	const def = new Map(teams.map((t) => [t, 0]));
	const iterations = options.iterations ?? 250;
	const all = /* @__PURE__ */ new Map();
	all.set("mu", mu);
	all.set("homeAdv", homeAdv);
	all.set("rho", rho);
	for (const t of teams) {
		all.set(`a:${t}`, 0);
		all.set(`d:${t}`, 0);
	}
	const mom = /* @__PURE__ */ new Map(), vel = /* @__PURE__ */ new Map();
	for (let iteration = 1; iteration <= iterations; iteration++) {
		const grad = /* @__PURE__ */ new Map();
		const add = (key, value) => grad.set(key, (grad.get(key) ?? 0) + value);
		for (let i = 0; i < valid.length; i++) {
			const match = valid[i], w = weights[i] / weightSum;
			const lh = clamp(Math.exp(mu + (att.get(match.homeId) ?? 0) - (def.get(match.awayId) ?? 0) + homeAdv), .08, 4.5);
			const la = clamp(Math.exp(mu + (att.get(match.awayId) ?? 0) - (def.get(match.homeId) ?? 0)), .08, 4.5);
			const corr = tauAndDerivatives(match.homeGoals, match.awayGoals, lh, la, rho);
			if (!(corr.t > .05)) continue;
			const gh = w * (match.homeGoals - lh + corr.gh);
			const ga = w * (match.awayGoals - la + corr.ga);
			add("mu", gh + ga);
			add("homeAdv", gh);
			add("rho", w * corr.gr);
			add(`a:${match.homeId}`, gh);
			add(`d:${match.awayId}`, -gh);
			add(`a:${match.awayId}`, ga);
			add(`d:${match.homeId}`, -ga);
		}
		for (const [key, value] of all) {
			const g = (grad.get(key) ?? 0) - (key.startsWith("a:") || key.startsWith("d:") ? .02 * value : 0);
			const m = .9 * (mom.get(key) ?? 0) + .1 * g;
			const v = .999 * (vel.get(key) ?? 0) + .001 * g * g;
			mom.set(key, m);
			vel.set(key, v);
			const mhat = m / (1 - .9 ** iteration), vhat = v / (1 - .999 ** iteration);
			all.set(key, value + .025 * mhat / (Math.sqrt(vhat) + 1e-8));
		}
		mu = clamp(all.get("mu") ?? mu, Math.log(.35), Math.log(3.5));
		homeAdv = clamp(all.get("homeAdv") ?? homeAdv, -.25, .35);
		rho = clamp(all.get("rho") ?? rho, -.4, .4);
		const avgAtt = teams.reduce((s, t) => s + (all.get(`a:${t}`) ?? 0), 0) / teams.length;
		const avgDef = teams.reduce((s, t) => s + (all.get(`d:${t}`) ?? 0), 0) / teams.length;
		for (const t of teams) {
			const a = clamp((all.get(`a:${t}`) ?? 0) - avgAtt, -1.5, 1.5);
			const d = clamp((all.get(`d:${t}`) ?? 0) - avgDef, -1.5, 1.5);
			all.set(`a:${t}`, a);
			all.set(`d:${t}`, d);
			att.set(t, a);
			def.set(t, d);
		}
		all.set("mu", mu);
		all.set("homeAdv", homeAdv);
		all.set("rho", rho);
	}
	return {
		intercept: mu,
		homeAdvantage: homeAdv,
		rho,
		attack: Object.fromEntries(att),
		defence: Object.fromEntries(def),
		samples: valid.length,
		halfLifeDays
	};
}
/** Applies a fitted Dixon–Coles model to one pair; unknown teams have neutral team effects. */
function fittedDcProbabilities(model, homeId, awayId, maxGoals = 9) {
	const lh = clamp(Math.exp(model.intercept + (model.attack[homeId] ?? 0) - (model.defence[awayId] ?? 0) + model.homeAdvantage), .08, 4.5);
	const la = clamp(Math.exp(model.intercept + (model.attack[awayId] ?? 0) - (model.defence[homeId] ?? 0)), .08, 4.5);
	let home = 0, draw = 0, away = 0;
	for (let h = 0; h <= maxGoals; h++) for (let a = 0; a <= maxGoals; a++) {
		const corr = tauAndDerivatives(h, a, lh, la, model.rho).t;
		const p = poisson(h, lh) * poisson(a, la) * Math.max(.01, corr);
		if (h > a) home += p;
		else if (h === a) draw += p;
		else away += p;
	}
	return normalize({
		home,
		draw,
		away
	});
}
function perLeagueAccuracy(rows) {
	const groups = /* @__PURE__ */ new Map();
	for (const row of rows) {
		if (!row.result || !finiteDate(row.recordedAt) || !finiteDate(row.kickoffAt) || Date.parse(row.recordedAt) >= Date.parse(row.kickoffAt)) continue;
		groups.set(row.league, [...groups.get(row.league) ?? [], row]);
	}
	return [...groups.entries()].map(([league, xs]) => {
		const n = xs.length;
		const hits = xs.filter((r) => KEYS.reduce((a, b) => r.final[b] > r.final[a] ? b : a, "home") === r.result).length;
		const brier = xs.reduce((s, r) => s + KEYS.reduce((q, k) => q + (r.final[k] - (k === r.result ? 1 : 0)) ** 2, 0), 0) / n;
		const logLoss = -xs.reduce((s, r) => s + Math.log(Math.max(1e-9, r.final[r.result])), 0) / n;
		return {
			league,
			n,
			hitRate: hits / n,
			brier,
			logLoss
		};
	}).sort((a, b) => a.league.localeCompare(b.league));
}
/** Weather is a diagnostic only; no probability shift is implied. */
function weatherDiagnostics(input) {
	const flags = [];
	if (Number.isFinite(input.windKmh) && input.windKmh >= 45) flags.push("High wind may affect passing and crossing.");
	if (Number.isFinite(input.precipitationMm) && input.precipitationMm >= 2) flags.push("Heavy hourly precipitation may affect pitch conditions.");
	if (Number.isFinite(input.temperatureC) && (input.temperatureC <= 0 || input.temperatureC >= 32)) flags.push("Temperature is an extreme-matchday diagnostic.");
	return flags;
}
//#endregion
export { fatigueFactor as a, multiSeasonElo as c, tableMotivation as d, venuePpg as f, closingLineComparison as i, oddsMovement as l, weatherDiagnostics as m, applyLeagueDrawPrior as n, fitTimeDecayedDixonColes as o, venueSplitFactor as p, assessFreshness as r, fittedDcProbabilities as s, analysis_Cbzgc3mb_exports as t, perLeagueAccuracy as u };
