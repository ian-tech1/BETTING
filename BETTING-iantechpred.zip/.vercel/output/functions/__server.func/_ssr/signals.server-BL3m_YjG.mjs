import { b as eloUpdate } from "./price-D3Ht-t88.mjs";
import { n as boundedNudge, o as headToHead, s as injuryImpact } from "./backtest-DeRv33Nh.mjs";
import { t as env } from "./env.server-B4a86VpI.mjs";
import { n as normalizeTeamName } from "./jackpot-utils-2-SdMduq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/signals.server-BL3m_YjG.js
/** Server-only. Every fetch is optional: with no key the signal is simply absent. */
async function getJson(url, headers = {}) {
	const res = await fetch(url, {
		headers,
		signal: AbortSignal.timeout(8e3)
	});
	if (!res.ok) throw new Error(`${new URL(url).host} responded ${res.status}`);
	return res.json();
}
var TTL = 12e5;
var cache = /* @__PURE__ */ new Map();
async function cached(key, load) {
	const hit = cache.get(key);
	if (hit && Date.now() - hit.at < TTL) return hit.v;
	const v = await load();
	cache.set(key, {
		at: Date.now(),
		v
	});
	return v;
}
var COMPETITIONS = [
	"PL",
	"ELC",
	"BL1",
	"PD",
	"FL1",
	"SA",
	"DED",
	"PPL"
];
var same = (a, b) => {
	const x = normalizeTeamName(a), y = normalizeTeamName(b);
	return !!x && !!y && (x === y || x.length > 4 && y.includes(x) || y.length > 4 && x.includes(y));
};
/** Elo ratings built from real finished results (football-data.org). Cached 20 min. */
async function eloRatings() {
	const key = env("FOOTBALL_DATA_KEY");
	if (!key) return null;
	return cached("elo", async () => {
		const to = /* @__PURE__ */ new Date();
		const from = /* @__PURE__ */ new Date(Date.now() - 7776e5);
		const rows = [];
		for (const comp of COMPETITIONS.slice(0, 5)) try {
			for (let w = 0; w < 6; w++) {
				const t = /* @__PURE__ */ new Date(to.getTime() - w * 9 * 864e5);
				const f = /* @__PURE__ */ new Date(from.getTime() - w * 9 * 864e5);
				const j = await getJson(`https://api.football-data.org/v4/competitions/${comp}/matches?${new URLSearchParams({
					status: "FINISHED",
					dateFrom: f.toISOString().slice(0, 10),
					dateTo: t.toISOString().slice(0, 10)
				})}`, { "X-Auth-Token": key });
				for (const m of j.matches ?? []) {
					const gh = m.score?.fullTime?.home, ga = m.score?.fullTime?.away;
					if (typeof gh === "number" && typeof ga === "number") rows.push({
						date: m.utcDate,
						h: m.homeTeam.name,
						a: m.awayTeam.name,
						gh,
						ga
					});
				}
			}
		} catch {}
		rows.sort((x, y) => x.date.localeCompare(y.date));
		const r = /* @__PURE__ */ new Map();
		for (const m of rows) {
			const next = eloUpdate(r.get(m.h) ?? 1500, r.get(m.a) ?? 1500, m.gh, m.ga);
			r.set(m.h, next.home);
			r.set(m.a, next.away);
		}
		return r;
	});
}
/** Multi-bookmaker 1X2 for a pair of teams, with a rough opening price from the earliest update. */
async function bookOdds(home, away) {
	const key = env("ODDS_API_KEY");
	if (!key) return null;
	for (const sport of [
		"soccer_epl",
		"soccer_efl_champ",
		"soccer_germany_bundesliga",
		"soccer_spain_la_liga",
		"soccer_france_ligue_one",
		"soccer_italy_serie_a",
		"soccer_netherlands_eredivisie",
		"soccer_portugal_primeira_liga"
	]) try {
		const ev = (await cached(`odds-${sport}`, () => getJson(`https://api.the-odds-api.com/v4/sports/${sport}/odds/?apiKey=${key}&regions=eu,uk&markets=h2h&oddsFormat=decimal`))).find((e) => same(e.home_team, home) && same(e.away_team, away));
		if (!ev) continue;
		const books = [];
		for (const b of ev.bookmakers ?? []) {
			const m = b.markets?.find((x) => x.key === "h2h");
			const get = (n) => m?.outcomes?.find((o) => o.name === n)?.price;
			const h = get(ev.home_team), a = get(ev.away_team), d = get("Draw");
			if (h && a && d) books.push({
				home: h,
				draw: d,
				away: a
			});
		}
		if (books.length) return { books };
	} catch {}
	return null;
}
async function apiFootball(path, params) {
	const key = env("API_FOOTBALL_KEY");
	if (!key) return null;
	const qs = new URLSearchParams(Object.entries(params).map(([k, v]) => [k, String(v)])).toString();
	return cached(`af-${path}-${qs}`, () => getJson(`https://v3.football.api-sports.io/${path}?${qs}`, { "x-apisports-key": key }));
}
async function teamId(name) {
	return ((await apiFootball("teams", { search: name.split(" ")[0] }))?.response ?? []).find((t) => same(t.team.name, name))?.team?.id ?? null;
}
async function absences(id, season) {
	const j = await apiFootball("injuries", {
		team: id,
		season
	});
	const pos = {
		Goalkeeper: "GK",
		Defender: "DEF",
		Midfielder: "MID",
		Attacker: "FWD"
	};
	const seen = /* @__PURE__ */ new Set();
	const out = [];
	for (const row of j?.response ?? []) {
		if (seen.has(row.player?.id)) continue;
		seen.add(row.player?.id);
		out.push({
			role: pos[row.player?.type] ?? "UNK",
			starter: true
		});
	}
	return out.slice(0, 8);
}
async function h2h(a, b) {
	const j = await apiFootball("fixtures/headtohead", {
		h2h: `${a}-${b}`,
		last: 8
	});
	const out = [];
	for (const f of j?.response ?? []) {
		const gh = f.goals?.home, ga = f.goals?.away;
		if (typeof gh !== "number" || typeof ga !== "number") continue;
		const aWon = f.teams?.home?.id === a ? gh > ga : ga > gh;
		out.push(gh === ga ? "draw" : aWon ? "home" : "away");
	}
	return out;
}
/** Gemini model used by the optional AI analyst. Override with GEMINI_MODEL if your quota or region needs a different one. */
var GEMINI_MODEL_DEFAULT = "gemini-2.5-flash";
/**
* Optional AI analyst (Google Gemini). It only sees numbers we computed and may nudge each outcome by at most
* 4 points. Key: GEMINI_API_KEY (https://aistudio.google.com/apikey). The free tier has limited quotas, so
* replies are cached and any quota error (429) or outage simply drops this signal instead of breaking the page.
*/
async function aiNudge(home, away, base, facts) {
	const key = env("GEMINI_API_KEY");
	if (!key) return null;
	const model = env("GEMINI_MODEL") ?? GEMINI_MODEL_DEFAULT;
	const rounded = {
		home: +base.home.toFixed(3),
		draw: +base.draw.toFixed(3),
		away: +base.away.toFixed(3)
	};
	try {
		return await cached(`ai-${model}-${home}-${away}-${JSON.stringify(rounded)}-${facts}`, async () => {
			const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`, {
				method: "POST",
				headers: {
					"content-type": "application/json",
					"x-goog-api-key": key
				},
				signal: AbortSignal.timeout(12e3),
				body: JSON.stringify({
					systemInstruction: { parts: [{ text: "You are a football analyst. Reply with JSON only: {\"home\":n,\"draw\":n,\"away\":n,\"note\":\"short reason\"}. Each n is a probability change between -0.04 and 0.04. Use 0 when unsure. Never invent injuries or news; use only the facts given." }] },
					contents: [{
						role: "user",
						parts: [{ text: `${home} v ${away}. Model probabilities ${JSON.stringify(rounded)}. Facts: ${facts}` }]
					}],
					generationConfig: {
						temperature: 0,
						maxOutputTokens: 300,
						responseMimeType: "application/json",
						thinkingConfig: { thinkingBudget: 0 }
					}
				})
			});
			if (!res.ok) return null;
			const text = ((await res.json()).candidates?.[0]?.content?.parts ?? []).map((p) => p.text ?? "").join("").replace(/```json|```/g, "").trim();
			return boundedNudge(JSON.parse(text));
		});
	} catch {
		return null;
	}
}
async function buildSignals(home, away, base, context) {
	const used = [];
	const s = {
		used,
		notes: []
	};
	const apiFootballConfigured = !!env("API_FOOTBALL_KEY");
	const [elo, odds] = await Promise.all([apiFootballConfigured ? Promise.resolve(null) : eloRatings().catch(() => null), context ? Promise.resolve(null) : bookOdds(home, away).catch(() => null)]);
	if (elo) {
		const find = (n) => [...elo.entries()].find(([k]) => same(k, n))?.[1];
		const rh = find(home), ra = find(away);
		if (rh && ra) {
			const { eloTriple } = await import("./backtest-DeRv33Nh.mjs").then((n) => n.t).then((n) => n.f);
			s.elo = eloTriple(rh, ra);
			used.push("Elo from real results");
		}
	}
	if (odds) {
		const { multiBookConsensus } = await import("./backtest-DeRv33Nh.mjs").then((n) => n.t).then((n) => n.f);
		const c = multiBookConsensus(odds.books);
		if (c) {
			s.market = c.p;
			s.dispersion = c.dispersion;
			used.push(`${c.books} bookmakers`);
		}
	}
	let facts = "";
	if (env("API_FOOTBALL_KEY")) try {
		const reference = context?.kickoffAt && Number.isFinite(Date.parse(context.kickoffAt)) ? new Date(context.kickoffAt) : /* @__PURE__ */ new Date();
		const season = reference.getUTCMonth() >= 6 ? reference.getUTCFullYear() : reference.getUTCFullYear() - 1;
		const [hid, aid] = await Promise.all([teamId(home), teamId(away)]);
		if (hid && aid) {
			const [ha, aa, hh] = await Promise.all([
				absences(hid, season),
				absences(aid, season),
				h2h(hid, aid)
			]);
			const hi = injuryImpact(ha), ai = injuryImpact(aa);
			const swing = (hi.attack - 1 - (hi.defence - 1) - (ai.attack - 1 - (ai.defence - 1))) * .25;
			s.nudge = {
				home: swing,
				draw: 0,
				away: -swing
			};
			s.h2h = headToHead(hh) ?? void 0;
			facts = `Home absences ${ha.length}, away absences ${aa.length}, head-to-head results ${hh.length}.`;
			used.push("Injuries", "Head to head");
		}
	} catch {}
	const ai = await aiNudge(home, away, base, facts || "No injury data available.");
	if (ai && s.nudge) for (const k of [
		"home",
		"draw",
		"away"
	]) s.nudge[k] += ai[k];
	else if (ai) s.nudge = { ...ai };
	if (ai) used.push("Gemini analyst (bounded)");
	if (context) {
		const { loadMultiSourceSignals } = await import("./multi-source.server-Li04VPvB.mjs");
		let extra = {
			used: [],
			notes: ["Optional provider request failed; no live feature is assumed."]
		};
		try {
			extra = await loadMultiSourceSignals(context);
		} catch {}
		s.elo = extra.elo ?? s.elo;
		s.dixonColes = extra.dixonColes;
		s.market = extra.market ?? s.market;
		s.dispersion = extra.dispersion ?? s.dispersion;
		s.movement = extra.movement ?? s.movement;
		s.oddsMovement = extra.oddsMovement;
		s.drawPrior = extra.drawPrior;
		s.rest = extra.rest;
		s.venueSplit = extra.venueSplit;
		s.motivation = extra.motivation;
		s.lineups = extra.lineups;
		s.weather = extra.weather;
		s.freshness = extra.freshness;
		s.featureStatus = extra.featureStatus;
		if (extra.nudge) s.nudge = {
			home: (s.nudge?.home ?? 0) + extra.nudge.home,
			draw: (s.nudge?.draw ?? 0) + extra.nudge.draw,
			away: (s.nudge?.away ?? 0) + extra.nudge.away
		};
		s.notes?.push(...extra.notes ?? []);
		used.push(...extra.used);
	}
	return s;
}
//#endregion
export { buildSignals };
