import { c as MATCHES, n as KICKOFF_ISO } from "./price-D3Ht-t88.mjs";
import { i as getServerFnById, n as createServerFn, r as TSS_SERVER_FUNCTION } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/odds-reference-CLcyw1L8.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var ROOT = "https://www.surebetafrica.com";
var LEAGUE_SLUGS = {
	"Premier League": "premier-league",
	"La Liga": "la-liga",
	"Serie A": "serie-a",
	Bundesliga: "bundesliga",
	"Ligue 1": "ligue-1",
	Eredivisie: "eredivisie",
	"Primeira Liga": "primeira-liga",
	"Scottish Premiership": "scottish-premiership",
	Championship: "championship"
};
function slug(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/&/g, " and ").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
}
function visibleText(value) {
	return value.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ").replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ").replace(/<[^>]+>/g, " ").replace(/&nbsp;|&#160;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, "\"").replace(/&#39;|&apos;/gi, "'").replace(/\s+/g, " ").trim();
}
function normalized(value) {
	return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();
}
function numberSpans(row) {
	return [...row.matchAll(/<span\b[^>]*class=["'][^"']*tabular-nums[^"']*["'][^>]*>\s*(\d+(?:\.\d+)?)\s*<\/span>/gi)].map((match) => Number(match[1])).filter((value) => Number.isFinite(value) && value > 1.01 && value <= 100);
}
function parseSportPesaComparisonPage(html, homeName, awayName, sourceUrl) {
	const headingKey = normalized(visibleText(html.match(/<h1\b[^>]*>([\s\S]*?)<\/h1>/i)?.[1] ?? ""));
	if (!headingKey || !headingKey.includes(normalized(homeName)) || !headingKey.includes(normalized(awayName))) return {
		status: "fixture-mismatch",
		sourceUrl,
		freshness: "Fixture not verified",
		detail: "The returned page title did not confirm both teams exactly; no odds were accepted."
	};
	const movement = visibleText(html).match(/Last odds movement\s+(\d+\s+(?:seconds?|minutes?|hours?|days?|weeks?)\s+ago)/i)?.[1]?.trim();
	const freshness = movement ? `Aggregator reports last odds movement ${movement}; this is not a guaranteed quote timestamp.` : "The aggregator did not publish a clear odds-movement time.";
	const tables = [...html.matchAll(/<table\b[^>]*>[\s\S]*?<\/table>/gi)].map((item) => item[0]);
	const oneXTwoTable = tables.find((table) => {
		const header = normalized(visibleText(table));
		return header.includes("home") && header.includes("draw") && header.includes("away");
	});
	const row = (oneXTwoTable ? [oneXTwoTable] : tables).flatMap((table) => [...table.matchAll(/<tr\b[^>]*>[\s\S]*?<\/tr>/gi)].map((item) => item[0])).find((candidate) => /alt=["']SportPesa["']/i.test(candidate));
	const prices = row ? numberSpans(row) : [];
	if (!row || prices.length !== 3) return {
		status: "no-quote",
		sourceUrl,
		freshness,
		detail: "The exact fixture page did not expose a complete SportPesa 1X2 row. No estimate or other bookmaker price is substituted."
	};
	return {
		status: "found",
		sourceUrl,
		odds: {
			home: prices[0],
			draw: prices[1],
			away: prices[2]
		},
		freshness,
		detail: "Third-party comparison snapshot, not an official or guaranteed live SportPesa price. Verify directly before use."
	};
}
function checkedResult(result) {
	return {
		...result,
		checkedAt: (/* @__PURE__ */ new Date()).toISOString()
	};
}
async function fetchSportPesaReference(matchId) {
	const match = MATCHES.find((item) => item.id === matchId);
	if (!match) return checkedResult({
		status: "unsupported",
		freshness: "Not checked",
		detail: "Fixture ID is not present in this board; no odds were requested."
	});
	const leagueSlug = LEAGUE_SLUGS[match.league];
	const kickoff = KICKOFF_ISO[match.id];
	if (!leagueSlug || !kickoff) return checkedResult({
		status: "unsupported",
		freshness: "Not checked",
		detail: "This competition or fixture has no verified comparison-page route; no quote is shown."
	});
	if (Date.parse(kickoff) <= Date.now()) return checkedResult({
		status: "unsupported",
		freshness: "Pre-match page only",
		detail: "The listed kickoff has passed; this lookup does not treat old pre-match prices as current."
	});
	const sourceUrl = `${ROOT}/kenya/leagues/${leagueSlug}/${kickoff.slice(0, 10)}/${slug(match.home.name)}-vs-${slug(match.away.name)}`;
	let response;
	try {
		response = await fetch(sourceUrl, {
			headers: {
				Accept: "text/html",
				"User-Agent": "PredictionBoardPublicOddsReference/1.0"
			},
			signal: AbortSignal.timeout(9e3)
		});
	} catch {
		return checkedResult({
			status: "unavailable",
			sourceUrl,
			freshness: "Unavailable",
			detail: "The public comparison page could not be reached. No current SportPesa quote is shown."
		});
	}
	if (!response.ok) return checkedResult({
		status: "unavailable",
		sourceUrl,
		freshness: `HTTP ${response.status}`,
		detail: "The public comparison page did not return an accessible response. No quote is shown."
	});
	return checkedResult(parseSportPesaComparisonPage(await response.text(), match.home.name, match.away.name, sourceUrl));
}
var lookupSportPesaReference = createServerFn({ method: "GET" }).validator((matchId) => {
	if (typeof matchId !== "string" || matchId.length > 80 || !/^[a-z0-9-]+$/i.test(matchId)) throw new Error("Invalid fixture ID");
	return matchId;
}).handler(createSsrRpc("fdecb9614002dc4304a988a7f5c1f89704b52e8361169d26acfe5ddda6ba5c7d"));
//#endregion
export { fetchSportPesaReference as n, lookupSportPesaReference as r, createSsrRpc as t };
