import { o as __toESM } from "../_runtime.mjs";
import { A as predictionFeeds, C as findMatch, D as marketLabel, E as liveFixture, F as selectionName, I as shortMarket, L as suggestedStake, M as readLine, O as matchMarks, R as tapeOdds, T as kickoffMs, a as LIVE, c as MATCHES, f as argmax, i as LEAGUE_CODES, j as quoteAt, k as modelRecord, l as RECENT, n as KICKOFF_ISO, o as LIVE_RAW, r as LEAGUES, s as MARKET_KEYS, t as BOOKS$1, u as actualSide, v as doubleChance, x as fairOdds$1 } from "./price-D3Ht-t88.mjs";
import { c as liveConsensus, i as buildConsensus, l as predictorPickLabel, r as buildAdvancedReport, u as predictorShortLabel } from "./backtest-DeRv33Nh.mjs";
import { b as require_jsx_runtime, q as require_react } from "../_libs/@tanstack/react-router+[...].mjs";
import { n as createServerFn } from "./ssr.mjs";
import { r as lookupSportPesaReference, t as createSsrRpc } from "./odds-reference-CLcyw1L8.mjs";
import { i as sameTeam, o as topResult, t as isModelDisagreement } from "./jackpot-utils-2-SdMduq.mjs";
import { a as Ticket, c as Search, d as Info, f as History, i as Trash2, l as Radio, m as CalendarClock, n as Trophy, o as Star, p as Flag, s as Sparkles, t as X, u as Link2 } from "../_libs/lucide-react.mjs";
import { a as tipCovered, n as buildDashboard, o as toCsv, s as topCorrect } from "./tracker-B_iIlhXn.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as ResponsiveContainer, i as Bar, n as YAxis, o as Tooltip, r as XAxis, t as BarChart } from "../_libs/recharts+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-tz1J8PHV.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function pct$1(n) {
	return `${Math.round(n * 100)}%`;
}
function signedPts(n) {
	const v = n * 100;
	return `${v > 0 ? "+" : ""}${v.toFixed(1)} pts`;
}
function signedEv(n) {
	const v = n * 100;
	return `${v > 0 ? "+" : ""}${v.toFixed(1)}% EV`;
}
function oddsText(n) {
	return n.toFixed(2);
}
function units(n) {
	return n.toLocaleString("en-GB", {
		minimumFractionDigits: 2,
		maximumFractionDigits: 2
	});
}
function gcd(a, b) {
	return b === 0 ? a : gcd(b, a % b);
}
function formatOdds(decimal, format) {
	if (!Number.isFinite(decimal) || decimal <= 1) return "—";
	if (format === "decimal") return decimal.toFixed(2);
	if (format === "american") {
		if (decimal >= 2) return `+${Math.round((decimal - 1) * 100)}`;
		return `${Math.round(-100 / (decimal - 1))}`;
	}
	const profit = decimal - 1;
	const den = 20;
	const num = Math.max(1, Math.round(profit * den));
	const g = gcd(num, den);
	return `${num / g}/${den / g}`;
}
function riskBand(decimal) {
	if (decimal < 1.7) return "Short";
	if (decimal < 2.6) return "Mid";
	return "Long";
}
function countdown(kickoffMs, now) {
	const delta = kickoffMs - now;
	if (delta <= 0) return "Kicked off";
	const mins = Math.floor(delta / 6e4);
	const days = Math.floor(mins / 1440);
	const hours = Math.floor(mins % 1440 / 60);
	const rest = mins % 60;
	if (days > 0) return `${days}d ${hours}h`;
	if (hours > 0) return `${hours}h ${rest}m`;
	return `${rest}m`;
}
function FormPills({ form }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1",
		"aria-label": "Last five",
		children: form.map((mark, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "flex size-6 items-center justify-center rounded-full text-xs font-medium " + (mark === "W" ? "bg-signal text-ink" : mark === "D" ? "bg-raised text-fg" : "bg-line text-muted"),
			children: mark
		}, `${mark}-${index}`))
	});
}
function SplitBar({ match }) {
	const h = match.model.home * 100;
	const d = match.model.draw * 100;
	const a = match.model.away * 100;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-1.5 overflow-hidden rounded-full bg-raised",
		role: "img",
		"aria-label": `Model split ${pct$1(match.model.home)} home, ${pct$1(match.model.draw)} draw, ${pct$1(match.model.away)} away`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-signal",
				style: { width: `${h.toFixed(1)}%` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-muted",
				style: { width: `${d.toFixed(1)}%` }
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "bg-fg",
				style: { width: `${a.toFixed(1)}%` }
			})
		]
	});
}
/** Extra signals for one fixture. Returns an empty set when no provider key is configured. */
var getMatchSignals = createServerFn({ method: "GET" }).validator((id) => {
	if (typeof id !== "string" || id.length > 80 || !/^[a-z0-9-]+$/i.test(id)) throw new Error("Invalid fixture ID");
	return id;
}).handler(createSsrRpc("0af0fc41459e674fabd285222dfb4c3a692db7590fd2dc0efc8cec9c3a416062"));
createServerFn({ method: "GET" }).handler(createSsrRpc("8f90fff7fcbefdb2522c142f480e92366b88036b2f4dc494b49068559f1b830c"));
/** Only prospective, settled forecast-log rows may train the live consensus. */
var getPredictionLearningHistory = createServerFn({ method: "GET" }).handler(createSsrRpc("b5b14acc5da9f5326c04d72a67a8be0b061cbc72fafc8bd73bbd3ea577c5bb83"));
createServerFn({ method: "POST" }).handler(createSsrRpc("c70ece561479a999463b28b8cf398882c90b0e011efa77dc05ad8e73d779e73d"));
/**
* Historical backtest: scores every settled match on record against its real final result.
* Reads the whole settled_results table (not just the latest 100) so the sample grows as matches finish.
*/
var getBacktest = createServerFn({ method: "GET" }).handler(createSsrRpc("5cf53b12df380c39c243a2a658e745198ff738c87727b2219dc2a13bd44e135f"));
var learningHistoryCache = null;
function loadLearningHistory(force = false) {
	if (force || !learningHistoryCache) learningHistoryCache = getPredictionLearningHistory().then((rows) => rows).catch(() => []);
	return learningHistoryCache;
}
/** One reconciled Final tip that every screen shares, with server signals and recorded results folded in. */
function useConsensus(id, home, away, opts = {}) {
	const [history, setHistory] = (0, import_react.useState)([]);
	const [signals, setSignals] = (0, import_react.useState)(null);
	const refreshSignals = (0, import_react.useCallback)(async () => {
		const [freshSignals, freshHistory] = await Promise.all([getMatchSignals({ data: id }), loadLearningHistory(true)]);
		setSignals(freshSignals);
		setHistory(freshHistory);
	}, [id]);
	(0, import_react.useEffect)(() => {
		let alive = true;
		loadLearningHistory().then((rows) => alive && setHistory(rows));
		getMatchSignals({ data: id }).then((s) => alive && setSignals(s)).catch(() => void 0);
		return () => {
			alive = false;
		};
	}, [id]);
	return {
		...(0, import_react.useMemo)(() => buildConsensus(home, away, {
			odds: opts.odds,
			history,
			league: opts.league,
			live: opts.live,
			signals: signals ?? void 0
		}), [
			home,
			away,
			opts.odds,
			opts.league,
			opts.live,
			history,
			signals
		]),
		signalsUsed: signals?.used ?? [],
		providerSignals: signals,
		refreshSignals
	};
}
var NAME$1 = {
	home: "Home",
	draw: "Draw",
	away: "Away"
};
function ConsensusBadge({ c, home, away, signalsUsed = [] }) {
	const who = c.pick === "home" ? home : c.pick === "away" ? away : "Draw";
	const covered = c.code.length === 2 ? ` · cover ${c.code}` : "";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card p-3",
		style: {
			border: `2px solid ${c.color}`,
			background: `${c.color}1A`
		},
		role: "status",
		"aria-label": `Final tip ${c.code === "PASS" ? "pass" : who}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-xs font-semibold uppercase tracking-wide",
				style: { color: c.color },
				children: ["Final tip · ", c.label]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-base font-semibold text-fg",
				children: [c.tier === "PASS" ? "PASS (no safe pick)" : `${who} (${c.code === "PASS" ? "-" : c.pick === "home" ? "1" : c.pick === "draw" ? "X" : "2"})`, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "ml-2 text-sm font-normal text-muted",
					children: [
						Math.round(c.probabilities[c.pick] * 100),
						"% · tier ",
						c.tier,
						covered
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					"Engine said ",
					NAME$1[c.enginePick],
					", AI lab said ",
					NAME$1[c.aiPick],
					"; one reconciled result is shown. Weights",
					" ",
					Math.round(c.weights.engine * 100),
					"/",
					Math.round(c.weights.ai * 100),
					" (engine/AI, last ",
					c.weights.sample,
					" matches).",
					c.cautions.length ? ` Cautions: ${c.cautions.join("; ")}.` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-xs text-muted",
				children: [
					"Pick holds in ",
					Math.round(c.band.stability * 100),
					"% of goal-rate stress runs; range ",
					Math.round(c.band.low * 100),
					"–",
					Math.round(c.band.high * 100),
					"%.",
					signalsUsed.length ? ` Extra signals: ${signalsUsed.join(", ")}.` : " No live data keys configured, stats-only."
				]
			})
		]
	});
}
function PredictionLab({ match, odds }) {
	const consensus = useConsensus(match.id, match.home, match.away, {
		odds,
		league: match.league
	});
	const report = (0, import_react.useMemo)(() => buildAdvancedReport(match.home, match.away), [match.home, match.away]);
	const [sourceCheck, setSourceCheck] = (0, import_react.useState)(null);
	const [sourceLoading, setSourceLoading] = (0, import_react.useState)(false);
	const [sourceError, setSourceError] = (0, import_react.useState)(false);
	const [refreshing, setRefreshing] = (0, import_react.useState)(false);
	const [refreshError, setRefreshError] = (0, import_react.useState)(false);
	const pickName = predictorPickLabel(report.pick, match.home.short, match.away.short);
	const pickProbability = report.ensemble[report.pick];
	const pickRange = report.models.map((model) => model.probabilities[report.pick]);
	const lower = Math.min(...pickRange);
	const upper = Math.max(...pickRange);
	const alignment = report.agreementRate >= .7 ? "Broad alignment" : report.agreementRate >= .5 ? "Mixed" : "Split";
	async function checkPublicSource() {
		if (sourceLoading || sourceCheck) return;
		setSourceLoading(true);
		setSourceError(false);
		try {
			setSourceCheck(await lookupSportPesaReference({ data: match.id }));
		} catch {
			setSourceError(true);
		} finally {
			setSourceLoading(false);
		}
	}
	async function refreshLiveData() {
		if (refreshing) return;
		setRefreshing(true);
		setRefreshError(false);
		try {
			await consensus.refreshSignals();
		} catch {
			setRefreshError(true);
		} finally {
			setRefreshing(false);
		}
	}
	function onLabToggle(event) {
		if (event.currentTarget.open) checkPublicSource();
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsensusBadge, {
			c: consensus,
			home: match.home.short,
			away: match.away.short
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
			className: "rounded-card border border-line bg-raised p-3",
			onToggle: onLabToggle,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
				className: "cursor-pointer list-none text-sm font-medium",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-signal",
						children: "AI-style lab (input to the final tip)"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 text-fg",
						children: [
							pickName,
							" · ",
							pct$1(pickProbability)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "ml-2 text-muted",
						children: [
							report.agreement,
							"/",
							report.models.length,
							" models"
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Ensemble lean",
								value: pickName
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Model probability",
								value: pct$1(pickProbability)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Agreement",
								value: `${report.agreement}/${report.models.length} · ${alignment}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Sample coverage",
								value: `${report.sampleGames} games · ${report.sampleLabel}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "Lead over 2nd result",
								value: pct$1(report.outcomeMargin)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "25 local predictor models"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Twenty-five formula-based predictors are compared. Six additional scenario models broaden the sensitivity checks. Each row shows home / draw / away probabilities. These formulas share inputs and are not independent votes; scenario variants are downweighted so they cannot dominate the ensemble. The result is not a trained or historically calibrated model."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 flex flex-col gap-2",
								children: report.models.map((model) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2 border-t border-line pt-2 first:border-0 first:pt-0",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-fg",
										children: model.name
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs text-muted",
										children: model.method
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "whitespace-nowrap text-right text-xs tabular-nums text-muted",
										children: [
											pct$1(model.probabilities.home),
											" / ",
											pct$1(model.probabilities.draw),
											" /",
											" ",
											pct$1(model.probabilities.away),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "block text-fg",
												children: ["Lean: ", predictorShortLabel(topPick(model.probabilities))]
											})
										]
									})]
								}, model.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "17 additional match tools"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "The top-result margin and recent-form volatility checks are new. Diagnostics are outputs from the same fixture data, not extra independent predictors or betting recommendations."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-3 grid gap-2 sm:grid-cols-2",
								children: report.tools.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-card border border-line bg-raised p-2",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs text-muted",
											children: tool.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-sm font-medium tabular-nums text-fg",
											children: tool.value
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs text-muted",
											children: tool.method
										})
									]
								}, tool.id))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-2 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-card border border-line bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Probability dispersion"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"For ",
									pickName,
									", the ",
									report.models.length,
									" models range from ",
									pct$1(lower),
									" to",
									" ",
									pct$1(upper),
									"(spread ",
									pct$1(report.spread),
									"). This is model disagreement, not a statistical confidence interval."
								]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-card border border-line bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "±10% xG stress test"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: [
									"Lean ",
									report.stressStable ? "stays the same" : "changes",
									" across low-attack, baseline, and high-attack scenarios:",
									" ",
									report.stressPicks.map((pick) => predictorPickLabel(pick, match.home.short, match.away.short)).join(" · "),
									"."
								]
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PublicOddsReference, {
						result: sourceCheck,
						loading: sourceLoading,
						failed: sourceError,
						onCheck: () => void checkPublicSource()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveDataStatus, {
						signal: consensus.providerSignals,
						refreshing,
						failed: refreshError,
						onRefresh: () => void refreshLiveData()
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Risk and data checks"
							}),
							report.riskFlags.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 flex flex-col gap-1 text-sm text-muted",
								children: report.riskFlags.map((flag) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: ["• ", flag] }, flag))
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "No configured sample-size, agreement, spread, draw, or stress-test warning triggered."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "Calibration status: not backtested by predictor. These deterministic algorithms use this app’s fixture stats; they are not separate external AI services, live team-news models, or bookmaker prices. Agreement is not accuracy."
							})
						]
					})
				]
			})]
		})]
	});
}
function LiveDataStatus({ signal, refreshing, failed, onRefresh }) {
	const freshness = signal?.freshness;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Live data and freshness gate"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-xs text-muted",
					children: freshness ? `${freshness.status.toUpperCase()} · ${freshness.action.toUpperCase()} · ${freshness.ageHours === null ? "age unknown" : `${freshness.ageHours.toFixed(1)} h`}` : "Checking configured sources…"
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onRefresh,
					disabled: refreshing,
					className: "h-10 rounded-full border border-line px-3 text-sm disabled:opacity-50",
					children: refreshing ? "Refreshing…" : "Refresh live data / lineups"
				})]
			}),
			freshness?.reasons.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-2 list-disc pl-5 text-xs text-muted",
				children: freshness.reasons.map((reason) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: reason }, reason))
			}) : null,
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-[#EF4444]",
				children: "The refresh failed; the existing forecast and log were not changed."
			}) : null,
			signal?.featureStatus?.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 grid gap-2 sm:grid-cols-2",
				children: signal.featureStatus.map((feature) => {
					const color = feature.status === "ready" ? "#10B981" : feature.status === "stale" ? "#F59E0B" : feature.status === "diagnostic" ? "#06B6D4" : "#EF4444";
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "rounded-card border border-line bg-raised p-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "font-medium",
							style: { color },
							children: [
								feature.id.replaceAll("-", " "),
								" · ",
								feature.status
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: feature.detail
						})]
					}, feature.id);
				})
			}) : null,
			signal?.lineups ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs",
				style: { color: signal.lineups.status === "confirmed" ? "#10B981" : "#F59E0B" },
				children: [
					"Lineups: ",
					signal.lineups.status,
					" · ",
					signal.lineups.homeStarters,
					"/",
					signal.lineups.awayStarters,
					" starters · observed ",
					new Date(signal.lineups.observedAt).toLocaleTimeString(),
					"."
				]
			}) : null,
			signal?.weather ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-[#06B6D4]",
				children: [
					"Weather diagnostic for ",
					new Date(signal.weather.validAt).toLocaleString(),
					": ",
					signal.weather.temperatureC === void 0 ? "temperature n/a" : `${signal.weather.temperatureC}°C`,
					", ",
					signal.weather.precipitationMm === void 0 ? "rain n/a" : `${signal.weather.precipitationMm} mm/h`,
					", ",
					signal.weather.windKmh === void 0 ? "wind n/a" : `${signal.weather.windKmh} km/h`,
					". ",
					signal.weather.diagnostics.join(" "),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://open-meteo.com/",
						target: "_blank",
						rel: "noreferrer",
						className: "underline",
						children: "Weather data by Open-Meteo"
					}),
					"."
				]
			}) : null,
			freshness?.action === "pass" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm font-medium text-[#EF4444]",
				children: "Pass: required current team data could not be verified."
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-[11px] text-muted",
				children: "Late lineups are requested on refresh within 90 minutes of a verified kickoff and saved as a separate observation; the original forecast stays frozen."
			})
		]
	});
}
function topPick(probabilities) {
	if (probabilities.home >= probabilities.draw && probabilities.home >= probabilities.away) return "home";
	if (probabilities.away >= probabilities.draw) return "away";
	return "draw";
}
function PublicOddsReference({ result, loading, failed, onCheck }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Public odds source check"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted",
				children: "SportPesa is checked against a public third-party comparison page only when this lab opens. Its prices may be delayed and are not guaranteed live or official."
			}),
			!result && !loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onCheck,
				className: "mt-2 h-10 rounded-full border border-line px-3 text-sm",
				children: failed ? "Retry public-source check" : "Check public SportPesa reference"
			}) : null,
			loading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "Checking the exact fixture page…"
			}) : null,
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "The public-source check failed; no quote is shown."
			}) : null,
			result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex flex-col gap-2",
				children: [
					result.odds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-3 gap-2 text-center",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "SportPesa reference · 1",
								value: result.odds.home.toFixed(2)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "X",
								value: result.odds.draw.toFixed(2)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Metric, {
								label: "2",
								value: result.odds.away.toFixed(2)
							})
						]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: result.detail
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							result.freshness,
							" Checked ",
							new Date(result.checkedAt).toLocaleTimeString(),
							" local time."
						]
					}),
					result.sourceUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: result.sourceUrl,
						target: "_blank",
						rel: "noreferrer",
						className: "text-sm text-signal underline",
						children: "Verify this fixture at the comparison source"
					}) : null
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 border-t border-line pt-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: "1xBet: no automated quote is shown. Its public page is not reliably readable here, and available bookmaker-specific aggregators prohibit automated reuse unless permission is granted."
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: "https://1xbet.com/en/line/football",
					target: "_blank",
					rel: "noreferrer",
					className: "mt-1 inline-block text-sm text-signal underline",
					children: "Open 1xBet directly"
				})]
			})
		]
	});
}
function Metric({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-raised px-3 py-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm font-medium tabular-nums text-fg",
			children: value
		})]
	});
}
/** Null until mounted so server and first client paint match. */
function useNow(ms = 15e3) {
	const [now, setNow] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		const tick = () => setNow(Date.now());
		tick();
		const id = window.setInterval(tick, ms);
		const wake = () => {
			if (document.visibilityState === "visible") tick();
		};
		document.addEventListener("visibilitychange", wake);
		window.addEventListener("pageshow", tick);
		return () => {
			window.clearInterval(id);
			document.removeEventListener("visibilitychange", wake);
			window.removeEventListener("pageshow", tick);
		};
	}, [ms]);
	return {
		now,
		bucket: now === null ? 0 : Math.floor(now / 3e4)
	};
}
var LEAGUE_ORDER = new Map(LEAGUE_CODES.map((code, index) => [code, index]));
function matchDateKey(match) {
	const kickoff = kickoffMs(match.id);
	return kickoff === null ? null : new Date(kickoff).toISOString().slice(0, 10);
}
function isUpcomingMatch(match, now = Date.now()) {
	const kickoff = kickoffMs(match.id);
	return kickoff !== null && kickoff > now;
}
function focusedMarket(match, focus) {
	if (focus === "btts") return "btts";
	if (focus === "corners") return "corners95";
	if (focus === "cards") return "red";
	if (focus === "goals") return match.model.over25 >= match.model.under25 ? "over25" : "under25";
	if (match.desk && (match.desk.market === "home" || match.desk.market === "draw" || match.desk.market === "away")) return match.desk.market;
	return match.edges.find((edge) => (edge.market === "home" || edge.market === "draw" || edge.market === "away") && edge.odds >= 1.7 && edge.odds <= 3.75)?.market ?? match.likely.market;
}
function passesFilters(match, opts) {
	if (opts.league !== "ALL" && match.code !== opts.league) return false;
	const q = opts.query.trim().toLowerCase();
	if (q) {
		if (!`${match.home.name} ${match.away.name} ${match.league}`.toLowerCase().includes(q)) return false;
	}
	if (opts.watchOnly && !opts.watch.includes(match.id)) return false;
	const market = focusedMarket(match, opts.marketFocus);
	const quote = quoteAt(match, opts.bookId, market);
	if (opts.onlyValue && quote.ev < .02) return false;
	if (opts.minEdge > 0 && quote.edge * 100 < opts.minEdge) return false;
	return true;
}
function sortMatches(rows, sortKey, bookId, focus) {
	const copy = rows.slice();
	copy.sort((a, b) => {
		if (sortKey === "competition") {
			const leagueDifference = (LEAGUE_ORDER.get(a.code) ?? Number.MAX_SAFE_INTEGER) - (LEAGUE_ORDER.get(b.code) ?? Number.MAX_SAFE_INTEGER);
			if (leagueDifference !== 0) return leagueDifference;
			const aKickoff = kickoffMs(a.id) ?? Number.POSITIVE_INFINITY;
			const bKickoff = kickoffMs(b.id) ?? Number.POSITIVE_INFINITY;
			if (aKickoff !== bKickoff) return aKickoff - bKickoff;
			return a.home.name.localeCompare(b.home.name);
		}
		if (sortKey === "kickoff") return (kickoffMs(a.id) ?? 0) - (kickoffMs(b.id) ?? 0);
		if (sortKey === "chance") return b.likely.model - a.likely.model;
		if (sortKey === "xg") return b.lambdaHome + b.lambdaAway - (a.lambdaHome + a.lambdaAway);
		const ea = quoteAt(a, bookId, focusedMarket(a, focus)).ev;
		return quoteAt(b, bookId, focusedMarket(b, focus)).ev - ea;
	});
	return copy;
}
function groupMatchesByCompetition(rows) {
	return LEAGUE_CODES.map((code) => ({
		code,
		rows: rows.filter((match) => match.code === code)
	})).filter((group) => group.rows.length > 0);
}
new Set(MARKET_KEYS);
new Set(BOOKS$1.map((book) => book.id));
function isManualJackpotGame(value) {
	if (!value || typeof value !== "object") return false;
	const row = value;
	const odds = row.odds;
	return typeof row.id === "string" && row.id.length <= 200 && row.id.startsWith("manual-") && (row.book === "betika" || row.book === "sportpesa" || row.book === "xbet" || row.book === "other") && typeof row.bookmaker === "string" && row.bookmaker.trim().length > 0 && row.bookmaker.length <= 40 && typeof row.league === "string" && row.league.length <= 80 && typeof row.when === "string" && row.when.length <= 80 && typeof row.home === "string" && row.home.trim().length > 0 && row.home.length <= 80 && typeof row.away === "string" && row.away.trim().length > 0 && row.away.length <= 80 && typeof row.enteredAt === "string" && Number.isFinite(Date.parse(row.enteredAt)) && !!odds && [
		odds.home,
		odds.draw,
		odds.away
	].every((odd) => typeof odd === "number" && Number.isFinite(odd) && odd > 1.01 && odd <= 100);
}
function trimJackpotPicks(picks) {
	return Object.fromEntries(Object.entries(picks).slice(-200));
}
var useDesk = create((set, get) => ({
	view: "live",
	league: "ALL",
	query: "",
	openId: null,
	previewId: null,
	bankroll: 100,
	legs: [],
	bookId: "betika",
	placeId: "betika",
	showKes: false,
	oddsFormat: "decimal",
	marketFocus: "1x2",
	sortKey: "edge",
	minEdge: 0,
	onlyValue: false,
	onlyDesk: false,
	day: "ALL",
	watchOnly: false,
	watch: [],
	quotes: {},
	jackpotPicks: {},
	manualJackpotGames: [],
	setView: (view) => set({ view }),
	setLeague: (league) => set({ league }),
	setQuery: (query) => set({ query }),
	setOpen: (openId) => set({ openId }),
	setPreview: (previewId) => set({ previewId }),
	setBankroll: (bankroll) => set({ bankroll }),
	setBookId: (bookId) => set({ bookId }),
	setPlaceId: (placeId) => set({ placeId }),
	setShowKes: (showKes) => set({ showKes }),
	setOddsFormat: (oddsFormat) => set({ oddsFormat }),
	setMarketFocus: (marketFocus) => set({ marketFocus }),
	setSortKey: (sortKey) => set({ sortKey }),
	setMinEdge: (minEdge) => set({ minEdge }),
	setOnlyValue: (onlyValue) => set({ onlyValue }),
	setOnlyDesk: (onlyDesk) => set({ onlyDesk }),
	setDay: (day) => set({ day }),
	setWatchOnly: (watchOnly) => set({ watchOnly }),
	toggleWatch: (matchId) => {
		const watch = get().watch;
		set({ watch: watch.includes(matchId) ? watch.filter((id) => id !== matchId) : [...watch, matchId] });
	},
	setQuote: (matchId, market, odds) => {
		const key = `${matchId}:${market}`;
		const quotes = { ...get().quotes };
		if (odds === null || odds < 1.01 || odds > 50) delete quotes[key];
		else quotes[key] = Math.round(odds * 100) / 100;
		set({
			quotes,
			legs: get().legs.map((leg) => leg.matchId === matchId && leg.market === market ? {
				...leg,
				seenOdds: quotes[key]
			} : leg)
		});
	},
	toggleLeg: (matchId, market) => {
		const legs = get().legs;
		if (legs.some((leg) => leg.matchId === matchId && leg.market === market)) {
			set({ legs: legs.filter((leg) => !(leg.matchId === matchId && leg.market === market)) });
			return;
		}
		set({ legs: [...legs, {
			matchId,
			market,
			seenOdds: get().quotes[`${matchId}:${market}`]
		}] });
	},
	setSeenOdds: (matchId, market, odds) => {
		set({ legs: get().legs.map((leg) => leg.matchId === matchId && leg.market === market ? {
			...leg,
			seenOdds: odds ?? void 0
		} : leg) });
	},
	setLegs: (legs) => set({ legs }),
	clearLegs: () => set({ legs: [] }),
	setJackpotPick: (id, pick) => set({ jackpotPicks: trimJackpotPicks({
		...get().jackpotPicks,
		[id]: pick
	}) }),
	setJackpotPicks: (jackpotPicks) => set({ jackpotPicks: trimJackpotPicks(jackpotPicks) }),
	addManualJackpotGame: (game) => {
		if (!isManualJackpotGame(game)) return;
		set({ manualJackpotGames: [...get().manualJackpotGames.filter((item) => item.id !== game.id), game].slice(-24) });
	},
	removeManualJackpotGame: (id) => set({ manualJackpotGames: get().manualJackpotGames.filter((game) => game.id !== id) })
}));
var lookupBoardOdds = createServerFn({ method: "GET" }).validator((matchId) => {
	if (typeof matchId !== "string" || matchId.length > 80 || !/^[a-z0-9-]+$/i.test(matchId)) throw new Error("Invalid fixture ID");
	return matchId;
}).handler(createSsrRpc("7a9401aac1db7813a8f2930461c310f1128eaa5744f89a93e52d1b66cb47dc30"));
var KEY = "consensus-history-v1";
function loadHistory() {
	try {
		const raw = typeof localStorage === "undefined" ? null : localStorage.getItem(KEY);
		return raw ? JSON.parse(raw).slice(-100) : [];
	} catch {
		return [];
	}
}
function MatchCard({ match }) {
	const [oddsSource, setOddsSource] = (0, import_react.useState)("demo");
	const [publicOdds, setPublicOdds] = (0, import_react.useState)(null);
	const [oddsLoading, setOddsLoading] = (0, import_react.useState)(false);
	const [oddsError, setOddsError] = (0, import_react.useState)(false);
	const [manualOddsInput, setManualOddsInput] = (0, import_react.useState)({
		home: "",
		draw: "",
		away: ""
	});
	const bookId = useDesk((s) => s.bookId);
	const oddsFormat = useDesk((s) => s.oddsFormat);
	const marketFocus = useDesk((s) => s.marketFocus);
	const bankroll = useDesk((s) => s.bankroll);
	const watch = useDesk((s) => s.watch);
	const toggleWatch = useDesk((s) => s.toggleWatch);
	const setOpen = useDesk((s) => s.setOpen);
	const setPreview = useDesk((s) => s.setPreview);
	const toggleLeg = useDesk((s) => s.toggleLeg);
	const legs = useDesk((s) => s.legs);
	const setQuote = useDesk((s) => s.setQuote);
	const typed = useDesk((s) => s.quotes[`${match.id}:${focusedMarket(match, marketFocus)}`]);
	const { now, bucket } = useNow();
	async function loadPublicOdds() {
		if (oddsLoading || publicOdds) return;
		setOddsLoading(true);
		setOddsError(false);
		try {
			setPublicOdds(await lookupBoardOdds({ data: match.id }));
		} catch {
			setOddsError(true);
		} finally {
			setOddsLoading(false);
		}
	}
	const market = focusedMarket(match, marketFocus);
	const quote = quoteAt(match, bookId, market);
	const manualValues = {
		home: Number(manualOddsInput.home),
		draw: Number(manualOddsInput.draw),
		away: Number(manualOddsInput.away)
	};
	const manualTriple = Object.values(manualValues).every((value) => Number.isFinite(value) && value > 1.01 && value <= 100) ? manualValues : void 0;
	const liveTriple = oddsSource === "betika" ? publicOdds?.betika.odds : oddsSource === "sportpesa" ? publicOdds?.sportpesa.odds : oddsSource === "manual" ? manualTriple : void 0;
	const liveCurrent = market === "home" || market === "draw" || market === "away" ? liveTriple?.[market] : void 0;
	const currentPrice = oddsSource === "demo" ? now === null ? quote.odds : tapeOdds(quote.odds, `${match.id}:${market}:${bookId}`, bucket) : liveCurrent;
	const isDemo = oddsSource === "demo";
	const shown = (isDemo ? typed ?? currentPrice : currentPrice) ?? NaN;
	const selectedSourceName = oddsSource === "betika" ? "Betika public quote" : oddsSource === "sportpesa" ? "SportPesa comparison snapshot" : oddsSource === "manual" ? `manually entered ${BOOKS$1.find((book) => book.id === bookId)?.name ?? "bookmaker"} price` : "demo estimate";
	const fair = fairOdds$1(match.model[market]);
	const dc = doubleChance(match);
	const kick = kickoffMs(match.id);
	const home = quoteAt(match, bookId, "home");
	const draw = quoteAt(match, bookId, "draw");
	const away = quoteAt(match, bookId, "away");
	const final = buildConsensus(match.home, match.away, {
		odds: {
			home: home.odds,
			draw: draw.odds,
			away: away.odds
		},
		history: loadHistory(),
		league: match.league
	});
	const show1x2 = (pick, n, seed) => {
		const price = oddsSource === "demo" ? now === null ? n : tapeOdds(n, seed, bucket) : liveTriple?.[pick];
		return price ? formatOdds(price, oddsFormat) : "—";
	};
	const edgeForStake = {
		...match.likely,
		market,
		model: match.model[market],
		odds: Number.isFinite(shown) ? shown : 0,
		ev: Number.isFinite(shown) ? match.model[market] * shown - 1 : Number.NEGATIVE_INFINITY,
		edge: quote.edge,
		book: quote.book,
		bookId: quote.bookId
	};
	const stake = isDemo ? suggestedStake(edgeForStake, bankroll) : 0;
	const onSlip = legs.some((leg) => leg.matchId === match.id && leg.market === market);
	const marks = matchMarks(match.lambdaHome, match.lambdaAway);
	const injury = [...match.home.out, ...match.away.out].find((item) => !/no new|no senior|no confirmed/i.test(item));
	const points = (form) => form.reduce((sum, mark) => sum + (mark === "W" ? 3 : mark === "D" ? 1 : 0), 0);
	const cornerOver = (line) => 1 - Array.from({ length: line + 1 }, (_, k) => {
		let p = Math.exp(-match.extras.corners);
		for (let i = 1; i <= k; i++) p *= match.extras.corners / i;
		return p;
	}).reduce((a, b) => a + b, 0);
	const yellowOver = 1 - Array.from({ length: 4 }, (_, k) => {
		let p = Math.exp(-match.extras.yellows);
		for (let i = 1; i <= k; i++) p *= match.extras.yellows / i;
		return p;
	}).reduce((a, b) => a + b, 0);
	const dnb = (side, other) => 1 / Math.max(.05, side / (side + other));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col gap-3 rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					match.code,
					" · ",
					match.dateLabel,
					" · ",
					match.time,
					" UK",
					now !== null && kick !== null ? ` · ${countdown(kick, now)}` : ""
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-label": watch.includes(match.id) ? "Remove from watchlist" : "Add to watchlist",
					onClick: () => toggleWatch(match.id),
					className: "flex size-11 items-center justify-center rounded-full border border-line " + (watch.includes(match.id) ? "text-signal" : "text-muted"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Star, {
						className: "size-4",
						fill: watch.includes(match.id) ? "currentColor" : "none"
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium",
					children: match.home.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPills, { form: match.home.form }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 font-medium",
					children: match.away.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPills, { form: match.away.form }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-sm text-muted",
					children: [
						"Last five count more than the season. ",
						match.home.short,
						" ",
						points(match.home.form),
						" pts,",
						" ",
						match.away.short,
						" ",
						points(match.away.form),
						" pts. Chance gap",
						" ",
						(match.lambdaHome - match.lambdaAway).toFixed(2),
						". ",
						namedOut(match.home),
						" ",
						namedOut(match.away)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-2 rounded-card border border-line bg-bg p-2 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-medium",
							children: "Player availability"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-muted",
							children: [
								namedOut(match.home),
								" ",
								namedOut(match.away)
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: "Injured or missing players are included as a caution signal when listed."
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 rounded-card bg-raised p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Home xG"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tabular-nums",
						children: match.lambdaHome.toFixed(2)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Away xG"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-2xl tabular-nums",
						children: match.lambdaAway.toFixed(2)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "text-right",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Score"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-2xl tabular-nums",
							children: match.score
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SplitBar, { match }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card border-2 border-red-400/70 bg-red-950/30 p-3",
				role: "status",
				"aria-label": "Visible fixture prediction and odds",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wide text-red-300",
							children: "Unified final prediction"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-lg font-semibold",
							children: final.tier === "PASS" ? "PASS · verify data" : `${final.code} · ${selectionName(match, final.pick)}`
						})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-right text-xs text-muted",
							children: [
								Math.round(final.probabilities[final.pick] * 100),
								"% · ",
								final.tier,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								"Scoreline model: ",
								match.score,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
								final.enginePick === final.aiPick ? "Engine + AI aligned" : "Engine / AI split"
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 text-center text-xs",
						children: [
							"home",
							"draw",
							"away"
						].map((pick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => toggleLeg(match.id, pick),
							className: `rounded-card border px-2 py-2 ${final.pick === pick ? "border-red-300 bg-red-500/30 text-red-100" : "border-line bg-bg text-muted"}`,
							"aria-pressed": onSlip && final.pick === pick,
							children: [
								pick === "home" ? "1" : pick === "draw" ? "X" : "2",
								" · ",
								pick === "home" ? match.home.short : pick === "away" ? match.away.short : "Draw",
								final.pick === pick ? " · FINAL" : ""
							]
						}, pick))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[11px] text-red-100/80",
						children: "Select the highlighted FINAL outcome to add it to your slip. PASS means the system does not recommend a single result."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-3 gap-2 text-center text-xs",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-card border border-line px-2 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: ["1 · ", match.home.short]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-base font-semibold tabular-nums",
									children: show1x2("home", home.odds, `${match.id}:home:${bookId}`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-card border border-line px-2 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-muted",
									children: "X · Draw"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-base font-semibold tabular-nums",
									children: show1x2("draw", draw.odds, `${match.id}:draw:${bookId}`)
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "rounded-card border border-line px-2 py-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-muted",
									children: ["2 · ", match.away.short]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-base font-semibold tabular-nums",
									children: show1x2("away", away.odds, `${match.id}:away:${bookId}`)
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-[11px] text-muted",
						children: [
							"Odds shown from ",
							BOOKS$1.find((book) => book.id === bookId)?.name ?? "selected bookmaker",
							" · open the odds panel to check exact public quotes."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictionLab, { match }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "max-w-full min-w-0 rounded-card border border-line bg-raised p-3",
				onToggle: (event) => {
					if (event.currentTarget.open && oddsSource !== "manual") loadPublicOdds();
				},
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("summary", {
					className: "cursor-pointer list-none text-sm font-medium",
					children: [
						"Choose or compare odds sources ·",
						" ",
						isDemo ? "Demo estimate" : oddsSource === "betika" ? "Betika" : "SportPesa reference"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-3 flex min-w-0 max-w-full flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Choose the line shown above for this match. Public lookups run only when requested. If a source has no exact current quote, its prices stay blank; demo lines are clearly separate estimates."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-muted",
							children: ["Use odds from", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: oddsSource,
								onChange: (event) => {
									const next = event.target.value;
									setOddsSource(next);
									if (next === "betika" || next === "sportpesa") loadPublicOdds();
								},
								className: "mt-1 h-11 w-full rounded-card border border-line bg-surface px-3 text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "demo",
										children: "Demo estimate · generated by this app"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "betika",
										children: "Betika · public 1X2 quote if exact match found"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "sportpesa",
										children: "SportPesa · third-party reference snapshot"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "manual",
										children: "Manual · enter any bookmaker’s 1X2 prices"
									})
								]
							})]
						}),
						oddsSource === "manual" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("fieldset", {
							className: "rounded-card border border-line bg-surface p-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("legend", {
									className: "px-1 text-sm text-muted",
									children: [BOOKS$1.find((book) => book.id === bookId)?.name ?? "Selected bookmaker", " decimal odds"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "grid grid-cols-3 gap-2",
									children: [
										"home",
										"draw",
										"away"
									].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
										className: "text-xs text-muted",
										children: [side === "home" ? "1 · Home" : side === "draw" ? "X · Draw" : "2 · Away", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
											inputMode: "decimal",
											value: manualOddsInput[side],
											onChange: (event) => setManualOddsInput((current) => ({
												...current,
												[side]: event.target.value
											})),
											placeholder: "e.g. 2.10",
											className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-2 text-fg"
										})]
									}, side))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-muted",
									children: "Enter all three prices. These are your manually read quotes, not fetched or independently verified."
								})
							]
						}) : null,
						oddsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Checking public odds sources…"
						}) : null,
						oddsError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "The check failed. No old or demo price is substituted for the selected source."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "max-w-full min-w-0 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-0 table-fixed border-collapse text-left text-xs sm:text-sm",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-b border-line text-xs text-muted",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 pr-2 font-normal",
											children: "Source"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 text-center font-normal",
											children: "1"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 text-center font-normal",
											children: "X"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "px-2 py-2 text-center font-normal",
											children: "2"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "py-2 pl-2 font-normal",
											children: "Action"
										})
									]
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OddsComparisonRow, {
										name: `${quote.book} demo estimate`,
										odds: {
											home: home.odds,
											draw: draw.odds,
											away: away.odds
										},
										active: oddsSource === "demo",
										onUse: () => setOddsSource("demo")
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OddsComparisonRow, {
										name: "Betika public feed",
										odds: publicOdds?.betika.odds,
										active: oddsSource === "betika",
										onUse: () => {
											setOddsSource("betika");
											loadPublicOdds();
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OddsComparisonRow, {
										name: "SportPesa comparison reference",
										odds: publicOdds?.sportpesa.odds,
										active: oddsSource === "sportpesa",
										onUse: () => {
											setOddsSource("sportpesa");
											loadPublicOdds();
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OddsComparisonRow, {
										name: `Manual · ${BOOKS$1.find((book) => book.id === bookId)?.name ?? "bookmaker"}`,
										odds: manualTriple,
										active: oddsSource === "manual",
										onUse: () => setOddsSource("manual")
									})
								] })]
							})
						}),
						publicOdds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Betika: ",
									publicOdds.betika.detail,
									" ",
									publicOdds.betika.freshness
								] }),
								publicOdds.betika.odds ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: publicOdds.betika.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "text-signal underline",
									children: "Verify at Betika"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"SportPesa: ",
									publicOdds.sportpesa.detail,
									" ",
									publicOdds.sportpesa.freshness
								] }),
								publicOdds.sportpesa.sourceUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: publicOdds.sportpesa.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "text-signal underline",
									children: "Verify comparison page"
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: ["1xBet: ", publicOdds.xbet.detail] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: publicOdds.xbet.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "text-signal underline",
									children: "Open 1xBet directly"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Other global odds feeds offer wider book coverage, but the checked service requires an API key. It is not configured because you asked for a no-key setup." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
									"Checked ",
									new Date(publicOdds.checkedAt).toLocaleTimeString(),
									" local time. Third-party comparison odds may be delayed or inaccurate."
								] })
							]
						}) : !oddsLoading ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Betika and SportPesa have not been checked for this fixture yet. Expanding this panel or choosing either source starts one exact-fixture check."
						}) : null
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: isDemo ? typed ? `${quote.book} price you entered manually` : `${quote.book} demo estimate, not the live ${quote.book} board` : oddsSource === "betika" ? `Betika public feed${liveTriple ? " · exact fixture quote" : " · no exact quote available"}` : oddsSource === "sportpesa" ? `SportPesa comparison snapshot${liveTriple ? " · reference quote" : " · no exact quote available"}` : `Manually entered ${BOOKS$1.find((book) => book.id === bookId)?.name ?? "bookmaker"}${liveTriple ? " · complete 1X2 set" : " · enter all three prices"}`
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-3 gap-2 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceCell, {
						label: "1",
						price: show1x2("home", home.odds, `${match.id}:home:${bookId}`),
						hot: market === "home"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceCell, {
						label: "X",
						price: show1x2("draw", draw.odds, `${match.id}:draw:${bookId}`),
						hot: market === "draw"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PriceCell, {
						label: "2",
						price: show1x2("away", away.odds, `${match.id}:away:${bookId}`),
						hot: market === "away"
					})
				]
			})] }),
			isDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "text-sm text-muted",
				children: [
					"Manually override the ",
					quote.book,
					" demo price for this pick",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						inputMode: "decimal",
						placeholder: "The number in the app",
						value: typed ?? "",
						onChange: (event) => {
							const next = Number(event.target.value);
							setQuote(match.id, market, event.target.value.trim() === "" || !Number.isFinite(next) ? null : next);
						},
						className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
					})
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-fg",
				children: !Number.isFinite(shown) ? `No ${selectedSourceName} price for this market. Verify at the source or switch sources.` : isDemo ? match.likely.odds < 1.7 ? `Likely side is ${formatOdds(match.likely.odds, oddsFormat)} — too short. Not the bet.` : `${selectionName(match, market)} · model ${pct$1(match.model[market])} · ${formatOdds(shown, oddsFormat)}` : `${selectionName(match, market)} · selected ${selectedSourceName} ${formatOdds(shown, oddsFormat)} · model comparison is illustrative only`
			}),
			isDemo && match.desk ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-signal",
				children: [
					"Bet ",
					selectionName(match, match.desk.market),
					" at ",
					formatOdds(match.desk.odds, oddsFormat),
					". Longer than the short favourite. Illustrative demo only."
				]
			}) : !isDemo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "The demo pick is hidden while a public source is selected; no calibrated recommendation is available."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "No price in the 1.70–3.75 band clears the filter. Pass."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums text-muted",
				children: [Number.isFinite(shown) ? `Model fair ${formatOdds(fair, oddsFormat)} · ${isDemo ? `${signedEv(match.model[market] * shown - 1)} · ${riskBand(shown)} demo price` : "not a calibrated edge; verify price directly"}` : "Price-derived metrics are unavailable until this source returns a quote.", isDemo && match.best[market].bookId !== bookId ? ` · best demo estimate elsewhere ${formatOdds(match.best[market].odds, oddsFormat)} ${match.best[market].book}` : ""]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Double chance ",
					dc.label,
					" ",
					pct$1(dc.probability),
					" · fair ",
					formatOdds(dc.fair, oddsFormat),
					isDemo && stake > 0 ? ` · illustrative demo stake ${units(stake)}u` : isDemo ? " · no stake" : " · no stake recommendation for public or manual source"
				]
			}),
			injury ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: ["Absence: ", injury]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-fg",
						children: "Goals, corners and cards"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted",
						children: [
							"About ",
							match.extras.corners.toFixed(1),
							" corners, more for",
							" ",
							match.extras.homeCorners >= match.extras.corners / 2 ? match.home.short : match.away.short,
							". About ",
							match.extras.yellows.toFixed(1),
							" yellow cards. These are desk estimates, not the 1xBet board."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-2 flex flex-col gap-2",
						children: PROP_MARKETS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								selectionName(match, key),
								" · ",
								pct$1(match.model[key]),
								" · fair",
								" ",
								formatOdds(fairOdds$1(match.model[key]), oddsFormat)
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleLeg(match.id, key),
								className: "h-9 shrink-0 rounded-full border border-line px-3",
								children: legs.some((leg) => leg.matchId === match.id && leg.market === key) ? "On slip" : "Add"
							})]
						}, key))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-muted",
						children: [
							"Win to nil ",
							match.home.short,
							" ",
							pct$1(marks.homeNil),
							", ",
							match.away.short,
							" ",
							pct$1(marks.awayNil),
							". Clean sheet ",
							pct$1(marks.homeClean),
							" / ",
							pct$1(marks.awayClean),
							". First goal ",
							match.home.short,
							" ",
							pct$1(marks.firstHome),
							". Draw no bet fair",
							" ",
							formatOdds(dnb(match.model.home, match.model.away), oddsFormat),
							" /",
							" ",
							formatOdds(dnb(match.model.away, match.model.home), oddsFormat),
							". Corners over 8.5",
							" ",
							pct$1(cornerOver(8)),
							", over 10.5 ",
							pct$1(cornerOver(10)),
							". Yellows over 3.5 ",
							pct$1(yellowOver),
							". Both teams and over 2.5 ",
							pct$1(marks.bothAndOver),
							". Top score ",
							match.score,
							"."
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPreview(match.id),
						className: "h-11 flex-1 rounded-full border border-line text-sm",
						children: "Preview"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOpen(match.id),
						className: "h-11 flex-1 rounded-full border border-line text-sm",
						children: "Sheet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => toggleLeg(match.id, market),
						className: "h-11 flex-1 rounded-full bg-signal text-sm font-medium text-ink",
						children: onSlip ? "On slip" : "Add pick"
					})
				]
			})
		]
	});
}
var PROP_MARKETS = [
	"over15",
	"over25",
	"over35",
	"btts",
	"corners95",
	"red"
];
function namedOut(side) {
	const names = side.out.filter((name) => !/no new|no senior|no confirmed/i.test(name));
	if (names.length === 0) return `${side.short} has no listed absence.`;
	return `${side.short} missing ${names.length}: ${names[0]}.`;
}
function PriceCell({ label, price, hot }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card px-2 py-2 " + (hot ? "bg-signal text-ink" : "bg-bg text-fg"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-xl tabular-nums",
			children: price
		})]
	});
}
function OddsComparisonRow({ name, odds, active, onUse }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-b border-line last:border-0",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				className: "py-2 pr-2 text-left text-xs font-normal text-fg",
				children: name
			}),
			[
				"home",
				"draw",
				"away"
			].map((side) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "px-2 py-2 text-center font-mono tabular-nums text-fg",
				children: odds ? odds[side].toFixed(2) : "—"
			}, side)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-2 pl-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: onUse,
					disabled: !odds && name !== "demo",
					className: "h-9 rounded-full border border-line px-3 text-xs disabled:opacity-40",
					children: active ? "Selected" : odds || name.includes("demo") ? "Use" : "Unavailable"
				})
			})
		]
	});
}
var getExpandedFixtures = createServerFn({ method: "GET" }).handler(createSsrRpc("56e124ef1242433c6b034641a2a420b6f8f976c8dfbf08293010f317e38ce3c6"));
var XBET_URL = "https://1xbet.com/en/line/football";
var PAGE_SIZE = 24;
function normalizedTeam(value) {
	return value.toLowerCase().replace(/\b(fc|afc|cf|sc|the)\b/g, "").replace(/[^a-z0-9]/g, "");
}
function fixtureModel(home, away) {
	const normalize = normalizedTeam;
	return MATCHES.find((match) => {
		const homeName = normalize(match.home.name);
		const awayName = normalize(match.away.name);
		const wantedHome = normalize(home);
		const wantedAway = normalize(away);
		return (homeName === wantedHome || homeName.includes(wantedHome) || wantedHome.includes(homeName)) && (awayName === wantedAway || awayName.includes(wantedAway) || wantedAway.includes(awayName));
	});
}
function limitedSide(name) {
	return {
		name,
		short: name,
		pos: 10,
		form: [],
		xgFor: 1.35,
		xgAgainst: 1.35,
		gf: 0,
		ga: 0,
		played: 0,
		out: []
	};
}
function fairOdds(report) {
	return {
		home: (1 / Math.max(report.ensemble.home, .01)).toFixed(2),
		draw: (1 / Math.max(report.ensemble.draw, .01)).toFixed(2),
		away: (1 / Math.max(report.ensemble.away, .01)).toFixed(2)
	};
}
function ExpandedFixtureOdds({ matchId }) {
	const [quote, setQuote] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [failed, setFailed] = (0, import_react.useState)(false);
	async function checkOdds() {
		if (loading || quote) return;
		setLoading(true);
		setFailed(false);
		try {
			setQuote(await lookupBoardOdds({ data: matchId }));
		} catch {
			setFailed(true);
		} finally {
			setLoading(false);
		}
	}
	const available = quote?.betika.odds ?? quote?.sportpesa.odds;
	const source = quote?.betika.odds ? "Betika" : quote?.sportpesa.odds ? "SportPesa reference" : null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-3 border-t border-line pt-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium text-fg",
					children: "Verified 1X2 odds check"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void checkOdds(),
					disabled: loading || !!quote,
					className: "min-h-9 rounded-full border border-line px-3 text-xs disabled:opacity-60",
					children: loading ? "Checking odds…" : quote ? "Odds checked" : "Check available odds"
				})]
			}),
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "Odds check failed. No estimated or demo prices are substituted."
			}) : null,
			quote ? available ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 grid grid-cols-3 gap-2 text-center text-xs",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded bg-raised p-2",
						children: ["1 · ", available.home.toFixed(2)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded bg-raised p-2",
						children: ["X · ", available.draw.toFixed(2)]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded bg-raised p-2",
						children: ["2 · ", available.away.toFixed(2)]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-[11px] text-muted",
				children: [
					source,
					" · ",
					quote.betika.odds ? quote.betika.freshness : quote.sportpesa.freshness,
					". Verify with bookmaker before use."
				]
			})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted",
				children: [
					"No exact current 1X2 quote was returned. ",
					quote.betika.detail,
					" ",
					quote.sportpesa.detail
				]
			}) : null
		]
	});
}
function ExpandedFixtures() {
	const league = useDesk((state) => state.league);
	const sortKey = useDesk((state) => state.sortKey);
	const setLeague = useDesk((state) => state.setLeague);
	const query = useDesk((state) => state.query);
	const [feed, setFeed] = (0, import_react.useState)(null);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const [error, setError] = (0, import_react.useState)(false);
	const [visible, setVisible] = (0, import_react.useState)(PAGE_SIZE);
	const [selectedDate, setSelectedDate] = (0, import_react.useState)("ALL");
	const [selectedMonth, setSelectedMonth] = (0, import_react.useState)("ALL");
	const active = league === "ALL" ? "ALL" : league;
	const selectedCompetition = feed?.competitions.find((item) => item.code === active);
	const rows = (feed?.fixtures ?? []).filter((fixture) => {
		if (active !== "ALL" && fixture.code !== active) return false;
		if (selectedDate !== "ALL" && fixture.date !== selectedDate) return false;
		if (selectedMonth !== "ALL" && !fixture.date.startsWith(selectedMonth)) return false;
		if (!query.trim()) return true;
		return `${fixture.home} ${fixture.away} ${fixture.competition} ${fixture.code}`.toLowerCase().includes(query.trim().toLowerCase());
	}).sort((a, b) => {
		if (sortKey === "competition") {
			const indexA = LEAGUE_CODES.indexOf(a.code);
			const indexB = LEAGUE_CODES.indexOf(b.code);
			if (indexA !== indexB) return indexA - indexB;
		}
		return a.date.localeCompare(b.date) || a.competition.localeCompare(b.competition) || a.home.localeCompare(b.home);
	});
	async function loadFixtures() {
		if (loading || feed) return;
		setLoading(true);
		setError(false);
		try {
			setFeed(await getExpandedFixtures());
		} catch {
			setError(true);
		} finally {
			setLoading(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "overflow-hidden rounded-card border border-line bg-surface",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "border-b border-line bg-raised p-4 sm:p-5",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "max-w-2xl",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs font-semibold uppercase tracking-[0.12em] text-signal",
								children: "Expanded schedule · eight supported competitions"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl",
								children: "Additional league fixtures"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: "Load fixtures from public-domain schedules for the next 30 days. The added list covers England’s top two divisions plus the top divisions in Germany, Spain, France, Italy, the Netherlands, and Portugal. Matched fixtures now show the local model analysis and recent form, with bookmaker links for checking current odds. Unmatched fixtures are clearly marked when reliable team data is not available."
							})
						]
					}), feed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full border border-line bg-surface px-3 py-2 text-sm tabular-nums text-fg",
						children: [feed.fixtures.length, " additional"]
					}) : null]
				}),
				!feed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => void loadFixtures(),
					disabled: loading,
					className: "mt-4 h-11 rounded-full bg-signal px-5 text-sm font-semibold text-ink disabled:opacity-60",
					children: loading ? "Loading published fixtures…" : "Load additional fixtures"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex flex-col gap-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted",
							children: [
								feed.fixtures.length + 152,
								" fixture entries available in this window: 152 bundled cards plus ",
								feed.fixtures.length,
								" deduplicated schedule entries across",
								" ",
								feed.competitions.filter((item) => item.count > 0).length,
								" supported competitions,",
								" ",
								feed.from,
								"–",
								feed.through,
								". Extra cards load 24 at a time. Dates only; kickoff times are not supplied."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							"aria-label": "Expanded fixture date selector",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-xs font-medium text-fg",
									children: "Browse schedule:"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSelectedDate("ALL");
										setSelectedMonth("ALL");
										setVisible(PAGE_SIZE);
									},
									className: "h-9 rounded-full border border-line px-3 text-xs",
									children: "All upcoming"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => {
										setSelectedDate((/* @__PURE__ */ new Date()).toISOString().slice(0, 10));
										setSelectedMonth("ALL");
										setVisible(PAGE_SIZE);
									},
									className: "h-9 rounded-full border border-line px-3 text-xs",
									children: "Today"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex h-9 items-center gap-2 rounded-full border border-line px-3 text-xs text-muted",
									children: ["Date ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "date",
										value: selectedDate === "ALL" ? "" : selectedDate,
										min: feed.from,
										max: feed.through,
										onChange: (event) => {
											setSelectedDate(event.target.value || "ALL");
											setSelectedMonth("ALL");
											setVisible(PAGE_SIZE);
										},
										className: "bg-transparent text-fg outline-none"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex h-9 items-center gap-2 rounded-full border border-line px-3 text-xs text-muted",
									children: ["Month ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "month",
										value: selectedMonth === "ALL" ? "" : selectedMonth,
										onChange: (event) => {
											setSelectedMonth(event.target.value || "ALL");
											setSelectedDate("ALL");
											setVisible(PAGE_SIZE);
										},
										className: "bg-transparent text-fg outline-none"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex gap-2 overflow-x-auto pb-1",
							"aria-label": "Expanded fixture competitions",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": active === "ALL",
								onClick: () => {
									setLeague("ALL");
									setVisible(PAGE_SIZE);
								},
								className: "h-10 shrink-0 rounded-full px-4 text-sm font-medium " + (active === "ALL" ? "bg-signal text-ink" : "border border-line text-fg"),
								children: ["All expanded · ", feed.fixtures.length]
							}), feed.competitions.filter((item) => item.count > 0).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								"aria-pressed": active === item.code,
								onClick: () => {
									setLeague(item.code);
									setVisible(PAGE_SIZE);
								},
								className: "h-10 shrink-0 rounded-full px-4 text-sm font-medium " + (active === item.code ? "bg-signal text-ink" : "border border-line text-fg"),
								children: [
									item.label,
									" · ",
									item.count
								]
							}, item.code))]
						})
					]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					role: "status",
					className: "mt-3 text-sm text-muted",
					children: "The public schedule source could not be reached. The 152 bundled fixtures remain available."
				}) : null,
				feed?.unavailable.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					role: "status",
					className: "mt-3 text-xs text-muted",
					children: ["Some competition schedules did not load: ", feed.unavailable.join(" · ")]
				}) : null
			]
		}), feed ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "p-4 sm:p-5",
			children: [
				rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "rounded-card border border-line p-4 text-sm text-muted",
					children: selectedCompetition ? `No additional ${selectedCompetition.label} fixtures matched the current search in this 30-day window.` : "No expanded-source schedule is mapped to the selected competition. The bundled match cards are still shown above."
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
					children: rows.slice(0, visible).map((fixture) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
						className: "flex min-w-0 flex-col gap-3 rounded-card border border-line bg-raised p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "max-w-[70%] truncate rounded-full border border-line px-3 py-1 text-xs font-medium text-signal",
									children: fixture.competition
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("time", {
									className: "shrink-0 text-xs tabular-nums text-muted",
									dateTime: fixture.date,
									children: (/* @__PURE__ */ new Date(`${fixture.date}T12:00:00Z`)).toLocaleDateString(void 0, {
										day: "numeric",
										month: "short",
										timeZone: "UTC"
									})
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-[1fr_auto_1fr] items-center gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "break-words font-semibold leading-snug text-fg",
										children: fixture.home
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "rounded-full bg-surface px-2 py-1 text-xs text-muted",
										children: "vs"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "break-words text-right font-semibold leading-snug text-fg",
										children: fixture.away
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2 text-xs text-muted",
								children: [fixture.round ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fixture.round }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Kickoff time unavailable · today’s game may have started" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-auto flex flex-wrap gap-2 border-t border-line pt-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: fixture.sourceUrl,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex min-h-10 items-center rounded-full border border-line px-3 text-xs text-fg",
									children: "Fixture source"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: XBET_URL,
									target: "_blank",
									rel: "noreferrer",
									className: "inline-flex min-h-10 items-center rounded-full bg-signal px-3 text-xs font-medium text-ink",
									children: "Check 1xBet Global"
								})]
							}),
							(() => {
								const modeled = fixtureModel(fixture.home, fixture.away);
								const report = buildAdvancedReport(modeled?.home ?? limitedSide(fixture.home), modeled?.away ?? limitedSide(fixture.away));
								const odds = fairOdds(report);
								const limited = !modeled;
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: `rounded-card border p-3 ${limited ? "border-amber-400/60 bg-amber-950/20" : "border-line bg-surface"}`,
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-xs font-semibold uppercase tracking-wide text-signal",
											children: "Fixture analysis · 25-model ensemble"
										}),
										limited ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-xs text-amber-100",
											children: "Limited-data proxy: no exact bundled team record matched this schedule row."
										}) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-sm font-medium text-fg",
											children: [
												"Lean: ",
												predictorPickLabel(report.pick, fixture.home, fixture.away),
												" · ",
												Math.round(report.ensemble[report.pick] * 100),
												"%"
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-muted",
											children: [
												"Home / draw / away: ",
												Math.round(report.ensemble.home * 100),
												"% / ",
												Math.round(report.ensemble.draw * 100),
												"% / ",
												Math.round(report.ensemble.away * 100),
												"% · ",
												report.agreement,
												"/",
												report.models.length,
												" formulas agree."
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-xs text-muted",
											children: ["Recent form: ", modeled ? `${fixture.home} ${modeled.home.form.join(" · ")} · ${fixture.away} ${modeled.away.form.join(" · ")}` : "Unavailable from the bundled team record; verify current form before using this row."]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 grid grid-cols-3 gap-2 text-center text-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "rounded bg-raised p-2",
													children: ["1 · ", odds.home]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "rounded bg-raised p-2",
													children: ["X · ", odds.draw]
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
													className: "rounded bg-raised p-2",
													children: ["2 · ", odds.away]
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-[11px] text-muted",
											children: ["Model-fair odds only · not bookmaker odds. ", modeled ? "Check the exact fixture source below for live prices." : "Limited-data proxy; do not treat as a verified market quote."]
										}),
										modeled ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpandedFixtureOdds, { matchId: modeled.id }) : null,
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-2 flex flex-wrap gap-3 text-xs",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "https://www.betika.com/en-ke/",
													target: "_blank",
													rel: "noreferrer",
													className: "text-signal underline",
													children: "Open Betika"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: "https://www.ke.sportpesa.com/",
													target: "_blank",
													rel: "noreferrer",
													className: "text-signal underline",
													children: "Open SportPesa"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													href: XBET_URL,
													target: "_blank",
													rel: "noreferrer",
													className: "text-signal underline",
													children: "Open 1xBet"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-[11px] text-muted",
											children: "Model probabilities are estimates, not guaranteed accuracy. Verified bookmaker odds remain separate from model-fair odds."
										})
									]
								});
							})()
						]
					}, fixture.id))
				}), rows.length > visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setVisible((current) => current + PAGE_SIZE),
					className: "mt-4 h-11 w-full rounded-full border border-line text-sm font-medium text-fg",
					children: [
						"Show ",
						Math.min(PAGE_SIZE, rows.length - visible),
						" more · ",
						rows.length - visible,
						" ",
						"remaining"
					]
				}) : null] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-4 text-xs text-muted",
					children: "OpenFootball describes its football.json match schedules as public-domain data. Source files update via the project’s repository; upstream changes are not guaranteed to track bookmaker lineups or the latest postponements. Check kickoff and availability at the original competition or a bookmaker."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
					href: feed.source,
					target: "_blank",
					rel: "noreferrer",
					className: "mt-2 inline-block text-xs text-signal underline",
					children: "OpenFootball source and license"
				})
			]
		}) : null]
	});
}
function Board() {
	const [selectedDate, setSelectedDate] = (0, import_react.useState)("ALL");
	const league = useDesk((s) => s.league);
	const query = useDesk((s) => s.query);
	const bookId = useDesk((s) => s.bookId);
	const marketFocus = useDesk((s) => s.marketFocus);
	const sortKey = useDesk((s) => s.sortKey);
	const minEdge = useDesk((s) => s.minEdge);
	const onlyValue = useDesk((s) => s.onlyValue);
	const watch = useDesk((s) => s.watch);
	const watchOnly = useDesk((s) => s.watchOnly);
	const onlyDesk = useDesk((s) => s.onlyDesk);
	const day = useDesk((s) => s.day);
	const rows = sortMatches(MATCHES.filter((match) => {
		if (day !== "ALL" && match.day !== day) return false;
		if (!isUpcomingMatch(match)) return false;
		if (selectedDate !== "ALL" && matchDateKey(match) !== selectedDate) return false;
		if (onlyDesk && !match.desk) return false;
		return passesFilters(match, {
			league,
			query,
			bookId,
			marketFocus,
			minEdge,
			onlyValue,
			watchOnly,
			watch
		});
	}), sortKey, bookId, marketFocus);
	const competitionCount = new Set(MATCHES.map((match) => match.code)).size;
	const days = [
		"Midweek",
		"Saturday",
		"Sunday"
	];
	const availableDates = (0, import_react.useMemo)(() => Array.from(new Set(MATCHES.filter((match) => isUpcomingMatch(match)).map(matchDateKey).filter((date) => Boolean(date)))).sort(), []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Upcoming games"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-2xl text-pretty text-muted",
				children: [
					rows.length,
					" of ",
					MATCHES.length,
					" bundled fixture cards in this view across",
					" ",
					competitionCount,
					" competitions. ",
					MATCHES.filter((match) => match.desk).length,
					" have an illustrative demo price in the 1.70–3.75 band. The expanded schedule above can add more date-only fixtures; neither source is a complete 1xBet event feed."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DatePicker, {
				selectedDate,
				setSelectedDate,
				availableDates
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpandedFixtures, {}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-card border border-line bg-surface px-4 py-8 text-center text-muted",
				children: "No upcoming game matches those filters."
			}) : sortKey === "competition" ? groupMatchesByCompetition(rows).map(({ code, rows: group }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl",
					children: [
						LEAGUES.find((item) => item.code === code)?.label ?? code,
						" · ",
						group.length,
						" games"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: group.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
				})]
			}, code)) : sortKey === "kickoff" ? days.map((day) => {
				const group = rows.filter((match) => match.day === day);
				if (group.length === 0) return null;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "flex flex-col gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: day
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-3 md:grid-cols-2",
						children: group.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
					})]
				}, day);
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: rows.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
			})
		]
	});
}
function DatePicker({ selectedDate, setSelectedDate, availableDates }) {
	const today = (/* @__PURE__ */ new Date()).toISOString().slice(0, 10);
	const tomorrow = new Date(Date.now() + 864e5).toISOString().slice(0, 10);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-4",
		"aria-label": "Choose fixture date",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mr-2 text-sm font-medium",
					children: "Browse games by date"
				}),
				[
					["ALL", "All upcoming"],
					[today, "Today"],
					[tomorrow, "Tomorrow"]
				].map(([value, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setSelectedDate(value),
					className: `h-10 rounded-full px-3 text-xs ${selectedDate === value ? "bg-signal text-ink" : "border border-line text-fg"}`,
					children: label
				}, value)),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex h-10 items-center gap-2 rounded-full border border-line px-3 text-xs text-muted",
					children: ["Specific date", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						type: "date",
						value: selectedDate === "ALL" ? "" : selectedDate,
						min: today,
						onChange: (event) => setSelectedDate(event.target.value || "ALL"),
						className: "bg-transparent text-fg outline-none"
					})]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-xs text-muted",
			children: availableDates.length ? `${availableDates.length} future dates are available in the bundled catalogue.` : "No future bundled cards remain; use the live expanded schedule below to load current fixtures."
		})]
	});
}
var CHIP = "h-11 shrink-0 rounded-full px-4 text-sm font-medium";
function Controls() {
	const league = useDesk((s) => s.league);
	const setLeague = useDesk((s) => s.setLeague);
	const query = useDesk((s) => s.query);
	const setQuery = useDesk((s) => s.setQuery);
	const bookId = useDesk((s) => s.bookId);
	const setBookId = useDesk((s) => s.setBookId);
	const oddsFormat = useDesk((s) => s.oddsFormat);
	const setOddsFormat = useDesk((s) => s.setOddsFormat);
	const marketFocus = useDesk((s) => s.marketFocus);
	const setMarketFocus = useDesk((s) => s.setMarketFocus);
	const sortKey = useDesk((s) => s.sortKey);
	const setSortKey = useDesk((s) => s.setSortKey);
	const minEdge = useDesk((s) => s.minEdge);
	const setMinEdge = useDesk((s) => s.setMinEdge);
	const onlyValue = useDesk((s) => s.onlyValue);
	const setOnlyValue = useDesk((s) => s.setOnlyValue);
	const onlyDesk = useDesk((s) => s.onlyDesk);
	const setOnlyDesk = useDesk((s) => s.setOnlyDesk);
	const day = useDesk((s) => s.day);
	const setDay = useDesk((s) => s.setDay);
	const watchOnly = useDesk((s) => s.watchOnly);
	const setWatchOnly = useDesk((s) => s.setWatchOnly);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-3 rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 md:flex-row md:items-end",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "flex flex-1 flex-col gap-1 text-sm text-muted",
					children: ["Betting site", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
						value: bookId,
						onChange: (event) => setBookId(event.target.value),
						className: "h-11 rounded-card border border-line bg-raised px-3 text-fg",
						children: [
							"Sharp",
							"Kenya",
							"International"
						].map((region) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
							label: region,
							children: BOOKS$1.filter((book) => book.region === region).map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
								value: book.id,
								children: [book.name, book.sharp ? " · sharp" : ""]
							}, book.id))
						}, region))
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "relative block flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "sr-only",
							children: "Search teams"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute top-3 left-3 size-5 text-muted" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: query,
							onChange: (event) => setQuery(event.target.value),
							placeholder: "Search a club",
							className: "h-11 w-full rounded-card border border-line bg-raised pr-3 pl-11 text-fg outline-none placeholder:text-muted focus:border-signal"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex gap-2 overflow-x-auto",
				role: "tablist",
				"aria-label": "Competition",
				children: LEAGUES.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					"aria-selected": league === item.code,
					onClick: () => setLeague(item.code),
					className: CHIP + (league === item.code ? " bg-signal text-ink" : " border border-line text-fg"),
					children: item.code === "ALL" ? `All ${MATCHES.length}` : `${item.label} ${MATCHES.filter((match) => match.code === item.code).length}`
				}, item.code))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
						label: "Prices",
						value: oddsFormat,
						options: [
							["decimal", "Decimal"],
							["fractional", "Fractional"],
							["american", "American"]
						],
						onChange: setOddsFormat
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
						label: "Market",
						value: marketFocus,
						options: [
							["1x2", "Result"],
							["goals", "Goals"],
							["btts", "BTTS"],
							["corners", "Corners"],
							["cards", "Cards"]
						],
						onChange: setMarketFocus
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
						label: "Sort",
						value: sortKey,
						options: [
							["edge", "Edge"],
							["kickoff", "Kickoff"],
							["competition", "Competition → kickoff"],
							["chance", "Chance"],
							["xg", "xG"]
						],
						onChange: setSortKey
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
						label: "Min edge",
						value: String(minEdge),
						options: [
							["0", "Any"],
							["2", "2 pts"],
							["4", "4 pts"]
						],
						onChange: (value) => setMinEdge(Number(value))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOnlyValue(!onlyValue),
						className: CHIP + (onlyValue ? " bg-signal text-ink" : " border border-line text-fg"),
						children: onlyValue ? "Value at my site" : "All prices"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Seg, {
						label: "Day",
						value: day,
						options: [
							["ALL", "Any day"],
							["Saturday", "Saturday"],
							["Sunday", "Sunday"],
							["Midweek", "Midweek"]
						],
						onChange: setDay
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setOnlyDesk(!onlyDesk),
						className: CHIP + (onlyDesk ? " bg-signal text-ink" : " border border-line text-fg"),
						children: onlyDesk ? "Bets only" : "Include passes"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setWatchOnly(!watchOnly),
						className: CHIP + (watchOnly ? " bg-signal text-ink" : " border border-line text-fg"),
						children: watchOnly ? "Watchlist" : "All matches"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "Competition → kickoff groups fixtures by league, then start time. The same schedule order applies to every selected bookmaker; it is not a live mirror of a bookmaker’s internal event list."
			})
		]
	});
}
function Seg({ label, value, options, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 max-w-full items-center gap-1 overflow-x-auto rounded-full border border-line p-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "shrink-0 px-2 text-xs text-muted",
			children: label
		}), options.map(([id, text]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onChange(id),
			className: "h-11 shrink-0 rounded-full px-3 text-sm " + (value === id ? "bg-signal font-medium text-ink" : "text-fg"),
			children: text
		}, id))]
	});
}
var OUTCOME = {
	home: "Home",
	draw: "Draw",
	away: "Away"
};
function accuracy(rows, key) {
	if (!rows.length) return null;
	return rows.filter((row) => {
		return Object.keys(row[key]).reduce((best, side) => row[key][side] > row[key][best] ? side : best, "home") === row.result;
	}).length / rows.length;
}
function brier(rows, key) {
	if (!rows.length) return null;
	return rows.reduce((sum, row) => sum + Object.keys(row[key]).reduce((score, side) => score + (row[key][side] - (row.result === side ? 1 : 0)) ** 2, 0), 0) / rows.length;
}
function Badge({ children, tone = "neutral" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: `rounded-full border px-2 py-1 text-[11px] font-medium ${tone === "good" ? "border-emerald-400/60 text-emerald-300" : tone === "warn" ? "border-amber-400/60 text-amber-200" : tone === "bad" ? "border-red-400/60 text-red-300" : "border-line text-muted"}`,
		children
	});
}
function ModelMonitor() {
	const history = (0, import_react.useMemo)(() => loadHistory(), []);
	const match = MATCHES[0];
	const report = (0, import_react.useMemo)(() => buildAdvancedReport(match.home, match.away), [match]);
	const consensus = (0, import_react.useMemo)(() => buildConsensus(match.home, match.away, {
		history,
		league: match.league
	}), [history, match]);
	const recent = history.slice(-20);
	const engineAccuracy = accuracy(recent, "engine");
	const aiAccuracy = accuracy(recent, "ai");
	const engineBrier = brier(recent, "engine");
	const aiBrier = brier(recent, "ai");
	const best = engineBrier === null || aiBrier === null ? "Balanced start" : engineBrier <= aiBrier ? "Statistical engine" : "AI-style lab";
	const settled = history.length > 0;
	const calibrationGap = recent.length ? recent.reduce((sum, row) => {
		const source = row.final ?? row.engine;
		const top = Math.max(source.home, source.draw, source.away);
		const hit = source[row.result] ? 1 : 0;
		return sum + Math.abs(top - hit);
	}, 0) / recent.length : null;
	const leaveOneOut = report.models.filter((model) => {
		const others = report.models.filter((candidate) => candidate.id !== model.id);
		return others.filter((candidate) => {
			const values = candidate.probabilities;
			return values[report.pick] >= Math.max(values.home, values.draw, values.away);
		}).length >= Math.ceil(others.length / 2);
	}).length;
	const marketPrices = match.books.map((book) => book.odds[consensus.pick]).filter((value) => Number.isFinite(value) && value > 1);
	const marketDispersion = marketPrices.length ? Math.max(...marketPrices) - Math.min(...marketPrices) : null;
	const formPoints = (form) => form.reduce((sum, mark) => sum + (mark === "W" ? 3 : mark === "D" ? 1 : 0), 0);
	const formMomentum = formPoints(match.home.form) - formPoints(match.away.form);
	const recencySkill = (key) => {
		if (!recent.length) return null;
		let weightedHits = 0;
		let totalWeight = 0;
		recent.forEach((row, index) => {
			const weight = Math.pow(.92, recent.length - index - 1);
			const pick = Object.keys(row[key]).reduce((bestSide, side) => row[key][side] > row[key][bestSide] ? side : bestSide, "home");
			weightedHits += pick === row.result ? weight : 0;
			totalWeight += weight;
		});
		return weightedHits / totalWeight;
	};
	const recentEngineSkill = recencySkill("engine");
	const recentAiSkill = recencySkill("ai");
	const drawCalibration = recent.length ? recent.reduce((sum, row) => sum + Math.abs((row.final ?? row.engine).draw - (row.result === "draw" ? 1 : 0)), 0) / recent.length : null;
	const sortedProbabilities = Object.values(consensus.probabilities).sort((a, b) => b - a);
	const topTwoCoverage = sortedProbabilities[0] + sortedProbabilities[1];
	const featureRows = [
		[
			"Historical winner",
			best,
			settled ? "Lower Brier score wins the next weighting window." : "Waiting for settled prediction results."
		],
		[
			"Engine accuracy",
			engineAccuracy === null ? "n/a" : pct$1(engineAccuracy),
			"Last 20 settled results."
		],
		[
			"AI-style accuracy",
			aiAccuracy === null ? "n/a" : pct$1(aiAccuracy),
			"Last 20 settled results."
		],
		[
			"Learning sample",
			`${history.length} results`,
			"Previous predictions retained for recalibration."
		],
		[
			"Engine / AI agreement",
			`${consensus.enginePick === consensus.aiPick ? "Aligned" : "Split"}`,
			`${OUTCOME[consensus.enginePick]} vs ${OUTCOME[consensus.aiPick]}.`
		],
		[
			"Final model margin",
			pct$1(consensus.probabilities[consensus.pick] - Math.max(...Object.entries(consensus.probabilities).filter(([key]) => key !== consensus.pick).map(([, value]) => value))),
			"Lead over the second outcome."
		],
		[
			"Stress stability",
			`${Math.round(report.stressStable ? 100 : 0)}%`,
			"Keeps the same lean under ±10% xG stress."
		],
		[
			"Probability spread",
			pct$1(report.spread),
			"Range between the 25 predictor outputs."
		],
		[
			"Recent form",
			`${match.home.short} ${match.home.form.join("")} · ${match.away.short} ${match.away.form.join("")}`,
			"Last five W/D/L marks."
		],
		[
			"Availability",
			`${match.home.out.length + match.away.out.length} listed`,
			"Named absences are shown on each fixture."
		],
		[
			"Odds alignment",
			match.desk ? "Value line found" : "PASS / verify price",
			"No edge is treated as a guarantee."
		],
		[
			"Data freshness",
			consensus.freshness.action.toUpperCase(),
			consensus.freshness.reasons[0] ?? "Current inputs available."
		],
		[
			"Dixon–Coles correction",
			"Active",
			"Adjusts low-score dependence for 0–0, 1–0, 0–1 and 1–1 outcomes."
		],
		[
			"Bayesian shrinkage",
			"Active",
			"Pulls small samples toward a 1.35-goal prior."
		],
		[
			"Monte Carlo",
			"2,400 runs",
			"Repeatable score simulations stress the adjusted goal rates."
		],
		[
			"Negative-binomial",
			"Active",
			"Tests wider-than-Poisson score variance."
		],
		[
			"Bivariate goals",
			"Active",
			"Allows a shared latent match-goal component."
		],
		[
			"Zero-inflated case",
			"Active",
			"Checks whether extra low-score mass changes the lean."
		],
		[
			"Table-position gap",
			`${Math.abs(match.home.pos - match.away.pos)} places`,
			`${match.home.short} ${match.home.pos} · ${match.away.short} ${match.away.pos}.`
		],
		[
			"xG attack gap",
			`${(match.home.xgFor - match.away.xgFor).toFixed(2)}`,
			"Season expected-goals-for difference."
		],
		[
			"Goal-difference gap",
			`${match.home.gf - match.home.ga - (match.away.gf - match.away.ga)}`,
			"Observed season goal-difference comparison."
		],
		[
			"Draw probability",
			pct$1(consensus.probabilities.draw),
			"Keeps draw risk visible even when a side leads."
		],
		[
			"Prediction entropy",
			`${(-Object.values(consensus.probabilities).reduce((sum, p) => sum + p * Math.log(Math.max(p, .001)), 0)).toFixed(2)}`,
			"Higher entropy means a less decisive probability split."
		],
		[
			"Scoreline mode",
			match.score,
			"Most likely score from the goal grid; not a guarantee."
		],
		[
			"Best market price",
			`${match.best[consensus.pick].odds.toFixed(2)}`,
			`${match.best[consensus.pick].book} reference price for the reconciled outcome.`
		],
		[
			"Absence stress",
			`${match.home.out.length + match.away.out.length} listed`,
			"Named availability changes are tested as a separate stress scenario."
		],
		[
			"Calibration gap",
			calibrationGap === null ? "n/a" : `${Math.round(calibrationGap * 100)} pp`,
			"Average gap between stated top probability and settled outcome over the recent window."
		],
		[
			"Leave-one-model-out",
			`${leaveOneOut}/${report.models.length}`,
			"Checks whether the final lean survives removal of an individual model."
		],
		[
			"Bookmaker dispersion",
			marketDispersion === null ? "n/a" : marketDispersion.toFixed(2),
			"Difference between the highest and lowest available 1X2 price for the final outcome."
		],
		[
			"Form momentum",
			`${formMomentum >= 0 ? "+" : ""}${formMomentum} pts`,
			`${match.home.short} versus ${match.away.short} across the listed five-match form.`
		],
		[
			"Recency-weighted skill",
			recentEngineSkill === null || recentAiSkill === null ? "n/a" : `E ${Math.round(recentEngineSkill * 100)}% · AI ${Math.round(recentAiSkill * 100)}%`,
			"Recent settled predictions count more than older results."
		],
		[
			"Draw calibration",
			drawCalibration === null ? "n/a" : `${Math.round(drawCalibration * 100)} pp`,
			"Outcome-specific error for the draw probability on recent results."
		],
		[
			"Top-two coverage",
			`${Math.round(topTwoCoverage * 100)}%`,
			topTwoCoverage >= .78 ? "Two outcomes cover most probability; a single pick is less decisive." : "The leading outcome carries a larger share of the probability."
		]
	];
	const verdictTone = consensus.tier === "PASS" ? "bad" : consensus.enginePick === consensus.aiPick ? "good" : "warn";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-4",
		"aria-labelledby": "model-monitor-title",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-[0.16em] text-signal",
						children: "Decision layer"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						id: "model-monitor-title",
						className: "mt-1 font-display text-3xl",
						children: "Final call monitor"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 max-w-3xl text-sm text-muted",
						children: "The dashboard now compares the two headline models against previous settled predictions, then makes one reconciled call. It shows PASS when current data is not strong enough."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: verdictTone,
					children: consensus.tier === "PASS" ? "PASS · verify data" : `FINAL · ${OUTCOME[consensus.pick]}`
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Final prediction"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xl font-semibold",
								children: consensus.tier === "PASS" ? "PASS" : OUTCOME[consensus.pick]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									Math.round(consensus.probabilities[consensus.pick] * 100),
									"% · tier ",
									consensus.tier
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Best model now"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xl font-semibold",
								children: best
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									"Historical weighting · ",
									history.length,
									" logged"
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "Two-model check"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xl font-semibold",
								children: consensus.enginePick === consensus.aiPick ? "Aligned" : "Split"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									"Engine ",
									OUTCOME[consensus.enginePick],
									" · AI ",
									OUTCOME[consensus.aiPick]
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: "PASS rule"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xl font-semibold",
								children: consensus.tier === "PASS" ? "Active" : "Clear"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Freshness, model split, margin and stress checks"
							})
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-4 grid gap-2 sm:grid-cols-2 lg:grid-cols-3",
				children: featureRows.map(([name, value, note]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-card border border-line bg-raised p-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-sm font-semibold tabular-nums text-fg",
							children: value
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-[11px] text-muted",
						children: note
					})]
				}, name))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-[11px] text-muted",
				children: "Historical accuracy is descriptive, not a guarantee. With fewer than 20 settled results the engine and AI weights remain balanced; the dashboard will not pretend a small sample proves a best model."
			})
		]
	});
}
/** Read the public page only; do not fetch hidden app endpoints or bypass a gate. */
var refreshJackpot = createServerFn({ method: "GET" }).handler(createSsrRpc("a3d9059c842e62f8323454b137a7bcc53e3132d66db2cc8efa5a8631699a19e4"));
var BETIKA_STAKE = 49;
var BOOK_LABELS = {
	betika: "Betika",
	sportpesa: "SportPesa",
	xbet: "1xBet",
	other: "Other / manual"
};
var BOOKS = [
	"betika",
	"sportpesa",
	"xbet",
	"other"
];
var EMPTY_LISTS = {
	betika: [],
	sportpesa: [],
	xbet: [],
	other: []
};
function fair(odds) {
	const raw = {
		home: 1 / odds.home,
		draw: 1 / odds.draw,
		away: 1 / odds.away
	};
	const sum = raw.home + raw.draw + raw.away;
	return {
		home: raw.home / sum,
		draw: raw.draw / sum,
		away: raw.away / sum
	};
}
function asGames(rows, book) {
	return rows.filter((row) => row.found).map((row) => ({
		id: row.id,
		book,
		bookmaker: BOOK_LABELS[book],
		league: row.league,
		when: row.when,
		kickoff: row.kickoff,
		home: row.home,
		away: row.away,
		odds: row.odds
	}));
}
function fromManual(row) {
	return {
		...row,
		manual: true,
		kickoff: row.when === "Kickoff not entered" ? void 0 : row.when,
		when: row.when === "Kickoff not entered" ? row.when : formatTime(row.when)
	};
}
function modeledFixture(game) {
	if (!game.kickoff) return void 0;
	let candidates = MATCHES.filter((match) => sameTeam(game.home, match.home.name) && sameTeam(game.away, match.away.name));
	const fixtureTime = Date.parse(game.kickoff);
	if (!Number.isFinite(fixtureTime)) return void 0;
	candidates = candidates.filter((match) => {
		const modeledTime = KICKOFF_ISO[match.id] ? Date.parse(KICKOFF_ISO[match.id]) : NaN;
		return Number.isFinite(modeledTime) && Math.abs(modeledTime - fixtureTime) <= 216e5;
	});
	return candidates.length === 1 ? candidates[0] : void 0;
}
function suggestedPick(game) {
	const match = modeledFixture(game);
	if (match) return buildConsensus(match.home, match.away, {
		odds: game.odds,
		history: loadHistory()
	}).pick;
	if (game.odds) return topResult(fair(game.odds));
	return "draw";
}
function mergeGames(publicGames, manualRows) {
	const rows = [...publicGames, ...manualRows.map(fromManual)];
	const unique = [];
	for (const game of rows) {
		const kickoff = game.kickoff ? Date.parse(game.kickoff) : NaN;
		const duplicateIndex = unique.findIndex((existing) => {
			if (existing.book !== game.book || !sameTeam(existing.home, game.home) || !sameTeam(existing.away, game.away)) return false;
			const existingKickoff = existing.kickoff ? Date.parse(existing.kickoff) : NaN;
			if (!Number.isFinite(kickoff) || !Number.isFinite(existingKickoff)) return existing.id === game.id;
			return Math.abs(existingKickoff - kickoff) <= 216e5;
		});
		if (duplicateIndex < 0) unique.push(game);
		else if (game.manual || !unique[duplicateIndex].manual && game.odds) unique[duplicateIndex] = game;
	}
	return unique.sort((left, right) => {
		return (left.kickoff ? Date.parse(left.kickoff) : Number.POSITIVE_INFINITY) - (right.kickoff ? Date.parse(right.kickoff) : Number.POSITIVE_INFINITY) || left.home.localeCompare(right.home);
	});
}
function Jackpot() {
	const { now } = useNow(1e3);
	const [book, setBook] = (0, import_react.useState)("betika");
	const [lists, setLists] = (0, import_react.useState)(EMPTY_LISTS);
	const [status, setStatus] = (0, import_react.useState)("Checking public bookmaker feeds.");
	const [sourceStatus, setSourceStatus] = (0, import_react.useState)({
		betika: "Checking",
		sportpesa: "Checking",
		xbet: "Checking",
		other: "No public feed; manually entered odds only."
	});
	const [prize, setPrize] = (0, import_react.useState)("");
	const [expiry, setExpiry] = (0, import_react.useState)("");
	const [checking, setChecking] = (0, import_react.useState)(false);
	const [refreshCount, setRefreshCount] = (0, import_react.useState)(0);
	const [dateFilter, setDateFilter] = (0, import_react.useState)("ALL");
	const [draft, setDraft] = (0, import_react.useState)({
		book: "betika",
		otherBookmaker: "",
		league: "",
		when: "",
		home: "",
		away: "",
		homeOdds: "",
		drawOdds: "",
		awayOdds: ""
	});
	const [formError, setFormError] = (0, import_react.useState)("");
	const jackpotPicks = useDesk((state) => state.jackpotPicks);
	const manualGames = useDesk((state) => state.manualJackpotGames);
	const setJackpotPick = useDesk((state) => state.setJackpotPick);
	const setJackpotPicks = useDesk((state) => state.setJackpotPicks);
	const addManualJackpotGame = useDesk((state) => state.addManualJackpotGame);
	const removeManualJackpotGame = useDesk((state) => state.removeManualJackpotGame);
	const allGames = (0, import_react.useMemo)(() => mergeGames(lists[book] ?? [], manualGames.filter((game) => game.book === book)), [
		book,
		lists,
		manualGames
	]);
	const gameDates = (0, import_react.useMemo)(() => Array.from(new Set(allGames.map((game) => game.kickoff ? new Date(game.kickoff).toISOString().slice(0, 10) : null).filter((date) => Boolean(date)))).sort(), [allGames]);
	const games = (0, import_react.useMemo)(() => dateFilter === "ALL" ? allGames : allGames.filter((game) => game.kickoff && new Date(game.kickoff).toISOString().slice(0, 10) === dateFilter), [allGames, dateFilter]);
	const deadline = expiry ? Date.parse(expiry) : NaN;
	const left = now === null || !Number.isFinite(deadline) ? null : Math.max(0, deadline - now);
	const complete = games.length > 0 && games.every((game) => jackpotPicks[game.id] !== null && jackpotPicks[game.id] !== void 0);
	(0, import_react.useEffect)(() => {
		let stop = false;
		const load = async () => {
			setChecking(true);
			try {
				const data = await refreshJackpot();
				if (stop) return;
				setLists({
					betika: asGames(data.betika, "betika"),
					sportpesa: asGames(data.sportpesa, "sportpesa"),
					xbet: asGames(data.xbet, "xbet"),
					other: []
				});
				setPrize(data.prize);
				setExpiry(data.expiry);
				setSourceStatus({
					betika: data.betikaStatus,
					sportpesa: data.sportpesaStatus,
					xbet: data.xbetStatus,
					other: "No public feed; manually entered odds only."
				});
				const clock = new Date(data.checked).toLocaleTimeString("en-KE", {
					hour: "2-digit",
					minute: "2-digit"
				});
				setStatus(`Last public-source check: ${clock}. Prices are refreshed every two minutes.`);
			} catch {
				if (!stop) {
					setLists(EMPTY_LISTS);
					setSourceStatus({
						betika: "Request failed; no cached or demo prices are shown.",
						sportpesa: "Request failed; no cached or demo prices are shown.",
						xbet: "Request failed; no cached or demo prices are shown.",
						other: "No public feed; manually entered odds only."
					});
					setStatus("Refresh failed. No saved or simulated public-source prices are displayed.");
				}
			} finally {
				if (!stop) setChecking(false);
			}
		};
		load();
		const timer = window.setInterval(() => void load(), 12e4);
		return () => {
			stop = true;
			window.clearInterval(timer);
		};
	}, [refreshCount]);
	(0, import_react.useEffect)(() => {
		const current = useDesk.getState().jackpotPicks;
		const next = { ...current };
		let changed = false;
		for (const game of games) {
			const proposed = suggestedPick(game);
			const existing = current[game.id];
			const priced = modeledFixture(game);
			const report = priced ? buildAdvancedReport(priced.home, priced.away) : null;
			const market = game.odds ? fair(game.odds) : null;
			const flagged = existing && report && market ? isModelDisagreement(market[existing], report.ensemble[existing]) : false;
			if (!Object.prototype.hasOwnProperty.call(current, game.id) || existing == null || flagged) {
				next[game.id] = proposed;
				changed = true;
			}
		}
		if (changed) setJackpotPicks(next);
	}, [games, setJackpotPicks]);
	function submitManualGame(event) {
		event.preventDefault();
		setFormError("");
		const home = draft.home.trim();
		const away = draft.away.trim();
		const odds = {
			home: Number(draft.homeOdds),
			draw: Number(draft.drawOdds),
			away: Number(draft.awayOdds)
		};
		if (!home || !away || sameTeam(home, away)) {
			setFormError("Enter two different team names in the same 1 / X / 2 order shown by the bookmaker.");
			return;
		}
		if (!Object.values(odds).every((odd) => Number.isFinite(odd) && odd > 1.01 && odd <= 100)) {
			setFormError("Enter all three decimal odds, each greater than 1.01 and no higher than 100.");
			return;
		}
		const kickoff = draft.when ? new Date(draft.when) : null;
		if (draft.when && (!kickoff || !Number.isFinite(kickoff.getTime()))) {
			setFormError("The kickoff time is not valid.");
			return;
		}
		const bookmaker = draft.book === "other" ? draft.otherBookmaker.trim() : BOOK_LABELS[draft.book];
		if (!bookmaker || bookmaker.length > 40) {
			setFormError("Enter the bookmaker name (up to 40 characters).");
			return;
		}
		const when = kickoff ? kickoff.toISOString() : "Kickoff not entered";
		const row = {
			id: `manual-${globalThis.crypto?.randomUUID?.() ?? `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`}`,
			book: draft.book,
			bookmaker,
			league: draft.league.trim().slice(0, 80) || "Competition not entered",
			when,
			home,
			away,
			odds,
			enteredAt: (/* @__PURE__ */ new Date()).toISOString()
		};
		addManualJackpotGame(row);
		setBook(draft.book);
		setDraft((current) => ({
			...current,
			league: "",
			when: "",
			home: "",
			away: "",
			homeOdds: "",
			drawOdds: "",
			awayOdds: ""
		}));
	}
	const lines = complete ? 1 : 0;
	const liveCount = (source) => lists[source].length + manualGames.filter((game) => game.book === source).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-lg flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Jackpot"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-muted",
				children: "One 1 / X / 2 result is selected for every listed match. Red flags warn against a market outcome; amber marks a cautious fallback when models disagree or data is incomplete. Missing bookmaker prices are never invented."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: status
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setRefreshCount((count) => count + 1),
					disabled: checking,
					className: "h-10 shrink-0 rounded-full border border-line px-4 text-sm disabled:opacity-50",
					children: checking ? "Checking…" : "Refresh now"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: BOOKS.map((source) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					onClick: () => setBook(source),
					className: "h-11 rounded-full text-sm " + (book === source ? "bg-signal font-medium text-ink" : "border border-line"),
					children: [
						BOOK_LABELS[source],
						" · ",
						liveCount(source)
					]
				}, source))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: sourceStatus[book]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-3",
				"aria-label": "Jackpot date selector",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium",
							children: "Jackpot date:"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDateFilter("ALL"),
							className: `h-9 rounded-full px-3 text-xs ${dateFilter === "ALL" ? "bg-signal text-ink" : "border border-line"}`,
							children: "All available"
						}),
						gameDates.slice(0, 5).map((date) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => setDateFilter(date),
							className: `h-9 rounded-full px-3 text-xs ${dateFilter === date ? "bg-signal text-ink" : "border border-line"}`,
							children: date === (/* @__PURE__ */ new Date()).toISOString().slice(0, 10) ? "Today" : (/* @__PURE__ */ new Date(`${date}T12:00:00Z`)).toLocaleDateString(void 0, {
								day: "numeric",
								month: "short"
							})
						}, date)),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-9 items-center gap-2 rounded-full border border-line px-3 text-xs text-muted",
							children: ["Specific date ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "date",
								value: dateFilter === "ALL" ? "" : dateFilter,
								onChange: (event) => setDateFilter(event.target.value || "ALL"),
								className: "bg-transparent text-fg outline-none"
							})]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-[11px] text-muted",
					children: [
						games.length,
						" real upcoming game",
						games.length === 1 ? "" : "s",
						" visible for this selection. Past games are excluded from Jackpot."
					]
				})]
			}),
			book === "betika" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
				className: "rounded-card border border-line bg-raised p-4",
				"aria-label": "Betika jackpot status",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-center justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-semibold uppercase tracking-wide text-signal",
							children: "Betika jackpot"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-lg font-semibold",
							children: games.length ? "Jackpot card present" : "Jackpot card not detected"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: games.length ? `${games.length} verified game${games.length === 1 ? "" : "s"} loaded with 1 / X / 2 prices.` : "No exact public Betika card is available right now. Add the fixtures and odds from the Betika app below; they will remain marked manual."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://www.betika.com/en-ke/",
						target: "_blank",
						rel: "noreferrer",
						className: "rounded-full border border-line px-3 py-2 text-xs text-signal",
						children: "Open Betika"
					})]
				})
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelMonitor, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-4 gap-2 rounded-card bg-signal p-4 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockCell, {
						label: "Days",
						value: left === null ? "—" : String(Math.floor(left / 864e5)).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockCell, {
						label: "Hours",
						value: left === null ? "—" : String(Math.floor(left / 36e5) % 24).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockCell, {
						label: "Minutes",
						value: left === null ? "—" : String(Math.floor(left / 6e4) % 60).padStart(2, "0")
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClockCell, {
						label: "Seconds",
						value: left === null ? "—" : String(Math.floor(left / 1e3) % 60).padStart(2, "0")
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-center text-sm font-medium",
				children: book === "betika" ? `Must Be Won · ${prize || "prize unavailable"} · stake KES ${BETIKA_STAKE}` : book === "sportpesa" ? "SportPesa public jackpot card · no fallback prices" : book === "xbet" ? "1xBet public page check · no fallback prices" : "Manual fixtures · user-entered odds only"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm font-medium",
					children: "Add a game and odds read from a bookmaker app"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
					className: "mt-3 flex flex-col gap-3",
					onSubmit: submitManualGame,
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-muted",
							children: ["Bookmaker", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
								value: draft.book,
								onChange: (event) => setDraft((current) => ({
									...current,
									book: event.target.value
								})),
								className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "betika",
										children: "Betika"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "sportpesa",
										children: "SportPesa"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "xbet",
										children: "1xBet"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
										value: "other",
										children: "Other bookmaker"
									})
								]
							})]
						}),
						draft.book === "other" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "text-sm text-muted",
							children: ["Other bookmaker name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								value: draft.otherBookmaker,
								onChange: (event) => setDraft((current) => ({
									...current,
									otherBookmaker: event.target.value
								})),
								maxLength: 40,
								className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg",
								placeholder: "Bookmaker name"
							})]
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-muted",
								children: ["Home team (1)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: draft.home,
									onChange: (event) => setDraft((current) => ({
										...current,
										home: event.target.value
									})),
									maxLength: 80,
									className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-muted",
								children: ["Away team (2)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									value: draft.away,
									onChange: (event) => setDraft((current) => ({
										...current,
										away: event.target.value
									})),
									maxLength: 80,
									className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "grid grid-cols-2 gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-muted",
								children: ["Competition (optional)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: draft.league,
									onChange: (event) => setDraft((current) => ({
										...current,
										league: event.target.value
									})),
									maxLength: 80,
									className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-sm text-muted",
								children: ["Kickoff (optional)", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "datetime-local",
									value: draft.when,
									onChange: (event) => setDraft((current) => ({
										...current,
										when: event.target.value
									})),
									className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
								})]
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid grid-cols-3 gap-2",
							children: [
								"homeOdds",
								"drawOdds",
								"awayOdds"
							].map((field, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "text-xs text-muted",
								children: [index === 0 ? "1 · Home" : index === 1 ? "X · Draw" : "2 · Away", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									required: true,
									type: "number",
									inputMode: "decimal",
									min: "1.02",
									max: "100",
									step: "0.01",
									value: draft[field],
									onChange: (event) => setDraft((current) => ({
										...current,
										[field]: event.target.value
									})),
									className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-2 text-fg",
									placeholder: "2.10"
								})]
							}, field))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-muted",
							children: "Enter the prices exactly as displayed: 1 is the home team, X is the draw, and 2 is the away team. This is a user-entered quote, not independently fetched or verified."
						}),
						formError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							role: "alert",
							className: "text-sm text-red-300",
							children: formError
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "submit",
							className: "h-11 rounded-full bg-signal text-sm font-medium text-ink",
							children: "Save this manually checked game"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						const next = { ...useDesk.getState().jackpotPicks };
						for (const game of games) next[game.id] = suggestedPick(game);
						setJackpotPicks(next);
					},
					disabled: games.length === 0,
					className: "h-11 flex-1 rounded-full border border-line text-sm disabled:opacity-50",
					children: "Auto pick · one result per game"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => {
						const next = { ...useDesk.getState().jackpotPicks };
						for (const game of games) next[game.id] = null;
						setJackpotPicks(next);
					},
					disabled: games.length === 0,
					className: "h-11 flex-1 rounded-full border border-line text-sm disabled:opacity-50",
					children: "Clear picks"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-end justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-semibold uppercase tracking-wide text-signal",
					children: "Jackpot teams"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-muted",
					children: "Previous five results are shown as W / D / L circles under both teams."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted",
					children: [games.length, " games"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
				className: "flex flex-col gap-3",
				children: [games.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "rounded-card border border-line bg-surface p-4 text-sm text-muted",
					children: "No current public quotes are available from this source. Add a game above and enter the exact 1 / X / 2 odds you read in the bookmaker app; unverified or estimated prices are never presented as official odds."
				}) : null, games.map((game, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(JackpotGameCard, {
					game,
					index,
					chosen: jackpotPicks[game.id] ?? null,
					onPick: (pick) => setJackpotPick(game.id, jackpotPicks[game.id] === pick ? null : pick),
					onRemove: game.manual ? () => removeManualJackpotGame(game.id) : void 0
				}, game.id))]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between rounded-card border border-line bg-surface px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: complete ? "Complete card · one selection per game" : "Card status" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tabular-nums",
					children: book === "betika" ? complete ? `KES ${BETIKA_STAKE}` : games.length ? "Pick one result per game" : "No current card" : complete ? `${lines} line` : games.length ? "Finish the card" : "No current card"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Card-wide diagnostics"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-2",
					children: checks(games).map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "text-fg",
							children: [item.name, ". "]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: item.note
						})]
					}, item.name))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-card border border-line bg-raised p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-sm font-medium",
						children: "How to use IAN TECH Jackpot"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 list-decimal space-y-2 pl-5 text-sm text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Choose Betika, SportPesa, 1xBet, or Other/manual. Public odds appear only when an exact fixture is available." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Check the home team shown first: 1 means home, X means draw, and 2 means away." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "One result is preselected for every game. A red flag means the market and local model materially disagree; do not manually choose that red outcome. If every outcome is flagged, the model-led pick is shown in amber as a caution. Amber also marks missing-data fallback picks." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If a bookmaker feed has no price, enter the match and all three prices read from that bookmaker's app. The entry is labeled as manual and is not independently verified." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open the prediction lab on a match with exact matching fixture data to see the same local models, diagnostics, source check, and risk warnings shown under Ready/Upcoming." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-xs text-muted",
						children: "Your Jackpot picks and manual fixtures are saved with your signed-in account. Another account using the same website link has its own saved selections. No prediction is certain; verify the match and price before placing anything."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Betika prices are accepted only for exact team pairs with a valid upcoming kickoff. SportPesa official odds are shown only when its public jackpot response is accessible and identifies home and away explicitly. A third-party comparison, old cached line, generated estimate, or another bookmaker's price is never relabeled as SportPesa odds. Nothing is placed for you."
			})
		]
	});
}
function knownTeamSide(team) {
	for (const match of MATCHES) {
		if (sameTeam(team, match.home.name)) return match.home;
		if (sameTeam(team, match.away.name)) return match.away;
		const wanted = looseTeamKey(team);
		for (const side of [match.home, match.away]) {
			const candidate = looseTeamKey(side.name);
			if (wanted.length >= 5 && candidate.length >= 5 && (wanted.includes(candidate) || candidate.includes(wanted))) return side;
		}
	}
}
function looseTeamKey(value) {
	return value.toLowerCase().replace(/\b(the|fc|afc|sc|cf|united|city)\b/g, "").replace(/[^a-z0-9]/g, "");
}
function formRecord(form) {
	return `W ${form.filter((mark) => mark === "W").length} · D ${form.filter((mark) => mark === "D").length} · L ${form.filter((mark) => mark === "L").length}`;
}
function formPoints(form) {
	return form.reduce((sum, mark) => sum + (mark === "W" ? 3 : mark === "D" ? 1 : 0), 0);
}
function JackpotGameCard({ game, index, chosen, onPick, onRemove }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	const priced = (0, import_react.useMemo)(() => modeledFixture(game), [game]);
	const report = (0, import_react.useMemo)(() => priced ? buildAdvancedReport(priced.home, priced.away) : null, [priced]);
	const odds = game.odds;
	const homeFormSide = priced?.home ?? knownTeamSide(game.home);
	const awayFormSide = priced?.away ?? knownTeamSide(game.away);
	const labHome = homeFormSide;
	const labAway = awayFormSide;
	const displayReport = labHome && labAway ? buildAdvancedReport(labHome, labAway) : null;
	const probs = odds ? fair(odds) : null;
	const modelPick = report ? predictorPickLabel(report.pick, priced?.home.short ?? game.home, priced?.away.short ?? game.away) : null;
	const redFlags = report && probs ? Object.keys(probs).filter((pick) => isModelDisagreement(probs[pick], report.ensemble[pick])) : [];
	const final = priced ? buildConsensus(priced.home, priced.away, {
		odds: odds ?? void 0,
		history: loadHistory(),
		league: priced.league
	}) : null;
	const finalMargin = final ? final.probabilities[final.pick] - Math.max(...Object.entries(final.probabilities).filter(([pick]) => pick !== final.pick).map(([, value]) => value)) : 0;
	const availability = [...priced?.home.out ?? [], ...priced?.away.out ?? []].filter((item) => !/no new|no senior|no confirmed/i.test(item));
	const status = game.kickoff && Date.parse(game.kickoff) <= Date.now() ? "Live / started" : "Upcoming";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3 text-sm text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					String(index + 1).padStart(2, "0"),
					" · ",
					game.league
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "tabular-nums",
						children: game.when
					}), onRemove ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onRemove,
						"aria-label": "Remove manual game",
						className: "grid size-9 place-items-center rounded-full border border-line",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
					}) : null]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2 text-[11px]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: `rounded-full border px-2 py-1 ${status === "Upcoming" ? "border-signal/60 text-signal" : "border-red-400/60 text-red-300"}`,
						children: status
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-line px-2 py-1",
						children: "Source checked live"
					}),
					availability.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "rounded-full border border-amber-400/60 px-2 py-1 text-amber-200",
						children: [
							availability.length,
							" absence warning",
							availability.length === 1 ? "" : "s"
						]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "rounded-full border border-line px-2 py-1",
						children: "No named absences"
					})
				]
			}),
			game.manual ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-signal",
				children: [
					"Manual quote · entered from ",
					game.bookmaker,
					" at",
					" ",
					game.enteredAt ? new Date(game.enteredAt).toLocaleTimeString() : "unknown time",
					" · not independently verified"
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-xs text-muted",
				children: [
					"Public source · ",
					game.bookmaker,
					" · exact event data"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 text-xs text-muted",
							children: "1 · HOME"
						}), game.home]
					}),
					homeFormSide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPills, { form: homeFormSide.form }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[11px] text-muted",
						children: ["Previous 5 · ", formRecord(homeFormSide.form)]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Previous W/D/L: unavailable in current team data"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 font-medium",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 text-xs text-muted",
							children: "2 · AWAY"
						}), game.away]
					}),
					awayFormSide ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPills, { form: awayFormSide.form }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-[11px] text-muted",
						children: ["Previous 5 · ", formRecord(awayFormSide.form)]
					})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Previous W/D/L: unavailable in current team data"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-muted",
				children: [
					"1 = ",
					game.home,
					" to win · X = draw · 2 = ",
					game.away,
					" to win"
				]
			}),
			report && probs ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 text-sm text-muted",
				children: [
					"Stats-only lean (feeds the Final tip above): ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-fg",
						children: modelPick
					}),
					" ·",
					" ",
					Math.round(report.ensemble[report.pick] * 100),
					"% · ",
					report.agreement,
					"/",
					report.models.length,
					" formulas agree · sample ",
					report.sampleGames,
					" games."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: "No verified team-stat match is available for this fixture. The prediction lab will remain limited until current team data is matched."
			}),
			displayReport ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-card border border-line bg-raised p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs font-semibold uppercase tracking-wide text-signal",
						children: [
							"Prediction lab · ",
							displayReport.models.length,
							"-model ensemble"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm font-medium text-fg",
						children: [
							predictorPickLabel(displayReport.pick, game.home, game.away),
							" · ",
							Math.round(displayReport.ensemble[displayReport.pick] * 100),
							"%"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							displayReport.agreement,
							"/",
							displayReport.models.length,
							" models agree · ",
							displayReport.sampleGames,
							" games sampled · spread ",
							Math.round(displayReport.spread * 100),
							" pp."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"Stress test: ",
							displayReport.stressStable ? "same lean across scenarios" : "lean changes under stress",
							". This is the stats layer feeding the final tip."
						]
					})
				]
			}) : null,
			final ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "mt-3 rounded-card border-2 border-red-400/70 bg-red-950/30 p-3",
				"aria-label": "Jackpot unified final prediction",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-semibold uppercase tracking-wide text-red-300",
						children: "Unified final prediction"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-lg font-semibold text-fg",
						children: final.tier === "PASS" ? "PASS · verify data" : `${mark(final.pick)} · ${nameOf(game, final.pick)}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							Math.round(final.probabilities[final.pick] * 100),
							"% · ",
							final.tier,
							" · ",
							report?.models.length ?? 0,
							" model formulas · scoreline ",
							priced?.score ?? "—"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 grid grid-cols-3 gap-2 text-center text-xs",
						children: [
							"home",
							"draw",
							"away"
						].map((pick) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => onPick(pick),
							className: `rounded-card border px-2 py-2 ${final.pick === pick ? "border-red-300 bg-red-500/30 text-red-100" : "border-line bg-bg text-muted"}`,
							children: [
								mark(pick),
								" · ",
								nameOf(game, pick),
								final.pick === pick ? " · FINAL" : ""
							]
						}, pick))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-[11px] text-red-100/80",
						children: "Select the highlighted FINAL result for the Jackpot card. PASS is a warning, not a guarantee."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 grid grid-cols-2 gap-2 text-[11px] text-muted sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								"Final margin ",
								Math.round(finalMargin * 100),
								" pp"
							] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Home form ", homeFormSide ? `${formPoints(homeFormSide.form)}/15` : "n/a"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Away form ", awayFormSide ? `${formPoints(awayFormSide.form)}/15` : "n/a"] }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: final.enginePick === final.aiPick ? "Engine + AI aligned" : "Engine / AI split" })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => {
							navigator.clipboard?.writeText(`${game.home} v ${game.away}: ${final.tier === "PASS" ? "PASS" : `${mark(final.pick)} ${nameOf(game, final.pick)}`} · scoreline ${priced?.score ?? "n/a"}`).then(() => setCopied(true));
						},
						className: "mt-3 h-9 rounded-full border border-line px-3 text-xs text-fg",
						children: copied ? "Final pick copied" : "Copy final pick"
					})
				]
			}) : null,
			odds ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-3 grid grid-cols-3 gap-2",
					children: [
						"home",
						"draw",
						"away"
					].map((pick) => {
						const isFlagged = redFlags.includes(pick);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								if (!isFlagged) onPick(pick);
							},
							disabled: isFlagged,
							"aria-disabled": isFlagged,
							"aria-pressed": chosen === pick,
							"aria-label": `${mark(pick)} ${nameOf(game, pick)} odds ${odds[pick].toFixed(2)}${isFlagged ? ", red flag: market/model mismatch" : ""}`,
							className: "flex min-h-14 flex-col items-center justify-center rounded-card px-1 py-2 text-sm tabular-nums " + (isFlagged && chosen === pick ? "border border-amber-400 bg-amber-950/70 text-amber-100 font-medium " : isFlagged ? "border border-red-400 bg-red-950/60 text-red-100 opacity-90 cursor-not-allowed " : chosen === pick ? "bg-signal font-medium text-ink" : "bg-bg text-fg"),
							children: [
								isFlagged ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "mb-0.5 flex items-center gap-1 text-[10px] font-semibold",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-3" }), " RED FLAG"]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									mark(pick),
									" · ",
									odds[pick].toFixed(2)
								] }),
								chosen === pick ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-[10px]",
									children: isFlagged ? "Selected · CAUTION" : "Selected"
								}) : null
							]
						}, pick);
					})
				}),
				redFlags.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-2 text-xs text-red-200",
					children: [
						"Red flag: the no-vig bookmaker probability is at least 10 percentage points above the corresponding local-model probability for",
						" ",
						redFlags.map((pick) => nameOf(game, pick)).join(", "),
						". Treat this as a disagreement warning only; the formulas are not calibrated."
					]
				}) : report ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-xs text-muted",
					children: "No 10-point market/model mismatch is flagged for these prices. That does not mean the bet is safe."
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-muted",
					children: analyse(game, fair(odds), priced)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: ["Two price-derived scoreline estimates: ", twoScores(odds).join(" · ")]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 rounded-card border border-amber-400 bg-amber-950/50 p-3 text-sm text-amber-100",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-semibold",
					children: ["AMBER · ", report ? "MODEL PICK · NO VERIFIED BOOKMAKER ODDS" : "LOW DATA FALLBACK"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1",
					children: [
						"Selected: ",
						mark(chosen ?? "draw"),
						" · ",
						nameOf(game, chosen ?? "draw"),
						".",
						report ? " This is the matched local model's leading outcome, but bookmaker prices are unavailable." : " No exact team-stat model or verified 1X2 odds are available. This is a placeholder selection, not a researched prediction.",
						" ",
						"Verify the market before using this pick."
					]
				})]
			}),
			priced ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-muted",
				children: [
					"Expected goals ",
					priced.lambdaHome.toFixed(2),
					"–",
					priced.lambdaAway.toFixed(2),
					". Most likely score ",
					priced.score,
					". ",
					priced.read
				]
			}) : null,
			priced ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PredictionLab, {
				match: priced,
				odds: game.odds
			}) : null,
			game.manual ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-muted",
				children: "Remove this row with the trash button if the event, team order, or price changes."
			}) : null
		]
	});
}
function analyse(game, probs, priced) {
	const order = [
		"home",
		"draw",
		"away"
	];
	const top = topResult(probs);
	const next = order.find((pick) => pick !== top && probs[pick] === Math.max(...order.filter((item) => item !== top).map((item) => probs[item]))) ?? "draw";
	const close = probs[top] - probs[next] < .06;
	const short = (game.odds?.[top] ?? 9) < 1.7;
	const desk = priced ? ` The local fixture model leans ${priced.likely.market === "home" ? game.home : priced.likely.market === "away" ? game.away : "the draw"}.` : "";
	return `No-vig market lean: ${nameOf(game, top)} (${pct(probs[top])}). ${close ? "The market is close; only one result can be selected." : "One result leads."}${short ? " That price is short." : ""}${desk}`;
}
function checks(games) {
	const leans = games.filter((game) => game.odds && game.odds.home > 1).map((game) => {
		const probs = fair(game.odds);
		const top = topResult(probs);
		return {
			game,
			probs,
			top,
			gap: probs[top] - Math.max(...[
				"home",
				"draw",
				"away"
			].filter((pick) => pick !== top).map((pick) => probs[pick]))
		};
	});
	const count = (pick) => leans.filter((row) => row.top === pick).length;
	const doubles = leans.filter((row) => row.gap < .06).length;
	const short = leans.filter((row) => (row.game.odds?.[row.top] ?? 9) < 1.5).length;
	const draws = leans.reduce((sum, row) => sum + row.probs.draw, 0) / Math.max(leans.length, 1);
	const open = leans.slice().sort((a, b) => a.probs.draw - b.probs.draw)[0];
	const even = leans.slice().sort((a, b) => a.gap - b.gap)[0];
	const bankers = leans.filter((row) => row.probs[row.top] >= .5).length;
	return [
		{
			name: "Home leans",
			note: `${count("home")} of ${leans.length} point to the home side.`
		},
		{
			name: "Draw leans",
			note: `${count("draw")} point to the draw.`
		},
		{
			name: "Away leans",
			note: `${count("away")} point to the away side.`
		},
		{
			name: "Close markets",
			note: `${doubles} games have a top-two probability gap under 6 points; the card still allows one selection only.`
		},
		{
			name: "Bankers",
			note: `${bankers} market leans are 50% or more. A banker can still lose.`
		},
		{
			name: "Short prices",
			note: `${short} market leans are under 1.50.`
		},
		{
			name: "Draw weight",
			note: `The average draw probability on this card is ${pct(draws)}.`
		},
		{
			name: "Most open",
			note: open ? `${open.game.home} v ${open.game.away} has the smallest draw probability.` : "No games."
		},
		{
			name: "Most even",
			note: even ? `${even.game.home} v ${even.game.away} has the tightest 1X2.` : "No games."
		},
		{
			name: "Odds-derived scores",
			note: "Each row estimates two scorelines from the selected 1X2 prices; these are not team-stat model outputs."
		},
		{
			name: "Public rows",
			note: `${games.filter((game) => !game.manual).length} rows came from an accessible public source.`
		},
		{
			name: "Manual rows",
			note: `${games.filter((game) => game.manual).length} rows were entered by a user and need bookmaker verification.`
		},
		{
			name: "Market/model warnings",
			note: "A red flag marks a material mismatch between no-vig market odds and a matched local model; no flag means no warning met the threshold."
		},
		{
			name: "Source order",
			note: "1 is the displayed home team, X is draw, and 2 is the displayed away team."
		},
		{
			name: "Missing prices",
			note: "Unavailable quotes stay blank; no demo or other-bookmaker odds are substituted."
		},
		{
			name: "One result",
			note: "A single result is selected per match. Close probabilities do not auto-create a double chance."
		},
		{
			name: "Card size",
			note: `${games.length} games are on this list.`
		},
		{
			name: "Data coverage",
			note: `${leans.length} games have a complete 1X2 price.`
		},
		{
			name: "Model access",
			note: "The full local model and analytics panel appears only where team order and kickoff match a fixture in Ready/Upcoming."
		},
		{
			name: "Limit",
			note: "No check or formula makes a jackpot certain."
		}
	];
}
function formatTime(iso) {
	const date = new Date(iso);
	if (!Number.isFinite(date.getTime())) return iso;
	return new Intl.DateTimeFormat("en-KE", {
		day: "2-digit",
		month: "2-digit",
		hour: "2-digit",
		minute: "2-digit",
		hourCycle: "h23",
		timeZone: "Africa/Nairobi"
	}).format(date);
}
function ClockCell({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "text-center",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-3xl tabular-nums",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs",
			children: label
		})]
	});
}
function mark(pick) {
	if (pick === "home") return "1";
	if (pick === "draw") return "X";
	return "2";
}
function nameOf(game, pick) {
	if (pick === "home") return game.home;
	if (pick === "away") return game.away;
	return "Draw";
}
function pct(value) {
	return `${Math.round(value * 100)}%`;
}
var FACT = [
	1,
	1,
	2,
	6,
	24,
	120
];
function pois(lambda, goals) {
	return Math.exp(-lambda) * lambda ** goals / FACT[goals];
}
function twoScores(odds) {
	const probs = fair(odds);
	const total = Math.min(3.4, Math.max(1.7, 2.5 * (1 - probs.draw) / .72));
	const gap = (probs.home - probs.away) * 1.5;
	const home = Math.min(3.1, Math.max(.35, (total + gap) / 2));
	const away = Math.min(3, Math.max(.25, (total - gap) / 2));
	const rows = [];
	for (let h = 0; h <= 5; h += 1) for (let a = 0; a <= 5; a += 1) rows.push({
		score: `${h}-${a}`,
		chance: pois(home, h) * pois(away, a)
	});
	rows.sort((a, b) => b.chance - a.chance);
	return [rows[0].score, rows[1].score];
}
function poisson(k, lambda) {
	let p = Math.exp(-lambda);
	for (let i = 1; i <= k; i++) p *= lambda / i;
	return p;
}
/** Minute runs on a 96-minute desk loop so a match is always in play. */
function liveClock(offsetMin, now) {
	if (now === null) return {
		label: "Live",
		minute: -1,
		half: "Live"
	};
	const minute = (Math.floor(now / 6e4) + offsetMin) % 96;
	if (minute >= 45 && minute < 48) return {
		label: "HT",
		minute: 45,
		half: "Half-time"
	};
	if (minute > 90) return {
		label: `90+${minute - 90}`,
		minute,
		half: "Added time"
	};
	if (minute >= 48) return {
		label: `${minute}'`,
		minute,
		half: "2nd half"
	};
	return {
		label: `${minute}'`,
		minute,
		half: "1st half"
	};
}
function scoreAt(goals, minute) {
	if (minute < 0) return {
		home: 0,
		away: 0
	};
	let home = 0;
	let away = 0;
	for (const goal of goals) if (goal.minute <= minute) {
		if (goal.side === "home") home += 1;
		else away += 1;
	}
	return {
		home,
		away
	};
}
/** Win chances from the goals already scored plus the xG still left. */
function inPlay(lamH, lamA, minute, hg, ag) {
	const played = minute < 0 ? 20 : Math.min(94, minute);
	const left = Math.max(6, 94 - played) / 94;
	const remH = lamH * left;
	const remA = lamA * left;
	const max = 6;
	const ph = Array.from({ length: 7 }, (_, k) => poisson(k, remH));
	const pa = Array.from({ length: 7 }, (_, k) => poisson(k, remA));
	let home = 0;
	let draw = 0;
	let away = 0;
	for (let i = 0; i <= max; i++) for (let j = 0; j <= max; j++) {
		const p = ph[i] * pa[j];
		const fh = hg + i;
		const fa = ag + j;
		if (fh > fa) home += p;
		else if (fh === fa) draw += p;
		else away += p;
	}
	const mass = home + draw + away || 1;
	const noGoal = Math.exp(-(remH + remA));
	const share = remH + remA <= 0 ? .5 : remH / (remH + remA);
	return {
		home: home / mass,
		draw: draw / mass,
		away: away / mass,
		liveXgH: lamH * (played / 94),
		liveXgA: lamA * (played / 94),
		remH,
		remA,
		nextHome: (1 - noGoal) * share,
		nextAway: (1 - noGoal) * (1 - share),
		noGoal
	};
}
function halfTimeLean(lamH, lamA) {
	return inPlay(lamH * .45, lamA * .45, 0, 0, 0);
}
function topScorelines(lamH, lamA, n = 3) {
	const max = 5;
	const rows = [];
	const ph = Array.from({ length: 6 }, (_, k) => poisson(k, lamH));
	const pa = Array.from({ length: 6 }, (_, k) => poisson(k, lamA));
	for (let i = 0; i <= max; i++) for (let j = 0; j <= max; j++) rows.push({
		score: `${i}–${j}`,
		p: ph[i] * pa[j]
	});
	return rows.sort((a, b) => b.p - a.p).slice(0, n);
}
function liveDecimal(prob, sharp) {
	return Math.round(1 / Math.max(.05, prob * (sharp ? 1.035 : 1.075)) * 100) / 100;
}
function slipCode(parts) {
	let h = 2166136261;
	const seed = parts.join("|");
	for (let i = 0; i < seed.length; i++) {
		h ^= seed.charCodeAt(i);
		h = Math.imul(h, 16777619);
	}
	return `SL-${(h >>> 0).toString(36).toUpperCase().padStart(4, "0").slice(0, 6)}`;
}
var HOME = [
	[78, 200],
	[160, 70],
	[160, 150],
	[160, 250],
	[160, 330],
	[250, 110],
	[250, 200],
	[250, 290],
	[330, 90],
	[330, 200],
	[330, 310]
];
var AWAY = HOME.map(([x, y]) => [680 - x, y]);
function LiveStage({ id, compact = false }) {
	const match = findMatch(id);
	const { now } = useNow(250);
	if (!match) return null;
	const fixture = liveFixture(match.id);
	const clock = fixture ? liveClock(fixture.offsetMin, now) : {
		label: match.time,
		minute: -1,
		half: "Not started"
	};
	const score = fixture ? scoreAt(fixture.goals, clock.minute) : {
		home: 0,
		away: 0
	};
	const play = inPlay(match.lambdaHome, match.lambdaAway, fixture ? clock.minute : 0, score.home, score.away);
	const lean = argmax({
		home: play.home,
		draw: play.draw,
		away: play.away
	});
	const leanName = lean === "home" ? match.home.short : lean === "away" ? match.away.short : "Draw";
	const t = now ?? 0;
	const ball = ballAt(t, score.home, score.away, clock.minute);
	const goals = fixture ? fixture.goals.filter((goal) => clock.minute < 0 || goal.minute <= clock.minute) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		id: "live-view",
		className: "overflow-hidden rounded-card border border-line bg-[#101612] text-white",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pitch, {
					now: t,
					ball,
					compact
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute top-2 left-2 flex items-center gap-2 rounded-full bg-black/70 px-3 py-1 text-xs",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "size-2 rounded-full bg-[#d6f25c]",
							"aria-hidden": "true"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: fixture ? clock.label : "KO" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-white/70",
							children: fixture ? clock.half : "Not started"
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "absolute right-2 bottom-2 left-2 grid grid-cols-[1fr_auto_1fr] items-center gap-2 rounded-card bg-black/75 px-3 py-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-sm",
							children: match.home.short
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-3xl tabular-nums",
							children: fixture && clock.minute < 0 ? "–" : `${score.home}–${score.away}`
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "truncate text-right text-sm",
							children: match.away.short
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-1 px-3 py-2 text-xs text-white/75",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
					match.league,
					match.venue ? ` · ${match.venue}` : "",
					" · lean ",
					leanName,
					" ",
					pct$1(lean === "home" ? play.home : lean === "away" ? play.away : play.draw)
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: goals.length === 0 ? "No goal yet." : goals.map((goal) => `${goal.minute}' ${goal.side === "home" ? match.home.short : match.away.short}`).join(" · ") }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Desk picture running on this site. Not the television broadcast." })
			]
		})]
	});
}
function Pitch({ now, ball, compact }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 680 400",
		className: compact ? "h-44 w-full" : "h-auto max-h-[28rem] w-full",
		role: "img",
		"aria-label": "Live pitch",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				width: "680",
				height: "400",
				fill: "#1c4a28"
			}),
			Array.from({ length: 8 }, (_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: i * 85,
				width: "85",
				height: "400",
				fill: i % 2 ? "#1a4424" : "#1c4a28"
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "16",
				y: "16",
				width: "648",
				height: "368",
				fill: "none",
				stroke: "#d6f25c",
				strokeOpacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("line", {
				x1: "340",
				y1: "16",
				x2: "340",
				y2: "384",
				stroke: "#d6f25c",
				strokeOpacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "340",
				cy: "200",
				r: "54",
				fill: "none",
				stroke: "#d6f25c",
				strokeOpacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "16",
				y: "110",
				width: "90",
				height: "180",
				fill: "none",
				stroke: "#d6f25c",
				strokeOpacity: "0.75"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
				x: "574",
				y: "110",
				width: "90",
				height: "180",
				fill: "none",
				stroke: "#d6f25c",
				strokeOpacity: "0.75"
			}),
			HOME.map(([x, y], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: x,
				cy: sway(y, now, i),
				r: "8",
				fill: "#d6f25c"
			}, `h${i}`)),
			AWAY.map(([x, y], i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: x,
				cy: sway(y, now, i + 3),
				r: "8",
				fill: "#f4f4f0"
			}, `a${i}`)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: ball.x,
				cy: ball.y,
				r: "6",
				fill: "#ffffff"
			})
		]
	});
}
function sway(y, now, i) {
	if (now === 0) return y;
	return Math.min(370, Math.max(30, y + Math.sin(now / 420 + i) * 10));
}
function ballAt(now, homeGoals, awayGoals, minute) {
	if (now === 0 || minute < 0) return {
		x: 340,
		y: 200
	};
	const toward = homeGoals === awayGoals ? 1 : homeGoals > awayGoals ? 1 : -1;
	const x = 340 + Math.sin(now / 900) * 150 + toward * 70;
	const y = 200 + Math.cos(now / 700) * 90;
	return {
		x: Math.min(640, Math.max(40, x)),
		y: Math.min(360, Math.max(40, y))
	};
}
function LiveBoard() {
	const league = useDesk((s) => s.league);
	const query = useDesk((s) => s.query);
	const bookId = useDesk((s) => s.bookId);
	const oddsFormat = useDesk((s) => s.oddsFormat);
	const setOpen = useDesk((s) => s.setOpen);
	const setPreview = useDesk((s) => s.setPreview);
	const toggleLeg = useDesk((s) => s.toggleLeg);
	const legs = useDesk((s) => s.legs);
	const { now } = useNow(1e3);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const [byMinute, setByMinute] = (0, import_react.useState)(false);
	const [watchId, setWatchId] = (0, import_react.useState)(null);
	const book = BOOKS$1.find((row) => row.id === bookId);
	const q = query.trim().toLowerCase();
	const rows = LIVE.filter((match) => {
		if (league !== "ALL" && match.code !== league) return false;
		if (q && !`${match.home.name} ${match.away.name}`.toLowerCase().includes(q)) return false;
		const fixture = liveFixture(match.id);
		if (!fixture || filter === "all") return true;
		const score = scoreAt(fixture.goals, liveClock(fixture.offsetMin, now).minute);
		if (filter === "level") return score.home === score.away;
		if (filter === "home") return score.home > score.away;
		return score.away > score.home;
	}).sort((a, b) => {
		if (!byMinute) return 0;
		const am = liveClock(liveFixture(a.id)?.offsetMin ?? 0, now).minute;
		return liveClock(liveFixture(b.id)?.offsetMin ?? 0, now).minute - am;
	});
	const playing = rows.find((match) => match.id === watchId) ?? rows[0];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Live games"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-2xl text-pretty text-muted",
				children: [
					LIVE.length,
					" matches on a running tape, ",
					rows.length,
					" showing. The picture is the live view. Watch switches the match and keeps a small window open. It is not a television broadcast."
				]
			})] }),
			playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveStage, { id: playing.id }) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [[
					["all", "All"],
					["level", "Level"],
					["home", "Home leading"],
					["away", "Away leading"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setFilter(id),
					className: "h-11 rounded-full border px-4 text-sm " + (filter === id ? "border-signal bg-signal text-ink" : "border-line bg-surface"),
					children: label
				}, id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setByMinute((on) => !on),
					className: "h-11 rounded-full border px-4 text-sm " + (byMinute ? "border-signal bg-signal text-ink" : "border-line bg-surface"),
					children: byMinute ? "Latest minute" : "Sort by minute"
				})]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-card border border-line bg-surface px-4 py-8 text-center text-muted",
				children: "No live game in this category."
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: rows.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveCard, {
					match,
					now,
					bookId,
					sharp: Boolean(book?.sharp),
					bookName: book?.name ?? "",
					oddsFormat,
					onSlip: legs.some((leg) => leg.matchId === match.id),
					watching: playing?.id === match.id,
					onOpen: () => setOpen(match.id),
					onPreview: () => {
						setWatchId(match.id);
						setPreview(match.id);
						document.getElementById("live-view")?.scrollIntoView({ block: "nearest" });
					},
					onAdd: (market) => toggleLeg(match.id, market)
				}, match.id))
			})
		]
	});
}
function LiveCard({ match, now, bookId, sharp, bookName, oddsFormat, onSlip, watching, onOpen, onPreview, onAdd }) {
	const fixture = liveFixture(match.id) ?? LIVE_RAW[0];
	const clock = liveClock(fixture.offsetMin, now);
	const score = scoreAt(fixture.goals, clock.minute);
	const play = inPlay(match.lambdaHome, match.lambdaAway, clock.minute, score.home, score.away);
	const lean = play.home >= play.away && play.home >= play.draw ? "home" : play.away >= play.draw ? "away" : "draw";
	const leanP = lean === "home" ? play.home : lean === "away" ? play.away : play.draw;
	const leanName = lean === "home" ? match.home.short : lean === "away" ? match.away.short : "Draw";
	const pre = quoteAt(match, bookId, lean);
	const shown = formatOdds(liveDecimal(leanP, sharp), oddsFormat);
	const both = bothStill(score.home, score.away, play.remH, play.remA);
	const last = lastGoal(fixture.goals, clock.minute);
	const split = play.liveXgH + play.liveXgA || 1;
	const pack = predictionFeeds(match.home, match.away);
	const preTip = useConsensus(match.id, match.home, match.away, {
		live: true,
		league: match.league
	});
	const liveTip = liveConsensus(preTip, play, clock.minute);
	const agreeName = pack.pick === "home" ? match.home.short : pack.pick === "away" ? match.away.short : "Draw";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "flex flex-col gap-3 rounded-card border bg-surface p-4 " + (watching ? "border-signal" : "border-line"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3 text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-muted",
					children: [
						match.code,
						" · ",
						clock.half
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "flex items-center gap-2 font-medium text-signal",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "size-2 rounded-full bg-signal",
						"aria-hidden": "true"
					}), clock.label]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-[1fr_auto_1fr] items-center gap-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 font-medium",
						children: match.home.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-4xl tabular-nums",
						children: clock.minute < 0 ? "–" : `${score.home}–${score.away}`
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "min-w-0 text-right font-medium",
						children: match.away.name
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex h-1.5 overflow-hidden rounded-full bg-raised",
				"aria-hidden": "true",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-signal",
					style: { width: `${(play.liveXgH / split * 100).toFixed(1)}%` }
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "bg-fg",
					style: { width: `${(play.liveXgA / split * 100).toFixed(1)}%` }
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm tabular-nums text-muted",
				children: [
					"Live xG ",
					play.liveXgH.toFixed(2),
					"–",
					play.liveXgA.toFixed(2),
					" · left ",
					play.remH.toFixed(2),
					"–",
					play.remA.toFixed(2)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-3 gap-2 text-center text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-card bg-raised px-2 py-2",
						children: ["1", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-display text-xl tabular-nums",
							children: pct$1(play.home)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-card bg-raised px-2 py-2",
						children: ["X", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-display text-xl tabular-nums",
							children: pct$1(play.draw)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-card bg-raised px-2 py-2",
						children: ["2", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mt-1 block font-display text-xl tabular-nums",
							children: pct$1(play.away)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsensusBadge, {
				c: liveTip,
				home: match.home.short,
				away: match.away.short,
				signalsUsed: preTip.signalsUsed
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-fg",
				children: [
					"In-play lean ",
					leanName,
					" ",
					pct$1(leanP),
					" · ",
					bookName,
					" ",
					shown
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					"Next goal ",
					match.home.short,
					" ",
					pct$1(play.nextHome),
					" · both to score ",
					pct$1(both),
					" · was ",
					formatOdds(pre.odds, oddsFormat)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					pack.agree,
					" of ",
					pack.core,
					" core reads say ",
					agreeName,
					". ",
					pack.extraAgree,
					" of ",
					pack.extras.length,
					" extra reads agree. Last goal ",
					last,
					".",
					fixture.flag ? ` ${fixture.flag}.` : ""
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onPreview,
						className: "h-11 flex-1 rounded-full bg-signal text-sm font-medium text-ink",
						children: watching ? "Watching" : "Watch"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: onOpen,
						className: "h-11 flex-1 rounded-full border border-line text-sm",
						children: "Sheet"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => onAdd(lean),
						className: "h-11 flex-1 rounded-full border border-line text-sm",
						children: onSlip ? "On slip" : "Add lean"
					})
				]
			})
		]
	});
}
function lastGoal(goals, minute) {
	if (minute < 0) return "not shown yet";
	const hit = [...goals].reverse().find((goal) => goal.minute <= minute);
	if (!hit) return "none yet";
	return `${hit.side === "home" ? "home" : "away"} ${hit.minute}'`;
}
function bothStill(home, away, remH, remA) {
	if (home > 0 && away > 0) return 1;
	const ph = 1 - Math.exp(-remH);
	const pa = 1 - Math.exp(-remA);
	if (home > 0) return pa;
	if (away > 0) return ph;
	return ph * pa;
}
function MatchPreview({ id }) {
	const match = findMatch(id);
	const setPreview = useDesk((s) => s.setPreview);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") setPreview(null);
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, [setPreview]);
	if (!match || !liveFixture(match.id)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		role: "dialog",
		"aria-label": "Live game",
		className: "fixed right-3 bottom-20 z-40 w-[min(100%-1.5rem,22rem)] overflow-hidden rounded-card border border-line bg-bg shadow-2xl md:bottom-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2 border-b border-line px-3 py-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "min-w-0 flex-1 text-sm text-signal",
					children: "Live window"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setPreview(null),
					"aria-label": "Close live window",
					className: "flex size-11 shrink-0 items-center justify-center rounded-full border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
				className: "block border-b border-line px-3 py-2 text-xs text-muted",
				children: ["Switch game", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					value: match.id,
					onChange: (event) => setPreview(event.target.value),
					className: "mt-1 h-11 w-full rounded-card border border-line bg-raised px-2 text-sm text-fg",
					children: LIVE.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("option", {
						value: row.id,
						children: [
							row.home.short,
							" v ",
							row.away.short
						]
					}, row.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveStage, {
				id: match.id,
				compact: true
			})
		]
	});
}
var EMPTY_SIDE = {
	name: "",
	short: "",
	pos: 10,
	form: [],
	xgFor: 1.3,
	xgAgainst: 1.3,
	gf: 0,
	ga: 0,
	played: 0,
	out: []
};
function MatchSheet({ id }) {
	const match = findMatch(id);
	const setOpen = useDesk((s) => s.setOpen);
	const toggleLeg = useDesk((s) => s.toggleLeg);
	const legs = useDesk((s) => s.legs);
	const bankroll = useDesk((s) => s.bankroll);
	const bookId = useDesk((s) => s.bookId);
	const [chartOn, setChartOn] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			if (event.key === "Escape") setOpen(null);
		};
		window.addEventListener("keydown", onKey);
		const prev = document.body.style.overflow;
		document.body.style.overflow = "hidden";
		const frame = requestAnimationFrame(() => setChartOn(true));
		return () => {
			window.removeEventListener("keydown", onKey);
			document.body.style.overflow = prev;
			cancelAnimationFrame(frame);
		};
	}, [setOpen]);
	const tip = useConsensus(id, match?.home ?? EMPTY_SIDE, match?.away ?? EMPTY_SIDE, { league: match?.league });
	if (!match) return null;
	const settled = RECENT.find((row) => row.id === match.id);
	const lines = topScorelines(match.lambdaHome, match.lambdaAway, 3);
	const ht = halfTimeLean(match.lambdaHome, match.lambdaAway);
	const yours = quoteAt(match, bookId, match.likely.market);
	const pack = predictionFeeds(match.home, match.away);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "fixed inset-0 z-40 flex items-end justify-center sm:items-center",
		role: "presentation",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": "Close sheet",
			className: "absolute inset-0 bg-ink/70",
			onClick: () => setOpen(null)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			role: "dialog",
			"aria-modal": "true",
			"aria-labelledby": "sheet-title",
			className: "relative max-h-[92vh] w-full max-w-3xl overflow-y-auto rounded-t-card border border-line bg-bg p-4 sm:rounded-card",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							match.league,
							" · ",
							match.dateLabel,
							" · ",
							match.time,
							" UK"
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						id: "sheet-title",
						className: "font-display text-3xl",
						children: [
							match.home.name,
							" v ",
							match.away.name
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: match.venue
					}),
					settled ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-3 text-fg",
						children: [
							"Full time ",
							settled.homeGoals,
							"–",
							settled.awayGoals,
							". Model had called ",
							shortMarket(match, match.likely.market),
							".",
							" ",
							actualSide(settled) === match.likely.market ? "That call landed." : "That call missed."
						]
					}) : null
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => setOpen(null),
					"aria-label": "Close",
					className: "flex size-11 shrink-0 items-center justify-center rounded-full border border-line",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-5" })
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-6 flex flex-col gap-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-4 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBlock, {
							match,
							side: "home"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SideBlock, {
							match,
							side: "away"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Home xG",
								value: match.lambdaHome.toFixed(2)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Modal score",
								value: match.score
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Away xG",
								value: match.lambdaAway.toFixed(2)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConsensusBadge, {
						c: tip,
						home: match.home.short,
						away: match.away.short,
						signalsUsed: tip.signalsUsed
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-pretty text-muted",
						children: match.read
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-signal",
						children: readLine(match.home.short, match.away.short, pack)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-2",
						children: pack.extras.map((feed) => {
							const side = argmax(feed);
							const label = side === "home" ? match.home.short : side === "away" ? match.away.short : "Draw";
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "rounded-full border border-line px-3 py-1 text-xs",
								title: feed.note,
								children: [
									feed.name,
									" · ",
									label
								]
							}, feed.id);
						})
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-3 sm:grid-cols-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Half-time lean",
								value: `${pct$1(Math.max(ht.home, ht.draw, ht.away))}`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: `${match.home.short} −0.5`,
								value: oddsText(quoteAt(match, bookId, "home").odds)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Stat, {
								label: "Your price",
								value: `${oddsText(yours.odds)} ${yours.book}`
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Top scores ",
							lines.map((line) => `${line.score} ${pct$1(line.p)}`).join(" · "),
							". Asian",
							" ",
							match.home.short,
							" −0.5 is the same bet as the home win. Half-time uses 45% of the full-match xG."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Call, {
							kicker: "Most likely result",
							title: selectionName(match, match.likely.market),
							detail: `${pct$1(match.likely.model)} · best ${oddsText(match.likely.odds)} ${match.likely.book}`,
							note: match.likely.ev >= .02 ? "The likely side still has a price edge." : match.likely.ev <= -.03 ? "Likely, and the price is shorter than the model. That is a pass if you only bet value." : "Likely, and the price is about fair."
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Call, {
							kicker: "Plus-EV price",
							title: match.desk ? selectionName(match, match.desk.market) : "Pass",
							detail: match.desk ? `${oddsText(match.desk.odds)} ${match.desk.book} · ${signedPts(match.desk.edge)} · ${signedEv(match.desk.ev)}` : "No market clears the desk filter.",
							note: match.desk ? `Suggested ${units(suggestedStake(match.desk, bankroll))} units on a ${units(bankroll)} bank.` : "Do not force a selection.",
							action: match.desk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => toggleLeg(match.id, match.desk.market),
								className: "mt-3 h-11 rounded-full bg-signal px-4 text-sm font-medium text-ink",
								children: legs.some((leg) => leg.matchId === match.id && leg.market === match.desk?.market) ? "Remove from slip" : "Add plus-EV to slip"
							}) : null
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-display text-2xl",
							children: "Prices"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Signal numbers are the best price in that column. Your site is marked."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 overflow-x-auto rounded-card border border-line",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[40rem] border-collapse text-left text-sm tabular-nums",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "bg-raised text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-3 font-medium",
										children: "Book"
									}), MARKET_KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "px-3 py-3 font-medium",
										children: marketLabel(key)
									}, key))] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: match.books.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line " + (book.id === bookId ? "bg-raised" : ""),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("th", {
										className: "px-3 py-3 text-left font-medium text-fg",
										children: [
											book.name,
											book.id === bookId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-normal text-signal",
												children: "Your site"
											}) : null,
											book.sharp && book.id !== bookId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "block font-normal text-muted",
												children: "Sharp"
											}) : null
										]
									}), MARKET_KEYS.map((key) => {
										const best = match.best[key].bookId === book.id;
										return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "px-3 py-3 " + (best ? "font-medium text-signal" : "text-fg"),
											children: oddsText(book.odds[key])
										}, key);
									})]
								}, book.id)) })]
							})
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl",
						children: "Total goals"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-48 rounded-card border border-line bg-surface p-3",
						children: chartOn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResponsiveContainer, {
							width: "100%",
							height: "100%",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(BarChart, {
								data: match.goalDist,
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XAxis, {
										dataKey: "goals",
										stroke: "#8a8478",
										fontSize: 12,
										tickLine: false,
										axisLine: false
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(YAxis, { hide: true }),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tooltip, {
										cursor: { fill: "rgba(214,242,92,0.08)" },
										contentStyle: {
											background: "#17160f",
											border: "1px solid #2c2a22",
											borderRadius: 12
										}
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bar, {
										dataKey: "pct",
										fill: "#d6f25c",
										radius: 4
									})
								]
							})
						}) : null
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-display text-2xl",
						children: "Add a market"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-col gap-2",
						children: MARKET_KEYS.map((key) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarketRow, {
							match,
							market: key
						}, key))
					})] })
				]
			})]
		})]
	});
}
function SideBlock({ match, side }) {
	const team = match[side];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-medium",
				children: team.name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					ordinal(team.pos),
					" · ",
					team.xgFor.toFixed(2),
					" xG for, ",
					team.xgAgainst.toFixed(2),
					" against"
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FormPills, { form: team.form })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted",
				children: team.out.length ? team.out.join(", ") : "No listed absence"
			})
		]
	});
}
function MarketRow({ match, market }) {
	const edge = match.edges.find((item) => item.market === market);
	const legs = useDesk((s) => s.legs);
	const toggleLeg = useDesk((s) => s.toggleLeg);
	const bookId = useDesk((s) => s.bookId);
	if (!edge) return null;
	const yours = quoteAt(match, bookId, market);
	const on = legs.some((leg) => leg.matchId === match.id && leg.market === market);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "flex flex-wrap items-center justify-between gap-3 rounded-card border border-line bg-surface px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-medium",
			children: selectionName(match, market)
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "text-sm tabular-nums text-muted",
			children: [
				"Model ",
				pct$1(edge.model),
				" · yours ",
				oddsText(yours.odds),
				" ",
				yours.book,
				" · best ",
				oddsText(edge.odds),
				" ",
				edge.book
			]
		})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => toggleLeg(match.id, market),
			className: "h-11 rounded-full bg-signal px-4 text-sm font-medium text-ink",
			children: on ? "On slip" : "Add"
		})]
	});
}
function Stat({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-surface px-4 py-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm text-muted",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
function Call({ kicker, title, detail, note, action }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-signal",
				children: kicker
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-1 font-display text-2xl",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm tabular-nums text-fg",
				children: detail
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-pretty text-muted",
				children: note
			}),
			action
		]
	});
}
function ordinal(n) {
	const v = n % 100;
	if (v >= 11 && v <= 13) return `${n}th`;
	switch (n % 10) {
		case 1: return `${n}st`;
		case 2: return `${n}nd`;
		case 3: return `${n}rd`;
		default: return `${n}th`;
	}
}
var pc$1 = (x) => Number.isFinite(x) ? `${(x * 100).toFixed(1)}%` : "n/a";
var num$1 = (x, d = 3) => Number.isFinite(x) ? x.toFixed(d) : "n/a";
function Row({ label, c }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-line",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
				scope: "row",
				className: "py-1.5 pr-3 text-left font-normal",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "py-1.5 pr-3 tabular-nums",
				children: [
					c.hits,
					"/",
					c.n
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "py-1.5 pr-3 tabular-nums",
				children: [
					pc$1(c.hitRate),
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-muted",
						children: [
							"(",
							pc$1(c.hitLow),
							"–",
							pc$1(c.hitHigh),
							")"
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 pr-3 tabular-nums",
				children: num$1(c.brier)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-1.5 tabular-nums",
				children: num$1(c.logLoss)
			})
		]
	});
}
/** Measured accuracy against completed matches. Agreement between models is shown only as a thing to test, never as proof. */
function BacktestPanel() {
	const [r, setR] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		let alive = true;
		getBacktest().then((x) => alive && setR(x)).catch(() => alive && setFailed(true));
		return () => {
			alive = false;
		};
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-2xl",
				children: "Retrospective backtest (not pre-recorded)"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-sm text-muted",
				children: "These matches were scored after they finished, from bundled statistics, so they are NOT counted in the dashboard above. They only show how the model would have done. Accuracy is judged by comparing probabilities with real results, not by how many models agree. Hit rates show a 95% range because small samples are mostly luck. Lower Brier and log loss are better."
			}),
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The backtest could not be loaded right now."
			}) : null,
			!r && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Scoring completed matches…"
			}) : null,
			r ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-3 flex flex-col gap-4 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "rounded-card border border-line bg-raised px-3 py-2",
						role: "status",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [r.n, " completed matches."] }),
							" ",
							r.verdictText
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[30rem] text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-3 text-left font-normal",
										children: "Forecaster"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-3 text-left font-normal",
										children: "Correct"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-3 text-left font-normal",
										children: "Hit rate (95% range)"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-3 text-left font-normal",
										children: "Brier"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 text-left font-normal",
										children: "Log loss"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tbody", { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Statistical engine",
									c: r.engine
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "AI-style lab",
									c: r.ai
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Engine + lab blend",
									c: r.blend
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Baseline: always home",
									c: r.baselines.alwaysHome
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Baseline: league base rates",
									c: r.baselines.frequency
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Row, {
									label: "Baseline: coin-flip thirds",
									c: r.baselines.uniform
								})
							] })]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-xs text-muted",
						children: [
							"Skill vs base rates (0 = no better than guessing by frequency): engine ",
							num$1(r.skill.engine),
							", lab ",
							num$1(r.skill.ai),
							", blend ",
							num$1(r.skill.blend),
							"."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Does agreement mean accuracy?"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-xs text-muted",
						children: [
							"Models agreed on ",
							r.agreement.agree.n,
							" matches (",
							pc$1(r.agreement.agree.hitRate),
							" correct) and disagreed on ",
							r.agreement.disagree.n,
							" (",
							pc$1(r.agreement.disagree.hitRate),
							" correct).",
							Number.isFinite(r.agreement.liftPoints) ? r.agreement.liftPoints > 5 && r.n >= 50 ? ` Agreement is associated with ${r.agreement.liftPoints.toFixed(1)} points higher accuracy in this sample.` : " That gap is too small or too uncertain to treat agreement as a sign of being right." : " Not enough matches on both sides to say."
						]
					})] }),
					r.confidence.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "Accuracy by stated confidence"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1 grid gap-1 text-xs text-muted sm:grid-cols-2",
						children: r.confidence.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							b.label,
							": ",
							pc$1(b.card.hitRate),
							" correct over ",
							b.card.n,
							" matches"
						] }, b.label))
					})] }) : null,
					r.calibration.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Calibration"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "When the blend says X%, how often does that outcome really happen?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 grid gap-1 text-xs text-muted sm:grid-cols-2",
							children: r.calibration.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "tabular-nums",
								children: [
									"Said ",
									pc$1(b.predicted),
									" → happened ",
									pc$1(b.observed),
									" (",
									b.n,
									" outcomes)"
								]
							}, b.from))
						})
					] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Limit: the stored probabilities come from the bundled fixture statistics, so this proves the model's track record on those matches, not that picks were locked in before kick-off. A past hit rate does not guarantee future results."
					})
				]
			}) : null
		]
	});
}
/** Read-only view of the log. */
var getTracker = createServerFn({ method: "GET" }).handler(createSsrRpc("9dfca6027de17322ea5a342cf6f5ff6950aac8b0867ec5b57fcf962ca352f321"));
/**
* Records forecasts for fixtures that have not kicked off, settles finished ones, and returns the log.
* Takes no input: every probability and timestamp is produced on the server.
*/
var syncTracker = createServerFn({ method: "POST" }).handler(createSsrRpc("f8d435955c0f59958b672882c4cf0a2c57d4d17c41efeef29851b396bf0f6aa2"));
var pc = (x) => Number.isFinite(x) ? `${(x * 100).toFixed(1)}%` : "n/a";
var num = (x, d = 3) => Number.isFinite(x) ? x.toFixed(d) : "n/a";
var when = (iso) => new Date(iso).toLocaleString("en-GB", {
	dateStyle: "medium",
	timeStyle: "short"
});
var NAME = {
	home: "Home",
	draw: "Draw",
	away: "Away"
};
function Tile({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-raised p-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xl font-semibold tabular-nums",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-0.5 text-[11px] text-muted",
				children: hint
			}) : null
		]
	});
}
function Spark({ points }) {
	if (points.length < 2) return null;
	const w = 320, h = 70, pad = 6;
	const ys = points.map((p) => p.brier);
	const lo = Math.min(...ys), hi = Math.max(...ys, lo + .01);
	const x = (i) => pad + i / (points.length - 1) * 308;
	const y = (v) => 64 - (v - lo) / (hi - lo) * 58;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: `0 0 ${w} ${h}`,
		className: "mt-2 h-[70px] w-full max-w-sm",
		role: "img",
		"aria-label": `Rolling Brier score from ${num(ys[0])} to ${num(ys[ys.length - 1])}; lower is better`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("polyline", {
			fill: "none",
			stroke: "currentColor",
			strokeWidth: "2",
			className: "text-signal",
			points: points.map((p, i) => `${x(i)},${y(p.brier)}`).join(" ")
		})
	});
}
function Mark({ ok }) {
	if (ok === null) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-muted",
		"aria-label": "not applicable",
		children: "–"
	});
	return ok ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-signal",
		"aria-label": "correct",
		children: "✓"
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		"aria-label": "incorrect",
		children: "✗"
	});
}
function download(name, text) {
	const url = URL.createObjectURL(new Blob([text], { type: "text/csv;charset=utf-8" }));
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	document.body.appendChild(a);
	a.click();
	a.remove();
	URL.revokeObjectURL(url);
}
/** Historical performance: forecasts frozen before kickoff, scored against real results. */
function PerformanceDashboard() {
	const [snap, setSnap] = (0, import_react.useState)(null);
	const [syncSummary, setSyncSummary] = (0, import_react.useState)(null);
	const [failed, setFailed] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [syncing, setSyncing] = (0, import_react.useState)(false);
	const [filter, setFilter] = (0, import_react.useState)("all");
	const load = (0, import_react.useCallback)(() => {
		setBusy(true);
		setFailed(false);
		getTracker().then((s) => setSnap(s)).catch(() => setFailed(true)).finally(() => setBusy(false));
	}, []);
	const sync = (0, import_react.useCallback)(() => {
		setSyncing(true);
		setFailed(false);
		syncTracker().then((s) => {
			setSnap({
				rows: s.rows,
				marketBenchmarks: s.marketBenchmarks,
				serverTime: s.serverTime,
				database: s.database
			});
			setSyncSummary({
				recording: s.recording,
				settling: s.settling
			});
		}).catch(() => setFailed(true)).finally(() => setSyncing(false));
	}, []);
	(0, import_react.useEffect)(load, [load]);
	const d = (0, import_react.useMemo)(() => snap ? buildDashboard(snap.rows) : null, [snap]);
	const marketSummary = (0, import_react.useMemo)(() => {
		const benchmarks = snap?.marketBenchmarks ?? [];
		const movement = benchmarks.filter((row) => row.movement !== null);
		const closes = benchmarks.filter((row) => row.closeProbabilityGap !== null);
		return {
			movementMatches: movement.length,
			closeMatches: closes.length,
			meanCloseGap: closes.length ? closes.reduce((sum, row) => sum + (row.closeProbabilityGap ?? 0), 0) / closes.length : null,
			closeRows: closes.slice(-8).reverse()
		};
	}, [snap]);
	const shown = (0, import_react.useMemo)(() => {
		if (!d) return [];
		return [...filter === "correct" ? d.outcomes.correct : filter === "incorrect" ? d.outcomes.incorrect : filter === "confident" ? d.outcomes.confidentMisses : d.buckets.settled].reverse();
	}, [d, filter]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface p-4",
		"aria-labelledby": "perf-title",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-start justify-between gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					id: "perf-title",
					className: "font-display text-2xl",
					children: "Performance dashboard"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 max-w-2xl text-pretty text-sm text-muted",
					children: "Each forecast is frozen before kick-off, then scored against the real result. Confidence alone is not counted as accuracy."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: load,
							disabled: busy,
							className: "rounded-full border border-line px-3 py-1.5 text-xs disabled:opacity-50",
							children: busy ? "Checking…" : "Refresh"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: sync,
							disabled: syncing,
							className: "rounded-full border border-line px-3 py-1.5 text-xs disabled:opacity-50",
							children: syncing ? "Syncing…" : "Sync log"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							disabled: !snap || !snap.rows.length,
							onClick: () => snap && download(`iantech-predictions-${(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)}.csv`, toCsv(snap.rows)),
							className: "rounded-full border border-line px-3 py-1.5 text-xs disabled:opacity-50",
							children: "Export CSV backup"
						})
					]
				})]
			}),
			failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "The prediction log could not be loaded right now. Try Refresh."
			}) : null,
			!snap && !failed ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-sm text-muted",
				children: "Loading the prediction log…"
			}) : null,
			snap && d ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 flex flex-col gap-5 text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised px-3 py-2 text-xs",
						role: "status",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-medium",
								children: [
									snap.database.provider === "supabase" ? "Supabase" : snap.database.provider === "pglite" ? "Preview database" : snap.database.provider === "unconfigured" ? "Database" : "Postgres",
									": ",
									snap.database.connected ? "connected" : "not connected",
									snap.database.durable ? " · durable" : snap.database.provider === "unconfigured" ? " · not configured" : " · ephemeral",
									snap.database.latencyMs === null ? "" : ` · ${snap.database.latencyMs} ms`
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-muted",
								children: snap.database.note
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-muted",
								children: [
									"Checked ",
									when(snap.database.checkedAt),
									". Refresh checks health only; Sync log is an explicit write."
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised px-3 py-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
								className: "font-medium",
								children: "Odds movement and close-line proxy"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-xs text-muted",
								children: "Uses stored The Odds API observations. A close proxy appears only when a provider timestamp is within three hours before kick-off; it is not an official close or placed-bet CLV."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-2 grid grid-cols-2 gap-2 sm:grid-cols-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
										label: "Matches with timestamped movement",
										value: marketSummary.movementMatches
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
										label: "Pre-kickoff quote proxies",
										value: marketSummary.closeMatches
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
										label: "Mean model − fair-market probability",
										value: marketSummary.meanCloseGap === null ? "n/a" : `${(marketSummary.meanCloseGap * 100).toFixed(1)} pp`
									})
								]
							}),
							marketSummary.closeRows.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "mt-2 grid gap-1 text-xs text-muted sm:grid-cols-2",
								children: marketSummary.closeRows.map((market) => {
									const row = snap.rows.find((item) => item.matchId === market.matchId);
									return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
										row ? `${row.home} v ${row.away}` : market.matchId,
										": ",
										(market.closeProbabilityGap * 100).toFixed(1),
										" pp, ",
										market.closeBooks,
										" book(s), observed ",
										market.closeObservedAt ? when(market.closeObservedAt) : "time unavailable",
										"."
									] }, market.matchId);
								})
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-xs text-muted",
								children: "No qualifying pre-kickoff observations have been collected yet."
							})
						]
					}),
					syncSummary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-card border border-line bg-raised px-3 py-2 text-xs",
						role: "status",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [
							"This sync: ",
							syncSummary.recording.recorded,
							" new forecast",
							syncSummary.recording.recorded === 1 ? "" : "s",
							" frozen, ",
							syncSummary.recording.alreadyLogged,
							" already logged."
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-muted",
							children: syncSummary.settling.note
						})]
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Forecasts logged",
								value: d.counts.recorded,
								hint: Number.isFinite(d.avgLeadHours) ? `avg ${d.avgLeadHours.toFixed(1)} h before kick-off` : void 0
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Pending results",
								value: d.counts.pending
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Settled",
								value: d.counts.settled,
								hint: `50 needed for a verdict`
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
								label: "Excluded",
								value: d.counts.excluded,
								hint: "recorded after kick-off"
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Accuracy so far"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 rounded-card border border-line bg-raised px-3 py-2 text-xs",
							children: d.report.verdictText
						}),
						d.counts.settled > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-2 grid grid-cols-2 gap-2 sm:grid-cols-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
									label: "Top pick correct",
									value: pc(d.report.primary.hitRate),
									hint: `${d.report.primary.hits}/${d.report.primary.n}, 95% range ${pc(d.report.primary.hitLow)}–${pc(d.report.primary.hitHigh)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
									label: "Brier score",
									value: num(d.report.primary.brier),
									hint: `base-rate guess ${num(d.report.baselines.frequency.brier)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
									label: "Log loss",
									value: num(d.report.primary.logLoss),
									hint: `equal thirds ${num(d.report.baselines.uniform.logLoss)}`
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tile, {
									label: "Skill vs base rates",
									value: num(d.report.skill.primary),
									hint: "above 0 beats a frequency guess"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								"Tips covering the result (including double chances): ",
								d.outcomes.tipHits,
								"/",
								d.outcomes.tipsMade,
								". PASS calls: ",
								d.outcomes.passes,
								". Engine alone: ",
								pc(d.report.engine.hitRate),
								", AI lab alone: ",
								pc(d.report.ai.hitRate),
								". Always-home baseline: ",
								pc(d.report.baselines.alwaysHome.hitRate),
								"."
							]
						})] }) : null
					] }),
					d.counts.settled > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Is it improving, or just looking confident?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: d.trend.text
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Spark, { points: d.rolling }),
						d.rolling.length >= 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-[11px] text-muted",
							children: "Rolling 20-match Brier score; lower is better."
						}) : null,
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-muted",
							children: [
								"Models agreed on ",
								d.report.agreement.agree.n,
								" matches (",
								pc(d.report.agreement.agree.hitRate),
								" correct) and disagreed on ",
								d.report.agreement.disagree.n,
								" (",
								pc(d.report.agreement.disagree.hitRate),
								" correct).",
								d.counts.settled < 50 ? " Too few matches to treat agreement as a signal." : ""
							]
						})
					] }) : null,
					d.report.calibration.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Confidence calibration"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "When the app said X%, how often did that outcome happen?"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-1 grid gap-1 text-xs text-muted sm:grid-cols-2",
							children: d.report.calibration.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "tabular-nums",
								children: [
									"Said ",
									pc(b.predicted),
									" → happened ",
									pc(b.observed),
									" (",
									b.n,
									" outcomes)",
									b.n >= 10 && Math.abs(b.predicted - b.observed) > .1 ? b.predicted > b.observed ? " · overconfident" : " · underconfident" : ""
								]
							}, b.from))
						})
					] }) : null,
					d.report.tiers.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "By tier"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1 grid gap-1 text-xs text-muted sm:grid-cols-2",
						children: d.report.tiers.map((t) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							"Tier ",
							t.tier,
							": ",
							pc(t.card.hitRate),
							" correct over ",
							t.card.n,
							" (",
							pc(t.card.hitLow),
							"–",
							pc(t.card.hitHigh),
							")"
						] }, t.tier))
					})] }) : null,
					d.byVersion.length > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
						className: "font-medium",
						children: "By model version"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1 text-xs text-muted",
						children: d.byVersion.map((v) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [
							v.version,
							": Brier ",
							num(v.card.brier),
							", hit rate ",
							pc(v.card.hitRate),
							", ",
							v.card.n,
							" matches"
						] }, v.version))
					})] }) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Per-league results"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Only forecasts frozen before kick-off and later settled are included. Small samples are descriptive, not proof of an edge."
						}),
						d.byLeague.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-2 overflow-x-auto",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
								className: "w-full min-w-[28rem] text-xs",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
									className: "text-muted",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "pb-1 pr-2 text-left font-normal",
											children: "League"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "pb-1 pr-2 text-right font-normal",
											children: "n"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "pb-1 pr-2 text-right font-normal",
											children: "Top pick"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "pb-1 pr-2 text-right font-normal",
											children: "Brier ↓"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
											className: "pb-1 text-right font-normal",
											children: "Log loss ↓"
										})
									] })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: d.byLeague.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
									className: "border-t border-line",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
											className: "py-1.5 pr-2",
											children: [row.league, row.n < 50 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted",
												children: " · early sample"
											}) : ""]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 pr-2 text-right tabular-nums",
											children: row.n
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 pr-2 text-right tabular-nums",
											children: pc(row.hitRate)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 pr-2 text-right tabular-nums",
											children: num(row.brier)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
											className: "py-1.5 text-right tabular-nums",
											children: num(row.logLoss)
										})
									]
								}, row.league)) })]
							})
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "No settled pre-kickoff records are available yet."
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h3", {
						className: "font-medium",
						children: [
							"Pending matches awaiting results (",
							d.buckets.pending.length,
							")"
						]
					}), d.buckets.pending.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-1 flex flex-col gap-1 text-xs",
						children: d.buckets.pending.map((r) => {
							const over = Date.parse(r.kickoffAt) + 72e5 < Date.parse(snap.serverTime);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex flex-wrap justify-between gap-2 border-t border-line py-1.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
									r.home,
									" v ",
									r.away,
									" ",
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-muted",
										children: ["· ", when(r.kickoffAt)]
									})
								] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-muted",
									children: [
										"Tip ",
										r.code === "PASS" ? "PASS" : `${NAME[r.pick]} (${r.code})`,
										" ",
										pc(r.final[r.pick]),
										" · ",
										over ? "result due" : "not played yet"
									]
								})]
							}, r.matchId);
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: "Nothing pending. New forecasts are frozen automatically when a fixture with a verified future kick-off appears."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
							className: "font-medium",
							children: "Settled match history and correct vs incorrect reports"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex gap-1 text-xs",
							role: "group",
							"aria-label": "Filter settled matches",
							children: [
								["all", `All (${d.counts.settled})`],
								["correct", `Correct (${d.outcomes.correct.length})`],
								["incorrect", `Incorrect (${d.outcomes.incorrect.length})`],
								["confident", `Confident misses (${d.outcomes.confidentMisses.length})`]
							].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => setFilter(id),
								"aria-pressed": filter === id,
								className: `rounded-full border px-2.5 py-1 ${filter === id ? "border-signal text-signal" : "border-line text-muted"}`,
								children: label
							}, id))
						})]
					}), shown.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-2 overflow-x-auto",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
							className: "w-full min-w-[34rem] text-xs",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
								className: "text-muted",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-2 text-left font-normal",
										children: "Match"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-2 text-left font-normal",
										children: "Frozen tip"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-2 text-left font-normal",
										children: "Score"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-2 text-left font-normal",
										children: "Result"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 pr-2 text-left font-normal",
										children: "Top pick"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
										className: "pb-1 text-left font-normal",
										children: "Tip covered"
									})
								] })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: shown.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
								className: "border-t border-line",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1.5 pr-2",
										children: [
											r.home,
											" v ",
											r.away,
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "text-muted",
												children: when(r.kickoffAt)
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1.5 pr-2",
										children: [
											NAME[r.pick],
											" ",
											pc(r.final[r.pick]),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("br", {}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "text-muted",
												children: [
													r.code,
													" · tier ",
													r.tier
												]
											})
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
										className: "py-1.5 pr-2 tabular-nums",
										children: [
											r.homeGoals,
											"–",
											r.awayGoals
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 pr-2",
										children: NAME[r.result]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5 pr-2",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { ok: topCorrect(r) })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
										className: "py-1.5",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { ok: tipCovered(r) })
									})
								]
							}, r.matchId)) })]
						})
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-xs text-muted",
						children: "No settled matches in this view yet."
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
						className: "rounded-card border border-line bg-raised p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
							className: "cursor-pointer text-sm font-medium",
							children: "How post-match information is kept out"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
							className: "mt-2 list-disc pl-5 text-xs text-muted",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The server computes each forecast and stamps the time itself; the browser cannot send probabilities or a date." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A forecast is only recorded if the kick-off time is verified and still in the future. The database also refuses any row recorded at or after kick-off." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Logged forecasts are never rewritten. Only the result columns are filled in, once, by the results feed." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Every row stores the model version and a fingerprint of the inputs used, so later changes are visible." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Results are matched by team names, home/away order and a 36-hour window, and use the 90-minute score." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Rows recorded after kick-off (should be none) are excluded from every metric and flagged in the CSV." }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The frozen forecast is the stats-only tip. Live odds, injuries and AI nudges seen on a match card are not part of it." })
							]
						})]
					})
				]
			}) : null
		]
	});
}
var STEPS = [
	{
		title: "Goals, not a guess",
		body: "Each side's last five results are weighted so the newest games count more than the start of the run. Named players who are out cut that side's attack and weaken their defence. Dixon-Coles still allows more 0-0 and 1-1. The prices next to a book name are desk estimates, not that book's live board. Type the decimal you see at your bookmaker into the slip if you want the return to match the price you see."
	},
	{
		title: "The grid becomes markets",
		body: "Sum the cells and you get home, draw, away, both teams to score, and over or under 2.5. The most likely scoreline is just the single busiest cell. It is usually 1–1 in an even match. That does not mean the model “predicts 1–1” as a bet."
	},
	{
		title: "Board prices are estimates",
		body: "The named-book rows on the main board are seeded demo estimates, not current quotes from Pinnacle, Betfair, Betika, SportPesa, 1xBet, or any other operator. Their margin and edge calculations do not measure a real market advantage. Enter the price you actually see or verify a separate public reference; never stake from a simulated quote."
	},
	{
		title: "In-play is the xG that is left",
		body: "A live match keeps the pre-match expected goals, spends them as the minute runs, and adds the goals already on the board. What is left is another Poisson. That is the in-play home, draw and away, and the chance of the next goal. The tape is a desk clock, not a television feed."
	},
	{
		title: "The slip is yours to place",
		body: "Pick the site you will actually use. The slip reprices every leg there, shows the same slip at every other site, and copies the lines. IAN TECH cannot log in, cannot send a booking code, and cannot place the bet. A code that loads inside 1xBet is printed by 1xBet, not here."
	},
	{
		title: "Stake small, or not at all",
		body: "Expected value is model probability times the best decimal price, minus one. The suggested stake is a quarter of the Kelly fraction, and never more than 4% of the bank you type in. If nothing clears a 2-point edge, the match is a pass."
	}
];
function Method() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex max-w-3xl flex-col gap-8",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "How the desk works"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-pretty text-muted",
				children: "IAN TECH reconciles the local statistical engine, its formula-model lab, and any available verified provider signals into one final result. The local models share inputs and are not independent votes. API-backed Elo, venue form, rest, standings, odds, lineups, or weather appear only when a provider response can be matched and timestamped. Required team-data gaps cause a PASS rather than an invented live forecast. These systems still cannot guarantee a correct result or 100% accuracy."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-signal p-4 text-ink",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Quick guide to using IAN TECH"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
						className: "mt-3 list-decimal space-y-2 pl-5 text-sm",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open Ready or Upcoming and choose the bookmaker and market you want to review." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open a match’s prediction lab to see the 25 local models, 17 diagnostics, sample coverage, model spread, stress check, source status, freshness gate, and risk warnings. Refresh live data/lineups when close to kick-off." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "In Jackpot, read the team order carefully: 1 is the home team shown first, X is draw, and 2 is the away team shown second. Select only one result per match." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "A red flag marks a 10-point-or-greater gap between a no-vig price probability and the matching local model probability. It is a caution, not proof that a bet will lose." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "If a public bookmaker quote is missing, add a match and type the exact three prices from that bookmaker’s app. Manual prices are user-entered and are not independently verified." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Selections, manual rows, and settings are saved only in this browser profile. They do not sync with other devices or profiles; use a separate browser profile/private window if sharing the same device." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-sm",
						children: "Always verify the fixture, kickoff, team order, and price in the bookmaker app. IAN TECH does not place bets, and no result is certain."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-4",
				children: STEPS.map((step, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-card border border-line bg-surface p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-sm text-signal",
							children: ["0", index + 1]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-1 font-display text-2xl",
							children: step.title
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-pretty text-muted",
							children: step.body
						})
					]
				}, step.title))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-raised p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Match order and bookmaker alignment"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-pretty text-sm text-muted",
					children: "Select a league, then choose Sort → Competition → kickoff to group matches by competition and order them by the listed start time. The same local schedule order is used for every bookmaker selection, and the expanded schedule follows the same rule. This is not a live mirror of the order inside 1xBet or another operator; a true per-book mirror requires an authorized, current fixture feed from that operator. All live quotes and missing fixture matches remain subject to the source limits described below."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-raised p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Server data, Supabase, and calibration"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-sm text-muted",
						children: "No login is required. For central Vercel persistence, configure SUPABASE_DATABASE_URL (a server-only Postgres connection) and run the included migrations; the Method tab’s Performance dashboard checks connection and durability. Without a hosted database, preview storage is ephemeral. Optional API_FOOTBALL_KEY supplies recent results, rest/fatigue, venue-split form, standings/motivation, longer-history Elo, fitted time-decayed Dixon–Coles, and fixture-matched lineups. ODDS_API_KEY collects current 1X2 quotes and app-observed movement. Verified VENUE_COORDINATES_JSON coordinates enable Open-Meteo weather diagnostics. GEMINI_API_KEY enables a bounded analyst nudge, and FOOTBALL_DATA_KEY settles logged results. All credentials stay server-side; see SETUP.md and .env.example for Vercel configuration."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-sm text-muted",
						children: "Model weights learn from up to the last 100 prospective, settled log entries; league metrics are shown with sample-size warnings. Late lineup and market observations are stored separately so frozen forecasts remain unchanged. The dashboard’s close-line metric is only a timestamp-qualified proxy, not official closing odds or a user's actual bet CLV. Open-Meteo’s public endpoint is non-commercial; commercial use requires a licensed endpoint."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-raised p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Expanded fixture schedule"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-sm text-muted",
						children: "The expanded schedule loads on request from OpenFootball’s public-domain fixture JSON for eight competitions: England’s Premier League and Championship, plus Germany, Spain, France, Italy, the Netherlands, and Portugal’s top divisions. It adds calendar-date rows for a rolling 30-day window and links each row to its source. These are not a complete 1xBet Global event feed. Source rows do not include reliable kick-off times, current bookmaker odds, or the team statistics used by the prediction models, so they are shown as fixture-only and receive no generated pick. Dates and postponements must be verified. The OpenFootball repository says its latest-season files are auto-published daily, but its upstream match data is not guaranteed to update daily."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href: "https://github.com/openfootball/football.json",
						target: "_blank",
						rel: "noreferrer",
						className: "mt-2 inline-block text-sm text-signal underline",
						children: "OpenFootball source and license"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PerformanceDashboard, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BacktestPanel, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Books on the board"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 flex flex-wrap gap-2",
						children: BOOKS$1.map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-full border border-line px-3 py-2 text-sm",
							children: [book.name, book.sharp ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: " · sharp"
							}) : null]
						}, book.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-pretty text-sm text-muted",
						children: "These are seeded demonstration prices reconstructed around the model. They are not live quotes and are not scraped from the named bookmakers. As a result, the calculated edge, value filter, expected value, and stake display are illustrative only—not real market measurements or betting advice."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-2xl",
					children: "Public odds checks"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-pretty text-sm text-muted",
					children: "The Jackpot tab accepts Betika prices only when both teams, their home/away order, a valid future kickoff, and all three decimal prices match. It checks SportPesa’s official public jackpot feed without a login or API key; this runtime received HTTP 403 from that feed, so no SportPesa prices are shown here unless the feed becomes accessible or you enter prices from the app manually. SportPesa home/away is never guessed from competitor row order. The official SportPesa homepage also presented a CAPTCHA, so neither restriction is bypassed. When a match card’s lab opens, it can check a public Kenya comparison page for an exact SportPesa row. That third-party site warns that prices may be delayed or inaccurate, so the result is only a reference snapshot. No automated 1xBet quote is shown: its public page is not reliably readable here and available bookmaker-specific aggregator terms prohibit automated reuse without permission. In the match-card odds panel, compare available Betika and SportPesa reference prices against the demo estimate. You can also enter all three prices manually for another bookmaker, including on Jackpot. Missing public quotes stay blank; they are never replaced by demo prices when a public source is selected."
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-raised p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "What this will not do"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-pretty text-muted",
						children: "No model produces correct bets. A 68% side loses about one time in three. A plus-EV price is a long-run argument about the number, and a short weekend is not the long run. xG, form and absences on this card are a compiled scouting snapshot, not a live injury wire. IAN TECH cannot log in to a bookmaker and cannot place a bet for you."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-pretty text-sm text-muted",
						children: "Only stake money you can lose. If betting stops being a choice, stop. Local gambling-help services exist for that moment. 18+."
					})
				]
			})
		]
	});
}
var TOOLS = [
	"Preferred betting site",
	"League categories",
	"Ready-made predictions",
	"Upcoming games",
	"Recent results",
	"Expected goals",
	"Your site’s 1X2 odds",
	"Decimal, fractional, American",
	"Result, BTTS or goals",
	"Minimum edge",
	"Sort by edge, kickoff, competition then kickoff, chance, xG",
	"Watchlist",
	"Kickoff countdown",
	"Most likely score",
	"Double chance",
	"Short, mid or long price",
	"Model record on recent games",
	"Value-only at your site",
	"Stake from your bank",
	"Best price elsewhere",
	"Fair price against your price",
	"Demo price tape",
	"Search",
	"Absence notes"
];
var ADVANCED_LENSES = [
	"Weighted recent form",
	"Season xG attack",
	"Season xG defence",
	"Dixon–Coles low-score correction",
	"Home advantage adjustment",
	"Away scoring adjustment",
	"League-position gap",
	"Named-absence impact",
	"Finishing regression",
	"Save/defence regression",
	"Goal-difference rate",
	"Last-two momentum",
	"Win/loss streak context",
	"Close-table draw lift",
	"Open-match scenario",
	"Tight-match scenario",
	"Both-defences leak check",
	"Both-defences strength check",
	"Sample-size shrinkage",
	"Home/away class gap",
	"Consensus probability blend",
	"1X2 bookmaker margin removal",
	"Odds-to-model value comparison"
];
function Ready() {
	const league = useDesk((s) => s.league);
	const query = useDesk((s) => s.query);
	const bookId = useDesk((s) => s.bookId);
	const marketFocus = useDesk((s) => s.marketFocus);
	const sortKey = useDesk((s) => s.sortKey);
	const minEdge = useDesk((s) => s.minEdge);
	const onlyValue = useDesk((s) => s.onlyValue);
	const watch = useDesk((s) => s.watch);
	const watchOnly = useDesk((s) => s.watchOnly);
	const record = modelRecord();
	const bookName = BOOKS$1.find((book) => book.id === bookId)?.name ?? "your site";
	const competitionCount = new Set(MATCHES.map((match) => match.code)).size;
	const rows = sortMatches(MATCHES.filter((match) => isUpcomingMatch(match) && passesFilters(match, {
		league,
		query,
		bookId,
		marketFocus,
		minEdge,
		onlyValue,
		watchOnly,
		watch
	})), sortKey, bookId, marketFocus);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Predictions, already read"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-2 max-w-2xl text-pretty text-muted",
				children: [
					"Every fixture currently in the board’s catalogue is available here; filters can narrow the view, but lower-probability games are not silently removed. The call is a probability at",
					" ",
					bookName,
					", not a correct bet. Recent record: the model’s likely result landed",
					" ",
					record.hit,
					" of ",
					record.n,
					". Open the AI-style prediction lab on a match card for 25 local model formulas, 17 additional diagnostics, agreement and stress tests, plus public odds references where an exact match is available."
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2 sm:grid-cols-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverageStat, {
						value: String(MATCHES.length),
						label: "Bundled fixture cards"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverageStat, {
						value: String(competitionCount),
						label: "Bundled competitions"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverageStat, {
						value: "19",
						label: "Local prediction models"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoverageStat, {
						value: "4",
						label: "Odds source choices"
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted",
				children: "The 152 cards are the app’s bundled set, not every bookmaker match. Use the expanded schedule above to load extra public fixtures in eight supported competitions; those schedule-only rows do not include the statistics or odds needed for a model pick."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExpandedFixtures, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
					className: "cursor-pointer text-sm font-medium",
					children: "Desk tools on this board"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-3 grid gap-1 text-sm text-muted sm:grid-cols-2",
					children: TOOLS.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: tool }, tool))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("details", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("summary", {
						className: "cursor-pointer text-sm font-medium",
						children: "23 additional statistical lenses"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: "These are explainable statistical checks calculated from the fixture data in this app. They are not 23 separate AI services, and their agreement does not guarantee a result."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-3 grid gap-2 text-sm text-muted sm:grid-cols-2",
						children: ADVANCED_LENSES.map((lens, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "mr-2 text-signal",
							children: String(index + 1).padStart(2, "0")
						}), lens] }, lens))
					})
				]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-card border border-line bg-surface px-4 py-8 text-center text-muted",
				children: "Nothing in this category clears the filters. Widen the edge or turn off value-only."
			}) : sortKey === "competition" ? groupMatchesByCompetition(rows).map(({ code, rows: group }) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
					className: "font-display text-2xl",
					children: [
						LEAGUES.find((item) => item.code === code)?.label ?? code,
						" · ",
						group.length,
						" games"
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-3 md:grid-cols-2",
					children: group.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
				})]
			}, code)) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-2",
				children: rows.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchCard, { match }, match.id))
			})
		]
	});
}
function CoverageStat({ value, label }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-card border border-line bg-raised p-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-2xl tabular-nums text-signal",
			children: value
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-xs text-muted",
			children: label
		})]
	});
}
function Recent() {
	const league = useDesk((s) => s.league);
	const query = useDesk((s) => s.query);
	const bookId = useDesk((s) => s.bookId);
	const oddsFormat = useDesk((s) => s.oddsFormat);
	const setOpen = useDesk((s) => s.setOpen);
	const q = query.trim().toLowerCase();
	const rows = RECENT.filter((match) => {
		if (league !== "ALL" && match.code !== league) return false;
		if (!q) return true;
		return `${match.home.name} ${match.away.name}`.toLowerCase().includes(q);
	});
	const hit = rows.filter((match) => actualSide(match) === match.likely.market).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-4xl",
			children: "Recent games"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "mt-2 max-w-2xl text-pretty text-muted",
			children: [
				"Finished matches from 1–4 November. The score is the outcome. The line under it is what the model thought was most likely, and whether that call landed. These are historical baseline calls, not the live reconciled Final tip used on Ready/Upcoming. ",
				hit,
				" of ",
				rows.length,
				" in this filter."
			]
		})] }), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "rounded-card border border-line bg-surface px-4 py-8 text-center text-muted",
			children: "No result in this category."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-col gap-3",
			children: rows.map((match) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultRow, {
				match,
				bookId,
				oddsFormat,
				onOpen: () => setOpen(match.id)
			}, match.id))
		})]
	});
}
function ResultRow({ match, bookId, oddsFormat, onOpen }) {
	const actual = actualSide(match);
	const landed = actual === match.likely.market;
	const quote = quoteAt(match, bookId, match.likely.market);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		onClick: onOpen,
		className: "grid w-full gap-3 rounded-card border border-line bg-surface p-4 text-left md:grid-cols-[auto_1fr_auto] md:items-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "font-display text-3xl tabular-nums",
				children: [
					match.homeGoals,
					"–",
					match.awayGoals
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						match.code,
						" · ",
						match.playedLabel,
						" · xG ",
						match.lambdaHome.toFixed(2),
						"–",
						match.lambdaAway.toFixed(2)
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-medium",
					children: [
						match.home.name,
						" v ",
						match.away.name
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-sm text-muted",
					children: [
						"Historical baseline called ",
						selectionName(match, match.likely.market),
						" (",
						pct$1(match.likely.model),
						") · result",
						" ",
						shortMarket(match, actual)
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm " + (landed ? "text-signal" : "text-muted"),
				children: [landed ? "Call landed" : "Call missed", /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "mt-1 block tabular-nums text-fg",
					children: [
						quote.book,
						" ",
						formatOdds(quote.odds, oddsFormat)
					]
				})]
			})
		]
	});
}
var HISTORY_KEY = "ian-tech-slips";
function readHistory() {
	try {
		const raw = JSON.parse(localStorage.getItem(HISTORY_KEY) || "[]");
		if (!Array.isArray(raw)) return [];
		return raw.filter((row) => {
			if (!row || typeof row !== "object") return false;
			const item = row;
			return typeof item.code === "string" && Array.isArray(item.legs) && typeof item.text === "string";
		});
	} catch {
		return [];
	}
}
function remember(slip) {
	const next = [slip, ...readHistory().filter((row) => row.code !== slip.code)].slice(0, 6);
	localStorage.setItem(HISTORY_KEY, JSON.stringify(next));
}
function SlipView() {
	const legs = useDesk((s) => s.legs);
	const bankroll = useDesk((s) => s.bankroll);
	const toggleLeg = useDesk((s) => s.toggleLeg);
	const clearLegs = useDesk((s) => s.clearLegs);
	const setOpen = useDesk((s) => s.setOpen);
	const placeId = useDesk((s) => s.placeId);
	const setPlaceId = useDesk((s) => s.setPlaceId);
	const oddsFormat = useDesk((s) => s.oddsFormat);
	const showKes = useDesk((s) => s.showKes);
	const setLegs = useDesk((s) => s.setLegs);
	const setSeenOdds = useDesk((s) => s.setSeenOdds);
	const [receipt, setReceipt] = (0, import_react.useState)("");
	const [receiptNote, setReceiptNote] = (0, import_react.useState)("");
	const [stakeText, setStakeText] = (0, import_react.useState)("");
	const [loadText, setLoadText] = (0, import_react.useState)("");
	const [loadNote, setLoadNote] = (0, import_react.useState)("");
	const [history, setHistory] = (0, import_react.useState)([]);
	const { now } = useNow(5e3);
	const place = BOOKS$1.find((book) => book.id === placeId) ?? BOOKS$1[0];
	const rows = legs.map((leg) => {
		const match = findMatch(leg.matchId);
		if (!match) return null;
		const priced = priceLeg(match, leg.market, placeId, now, leg.seenOdds);
		return {
			match,
			market: leg.market,
			seenOdds: leg.seenOdds,
			...priced
		};
	}).filter((row) => row !== null);
	const sameGame = rows.some((row, index) => rows.findIndex((other) => other.match.id === row.match.id) !== index);
	const combinedOdds = rows.reduce((acc, row) => acc * row.odds, 1);
	const combinedP = rows.reduce((acc, row) => acc * row.model, 1);
	const combinedEv = rows.length === 0 ? 0 : combinedP * combinedOdds - 1;
	const code = slipCode(rows.map((row) => `${row.match.id}:${row.market}`));
	const suggested = rows.length === 0 ? 0 : rows.length === 1 ? rows[0].stake : parlayStake(combinedOdds, combinedP, combinedEv, bankroll);
	const typedStake = Number(stakeText);
	const stake = stakeText === "" || !Number.isFinite(typedStake) || typedStake < 0 ? suggested : typedStake;
	const returns = stake * (Number.isFinite(combinedOdds) ? combinedOdds : 0);
	const heavy = bankroll > 0 && stake / bankroll > .05;
	const money = (n) => showKes ? `KES ${Math.round(n * 100).toLocaleString("en-KE")}` : `${units(n)} u`;
	const lines = rows.map((row, index) => `${index + 1}. ${row.match.home.name} v ${row.match.away.name} — ${selectionName(row.match, row.market)} @ ${row.odds.toFixed(2)}${row.live ? " in-play" : ""}`);
	const xbetText = [
		"IAN TECH lines for 1xBet",
		"Not a 1xBet booking code. 1xBet will not load this. Add each match on 1xBet yourself.",
		...lines,
		`Combined @ ${combinedOdds.toFixed(2)}`,
		`Stake ${money(stake)} · return ${money(returns)}`,
		`IAN TECH code ${code} — paste this on IAN TECH to reload the slip, not into 1xBet.`
	].join("\n");
	const savedSlipSnapshot = JSON.stringify({
		code,
		legs: rows.map((row) => ({
			matchId: row.match.id,
			market: row.market
		})),
		text: lines.join("\n")
	});
	(0, import_react.useEffect)(() => {
		setHistory(readHistory());
	}, []);
	(0, import_react.useEffect)(() => {
		const saved = JSON.parse(savedSlipSnapshot);
		if (saved.legs.length === 0) return;
		remember(saved);
		setHistory(readHistory());
	}, [savedSlipSnapshot]);
	async function processCopy(body) {
		setReceipt(body);
		try {
			await navigator.clipboard.writeText(body);
			setReceiptNote("Copy processed. It is on the clipboard. Select the box if you need it again.");
		} catch {
			setReceiptNote("Copy processed on screen. The clipboard was blocked, so select the text.");
		}
	}
	function loadCode() {
		const wanted = loadText.trim().toUpperCase();
		const hit = readHistory().find((row) => row.code.toUpperCase() === wanted);
		if (!hit) {
			setLoadNote("That code is not saved on this browser. IAN TECH codes reload a slip you already built here. 1xBet will not accept them.");
			return;
		}
		setLegs(hit.legs);
		setLoadNote(`Loaded ${hit.code}.`);
	}
	const across = BOOKS$1.map((book) => ({
		book,
		odds: rows.reduce((acc, row) => acc * priceLeg(row.match, row.market, book.id, now).odds, 1)
	})).sort((a, b) => b.odds - a.odds);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl",
				children: "Slip"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 max-w-2xl text-pretty text-muted",
				children: "Price the legs for the site you use, then process the copy. 1xBet will not load a code made here. Their load box only accepts a code 1xBet printed. The lines below are what you add by hand."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-surface p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl",
						children: "Load an IAN TECH code"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "This reloads a slip already processed in this browser. It is not a 1xBet booking code."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: loadText,
							onChange: (event) => setLoadText(event.target.value),
							placeholder: "SL-····",
							className: "h-11 min-w-40 flex-1 rounded-card border border-line bg-bg px-3",
							"aria-label": "IAN TECH slip code"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: loadCode,
							className: "h-11 rounded-full bg-signal px-4 text-sm font-medium text-ink",
							children: "Load"
						})]
					}),
					loadNote ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-muted",
						children: loadNote
					}) : null,
					history.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 flex flex-wrap gap-2",
						children: history.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							onClick: () => {
								setLegs(item.legs);
								setLoadNote(`Loaded ${item.code}.`);
							},
							className: "h-11 rounded-full border border-line px-4 text-sm",
							children: item.code
						}, item.code))
					}) : null
				]
			}),
			rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-card border border-dashed border-line bg-surface px-4 py-10 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: "The slip is empty."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-muted",
						children: "Add a pick from Live, Ready, or a match sheet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => useDesk.getState().setView("live"),
						className: "mt-4 h-11 rounded-full bg-signal px-4 text-sm font-medium text-ink",
						children: "See live games"
					})
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-4 lg:grid-cols-[1fr_20rem]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex flex-col gap-1 text-sm text-muted",
								children: ["Place this on", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
									value: placeId,
									onChange: (event) => setPlaceId(event.target.value),
									className: "h-11 rounded-card border border-line bg-surface px-3 text-fg",
									children: [
										"Kenya",
										"International",
										"Sharp"
									].map((region) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("optgroup", {
										label: region,
										children: BOOKS$1.filter((book) => book.region === region).map((book) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: book.id,
											children: book.name
										}, book.id))
									}, region))
								})]
							}),
							sameGame ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: "Two markets from the same game are on this slip. Some books will not take both. The combined price treats them as separate."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "flex flex-col gap-3",
								children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "rounded-card border border-line bg-surface p-4",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "text-sm text-muted",
											children: [
												row.match.home.short,
												" v ",
												row.match.away.short,
												row.live ? " · in play" : ` · ${row.match.dateLabel}`
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 text-lg font-medium",
											children: selectionName(row.match, row.market)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
											className: "mt-1 text-sm tabular-nums text-muted",
											children: [
												row.yours ? "Your price" : `${place.name} desk estimate`,
												" ",
												formatOdds(row.odds, oddsFormat),
												" · model ",
												pct$1(row.model),
												" ·",
												" ",
												signedEv(row.model * row.odds - 1),
												row.stake > 0 ? ` · stake ${money(row.stake)}` : ""
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
											className: "mt-3 block text-sm text-muted",
											children: [
												"Odds you see on ",
												place.name,
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
													inputMode: "decimal",
													placeholder: "e.g. 1.85",
													value: row.seenOdds ?? "",
													onChange: (event) => {
														const next = Number(event.target.value);
														setSeenOdds(row.match.id, row.market, event.target.value.trim() === "" || !Number.isFinite(next) ? null : next);
													},
													className: "mt-1 h-11 w-full rounded-card border border-line bg-bg px-3 text-fg"
												})
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex gap-2",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => setOpen(row.match.id),
												className: "h-11 rounded-full border border-line px-4 text-sm",
												children: "Sheet"
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												onClick: () => toggleLeg(row.match.id, row.market),
												className: "h-11 rounded-full border border-line px-4 text-sm text-muted",
												children: "Remove"
											})]
										})
									]
								}, `${row.match.id}:${row.market}`))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-card border border-line bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: "Put this on Betika or 1xBet"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
										className: "mt-2 list-decimal space-y-1 pl-5 text-sm text-muted",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Open that site and search each match by the team names below." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "Tap the same pick: 1, X, 2, both teams, or over/under 2.5." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "On Betika, tap Share on their slip. On 1xBet, tap Save/load events." }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: "The code that site shows is the only one its load box will accept." })
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-3 text-sm text-fg",
										children: [
											"The code on this page (",
											code,
											") only reloads the slip here. Betika and 1xBet both reject it, because they never created it."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "mt-3 overflow-x-auto whitespace-pre-wrap rounded-card bg-bg p-3 text-sm",
										children: xbetText
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
								className: "rounded-card border border-line bg-surface p-4",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-display text-2xl",
										children: "Same slip, every site"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
										className: "mt-1 text-sm text-muted",
										children: [
											"Best place to play it: ",
											across[0]?.book.name,
											" at ",
											across[0]?.odds.toFixed(2),
											". Still type it in yourself."
										]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-3 grid gap-2 sm:grid-cols-2",
										children: across.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
											className: "flex items-center justify-between rounded-card px-3 py-2 text-sm " + (row.book.id === placeId ? "bg-signal text-ink" : "bg-raised"),
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: row.book.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums",
												children: formatOdds(row.odds, oddsFormat)
											})]
										}, row.book.id))
									})
								]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
						className: "h-fit rounded-card border border-dashed border-line bg-surface p-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: [
									rows.length === 1 ? "Single" : `${rows.length}-leg parlay`,
									" · ",
									place.name
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-4xl tabular-nums",
								children: formatOdds(combinedOdds, oddsFormat)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-2 text-sm text-muted",
								children: ["Desk code ", code]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-sm text-muted",
								children: ["Combined model chance ", pct$1(combinedP)]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm tabular-nums",
								children: signedEv(combinedEv)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-3 text-sm text-fg",
								children: [
									"Stake ",
									money(stake),
									" · possible return ",
									money(returns)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "mt-3 flex flex-col gap-1 text-sm text-muted",
								children: ["Your stake", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									value: stakeText,
									onChange: (event) => setStakeText(event.target.value),
									inputMode: "decimal",
									placeholder: suggested ? String(suggested) : "0",
									className: "h-11 rounded-card border border-line bg-bg px-3 text-fg"
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-2 flex flex-wrap gap-2",
								children: [
									1,
									2,
									5,
									10
								].map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
									type: "button",
									onClick: () => setStakeText(String(n)),
									className: "h-11 rounded-full border border-line px-3 text-sm",
									children: [n, "u"]
								}, n))
							}),
							heavy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-pretty text-muted",
								children: "That stake is over 5% of the bank. Cut it."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-3 h-1.5 overflow-hidden rounded-full bg-raised",
								"aria-hidden": "true",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "h-full bg-signal",
									style: { width: `${Math.min(100, combinedP * 100).toFixed(1)}%` }
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-sm text-muted",
								children: ["Slip chance ", pct$1(combinedP)]
							}),
							rows.length > 2 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-3 text-sm text-pretty text-muted",
								children: "Three or more legs multiply the book’s margin. A long acca is not a better bet."
							}) : null,
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: () => void processCopy(xbetText),
								className: "mt-4 h-11 w-full rounded-full bg-signal text-sm font-medium text-ink",
								children: "Process 1xBet lines"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => void processCopy([
									`IAN TECH slip · ${place.name}`,
									`Code ${code}`,
									...lines,
									`Combined @ ${combinedOdds.toFixed(2)}`,
									`Stake ${money(stake)}`
								].join("\n")),
								className: "mt-2 h-11 w-full rounded-full border border-line text-sm",
								children: [
									"Process ",
									place.name,
									" copy"
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: place.href,
								target: "_blank",
								rel: "noreferrer",
								className: "mt-2 flex h-11 w-full items-center justify-center rounded-full border border-line text-sm",
								children: ["Open ", place.name]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								onClick: clearLegs,
								className: "mt-2 h-11 w-full rounded-full border border-line text-sm text-muted",
								children: "Clear slip"
							})
						]
					}),
					receipt ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "rounded-card border border-signal bg-surface p-4 lg:col-span-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "font-display text-2xl",
								children: "Copy processed"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: receiptNote
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
								className: "mt-3 overflow-x-auto whitespace-pre-wrap rounded-card bg-bg p-3 text-sm text-fg",
								children: receipt
							})
						]
					}) : null
				]
			})
		]
	});
}
function priceLeg(match, market, bookId, now, seen) {
	const fixture = liveFixture(match.id);
	const book = BOOKS$1.find((row) => row.id === bookId);
	const typed = typeof seen === "number" && seen >= 1.01 && seen <= 50 ? Math.round(seen * 100) / 100 : null;
	if (fixture && (market === "home" || market === "draw" || market === "away") && now !== null && typed === null) {
		const clock = liveClock(fixture.offsetMin, now);
		const score = scoreAt(fixture.goals, clock.minute);
		const play = inPlay(match.lambdaHome, match.lambdaAway, clock.minute, score.home, score.away);
		const model = market === "home" ? play.home : market === "away" ? play.away : play.draw;
		const odds = liveDecimal(model, Boolean(book?.sharp));
		const edge = {
			market,
			model,
			consensus: model,
			edge: 0,
			odds,
			book: book?.name ?? "",
			bookId,
			ev: model * odds - 1,
			confidence: "Solid"
		};
		return {
			odds,
			model,
			live: true,
			yours: false,
			stake: suggestedStake(edge, useDesk.getState().bankroll)
		};
	}
	const quote = quoteAt(match, bookId, market);
	const model = match.model[market];
	const odds = typed ?? quote.odds;
	const edge = {
		market,
		model,
		consensus: match.consensus[market],
		edge: quote.edge,
		odds,
		book: quote.book,
		bookId,
		ev: model * odds - 1,
		confidence: "Solid"
	};
	return {
		odds,
		model,
		live: false,
		yours: typed !== null,
		stake: suggestedStake(edge, useDesk.getState().bankroll)
	};
}
function parlayStake(odds, model, ev, bankroll) {
	if (ev <= 0 || odds <= 1) return 0;
	const fraction = Math.min(.02, Math.max(0, ((odds - 1) * model - (1 - model)) / (odds - 1)) * .25);
	return Math.round(fraction * bankroll * 100) / 100;
}
function AccuracyNotice({ className = "" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		role: "note",
		className: `rounded-card border border-line bg-raised px-3 py-2 text-xs text-fg ${className}`,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", {
				className: "font-semibold",
				children: "Important:"
			}),
			" ",
			"AI cannot guarantee winning jackpot predictions. Actual accuracy must be measured against completed match results."
		]
	});
}
function ProviderStatus() {
	const [status, setStatus] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		let active = true;
		fetch("/api/ops/status", { headers: { accept: "application/json" } }).then((response) => response.ok ? response.json() : null).then((value) => {
			if (active && value) setStatus(value);
		}).catch(() => void 0);
		return () => {
			active = false;
		};
	}, []);
	const configured = status?.providers.filter((provider) => provider.configured) ?? [];
	const workerFailures = status?.workers.filter((worker) => worker.status === "failed").length ?? 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-surface px-4 py-3",
		"aria-label": "Data coverage status",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-wrap items-center justify-between gap-2",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-semibold uppercase tracking-[0.16em] text-signal",
				children: "Signal desk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-1 text-sm text-fg",
				children: [
					configured.length,
					" live server integrations configured · ",
					workerFailures ? `${workerFailures} worker failures` : "worker lane ready"
				]
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-1.5",
				children: (status?.providers ?? []).map((provider) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: `rounded-full border px-2 py-1 text-[11px] ${provider.configured ? "border-emerald-400/60 text-emerald-300" : "border-line text-muted"}`,
					children: [
						provider.name,
						": ",
						provider.configured ? "connected" : "not configured"
					]
				}, provider.id))
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-[11px] text-muted",
			children: "Live odds are shown only from configured authorized sources with timestamps. Unavailable sources remain blank; schedule coverage is not odds coverage."
		})]
	});
}
var NAV = [
	{
		id: "live",
		label: "Live",
		short: "Live",
		icon: Radio
	},
	{
		id: "ready",
		label: "Ready",
		short: "Ready",
		icon: Sparkles
	},
	{
		id: "upcoming",
		label: "Upcoming",
		short: "Next",
		icon: CalendarClock
	},
	{
		id: "jackpot",
		label: "Jackpot",
		short: "Jackpot",
		icon: Trophy
	},
	{
		id: "recent",
		label: "Results",
		short: "Results",
		icon: History
	},
	{
		id: "slip",
		label: "Slip",
		short: "Slip",
		icon: Ticket
	},
	{
		id: "method",
		label: "Method",
		short: "Method",
		icon: Info
	}
];
function Desk() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(false);
	const view = useDesk((s) => s.view);
	const setView = useDesk((s) => s.setView);
	const legs = useDesk((s) => s.legs);
	const bankroll = useDesk((s) => s.bankroll);
	const setBankroll = useDesk((s) => s.setBankroll);
	const openId = useDesk((s) => s.openId);
	const previewId = useDesk((s) => s.previewId);
	const bookId = useDesk((s) => s.bookId);
	const showKes = useDesk((s) => s.showKes);
	const setShowKes = useDesk((s) => s.setShowKes);
	const book = BOOKS$1.find((row) => row.id === bookId)?.name ?? "Betika";
	const { now } = useNow(1e3);
	(0, import_react.useEffect)(() => {
		const timer = window.setTimeout(() => setOpen(true), 1800);
		return () => window.clearTimeout(timer);
	}, []);
	const clock = now === null ? "Live desk" : new Intl.DateTimeFormat("en-GB", {
		hour: "2-digit",
		minute: "2-digit",
		timeZone: "Europe/London",
		hourCycle: "h23"
	}).format(now) + " UK";
	if (!open) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Splash, { onEnter: () => setOpen(true) });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-30 border-b border-line bg-bg/95 backdrop-blur",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-6xl flex-wrap items-center gap-3 px-4 py-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mr-auto flex items-center gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "size-3 rounded-full bg-signal",
								"aria-hidden": "true"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl leading-none",
								children: "IAN TECH"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "max-w-[16rem] text-[11px] leading-tight text-muted",
								children: [
									"Football betting predictions website · ",
									clock,
									" · ",
									book
								]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
							className: "hidden items-center gap-1 md:flex",
							"aria-label": "Sections",
							children: NAV.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavButton, {
								active: view === item.id,
								label: item.id === "slip" && legs.length > 0 ? `${item.label} ${legs.length}` : item.label,
								onClick: () => setView(item.id)
							}, item.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 rounded-full border border-line bg-surface px-3 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-muted",
									children: "Bank"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
									type: "number",
									min: 1,
									max: 1e6,
									value: showKes ? Math.round(bankroll * 100) : bankroll,
									onChange: (event) => {
										const next = Number(event.target.value);
										if (!Number.isFinite(next) || next < 1) return;
										setBankroll(showKes ? next / 100 : next);
									},
									className: "w-24 bg-transparent text-right tabular-nums outline-none",
									"aria-label": showKes ? "Bankroll in Kenyan shillings" : "Bankroll in units"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setShowKes(!showKes),
									className: "text-muted",
									children: showKes ? "KES" : "u"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => {
								const url = window.location.href;
								navigator.clipboard.writeText(url).then(() => {
									setCopied(true);
									window.setTimeout(() => setCopied(false), 1600);
								});
							},
							className: "flex h-11 items-center gap-2 rounded-full border border-line px-3 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link2, { className: "size-4" }), copied ? "Copied" : "Copy link"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "border-t border-line px-4 py-2 text-center text-xs text-muted",
					children: [
						"Estimates, not certainties. Demo prices are the default; choose or compare sources per match. Missing public prices stay blank. A positive edge is not a correct bet. 18+. Need help?",
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "underline",
							href: "tel:+254723278526",
							children: "+254 723 278 526"
						}),
						" · ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							className: "underline",
							href: "https://wa.me/254723278526",
							target: "_blank",
							rel: "noreferrer",
							children: "WhatsApp"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto flex max-w-6xl flex-col gap-4 px-4 py-6 pb-28 md:pb-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AccuracyNotice, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProviderStatus, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ModelMonitor, {}),
					view !== "slip" && view !== "method" && view !== "jackpot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Controls, {}) : null,
					view === "live" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LiveBoard, {}) : null,
					view === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ready, {}) : null,
					view === "upcoming" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Board, {}) : null,
					view === "jackpot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Jackpot, {}) : null,
					view === "recent" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Recent, {}) : null,
					view === "slip" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlipView, {}) : null,
					view === "method" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Method, {}) : null
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-30 border-t border-line bg-bg/95 backdrop-blur md:hidden",
				"aria-label": "Sections",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid grid-cols-7",
					children: NAV.map((item) => {
						const Icon = item.icon;
						const active = view === item.id;
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							onClick: () => setView(item.id),
							className: "flex h-16 w-full flex-col items-center justify-center gap-1 text-[11px] " + (active ? "text-signal" : "text-muted"),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" }),
								item.short,
								item.id === "slip" && legs.length > 0 ? ` ${legs.length}` : ""
							]
						}) }, item.id);
					})
				})
			}),
			openId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchSheet, { id: openId }) : null,
			previewId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MatchPreview, { id: previewId }) : null
		]
	});
}
function Splash({ onEnter }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-h-screen flex-col items-center justify-center gap-6 px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "size-3 rounded-full bg-signal",
				"aria-hidden": "true"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
				className: "font-display text-5xl leading-none sm:text-7xl",
				children: ["IAN TECH", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "mt-3 block",
					children: "PREDICTIONS"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-muted",
				children: "Football. Estimates, not certainties."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				onClick: onEnter,
				className: "h-11 rounded-full bg-signal px-6 text-sm font-medium text-ink",
				children: "Enter"
			})
		]
	});
}
function NavButton({ active, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		onClick,
		className: "h-11 rounded-full px-3 text-sm " + (active ? "bg-signal font-medium text-ink" : "text-muted"),
		children: label
	});
}
var SplitComponent = Desk;
//#endregion
export { SplitComponent as component };
